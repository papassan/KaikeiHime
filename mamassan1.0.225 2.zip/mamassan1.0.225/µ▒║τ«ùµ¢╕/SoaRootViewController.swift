//
//  PRootViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/25.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//
//参考サイトhttp://hack-it-iron.hatenablog.com/entry/2015/07/15/102631

import UIKit

var 会計姫categories = ["仕訳の支払い", "保険料の支払い", "通信費の支払い", "ガソリン代の支払い", "水道光熱費の支払い", "租税公課の支払い", "事務用消耗品費の支払い", "備品消耗品費の支払い", "旅費交通費の支払い", "修繕費の支払い"]
var 会計姫categoriesForButtons = ["仕訳", "保険料", "通信費", "ガソリン代", "水道光熱費", "租税公課", "事務用消耗品費", "備品消耗品費", "旅費交通費", "修繕費"]

class SoaRootViewController: UIViewController, UIPageViewControllerDelegate {

    var pageViewController: UIPageViewController?


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Configure the page view controller and add it as a child view controller.
        
//水平スクロール
        pageViewController = UIPageViewController(transitionStyle: .pageCurl, navigationOrientation: .horizontal, options: nil)
//垂直スクロール
//        self.pageViewController = UIPageViewController(transitionStyle: .pageCurl, navigationOrientation: .vertical, options: nil)
        
        pageViewController!.delegate = self
//ここSoaDataViewController
        let startingViewController: SoaDataViewController = modelController.viewControllerAtIndex(0, storyboard: storyboard!)!
        let viewControllers = [startingViewController]
        pageViewController!.setViewControllers(viewControllers, direction: .forward, animated: false, completion: {done in })

        pageViewController!.dataSource = modelController

        addChildViewController(pageViewController!)
        view.addSubview(pageViewController!.view)

        // Set the page view controller's bounds using an inset rect so that self's view is visible around the edges of the pages.
        let pageViewRect = view.bounds
        pageViewController!.view.frame = pageViewRect

        pageViewController!.didMove(toParentViewController: self)

        // Add the page view controller's gesture recognizers to the book view controller's view so that the gestures are started more easily.
        view.gestureRecognizers = pageViewController!.gestureRecognizers
    }
    
    //ここSoaModelController
    var modelController: SoaModelController {
        // Return the model controller object, creating it if necessary.
        // In more complex implementations, the model controller may be passed to the view controller.
        if _modelController == nil {
            //ここSoaModelController
            _modelController = SoaModelController()
        }
        return _modelController!
    }
    //ここSoaModelController
    var _modelController: SoaModelController? = nil
    
    // MARK: - UIPageViewController delegate methods
    
    func pageViewController(_ pageViewController: UIPageViewController, spineLocationFor orientation: UIInterfaceOrientation) -> UIPageViewControllerSpineLocation {
        // Set the spine position to "min" and the page view controller's view controllers array to contain just one view controller. Setting the spine position to 'UIPageViewControllerSpineLocationMid' in landscape orientation sets the doubleSided property to true, so set it to false here.
        let currentViewController = pageViewController.viewControllers?[0]
        let viewControllers = [currentViewController]
        pageViewController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: true, completion: {done in })
        
        pageViewController.isDoubleSided = false
        return .min
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

