//
//  ContentView.swift
//  SwiftUICDSaveToDoc2
//
//  Created by 福田 敏一 on 2019/12/11.
//  Copyright © 2019 株式会社パパスサン. All rights reserved.
//

import SwiftUI
import Combine
import CoreData

var students = [String]()
var isSave = false

final class StudentData: ObservableObject  {
    
    let appDelegate: AppDelegate
    let moc: NSManagedObjectContext
    
    init() {
print("22-3 Counter data initialized・CV")
        
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        moc = appDelegate.managedObjectContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        
        let results = try! moc.fetch(fetchRequest) as! [Student]
//起動時に通過します、初期では配列は空なのいで結果は[]です
print("31-15通過・students・cv -> \(students)")
        if results.capacity > 0 {
            for i in 0..<results.count {
                students += ["\(results[i].student)"]
            }
//1つ以上の保存データがあれば通過します
print("38-16通過・students -> \(students)")
        }
    }
    
    let didChange = PassthroughSubject<StudentData, Never>()
    
    @Published var name: String = "" {
        didSet {
print("Data changed to", self.name)
            didChange.send(self)
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
            do {
                if self.name == "" && students != [] {
                    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
                    var daleteStudents: [Student] = []
                    daleteStudents = try! moc.fetch(fetchRequest) as! [Student]
                    moc.delete(daleteStudents.last!)
                    students.removeLast()
                    try moc.save()
/*                    students = []
                    let results = try moc.fetch(fetchRequest) as! [Student]
                    for i in 0..<results.count {
                        students += ["\(results[i].student)"]
print("2通過・students -> \(students)")
                    }*/
                    return
                }
                let results = try moc.fetch(fetchRequest) as! [Student]
                
                if results.capacity > 0 {
print("Updating existing entity", self.name)
                    let Updating = NSEntityDescription.insertNewObject(forEntityName: "Student", into: moc) as! Student
                        Updating.student = self.name
                } else {
print("Creating new entity", self.name)
                    let newEntity = NSEntityDescription.insertNewObject(forEntityName: "Student", into: moc) as! Student
                    newEntity.student = self.name
                    students = ["\(self.name)"]
                }
                if isSave == true {
print("71・通過・context.save()")
                    try moc.save()
                    isSave = false
                }
            } catch {
                // Do something in response to error condition
                print("Failed trying to save")
                print("Error info: \(error)")
            }
            do {
                students = []
                let results = try moc.fetch(fetchRequest) as! [Student]
                for i in 0..<results.count {
                    students += ["\(results[i].student)"]
print("2通過・students -> \(students)")
                }
             } catch {
                 // Do something in response to error condition
                 print("Failed trying to save")
                 print("Error info: \(error)")
             }
        }
    }
}

public class Student: NSManagedObject {
    @NSManaged public var student: String
}

struct ContentView : View {
    
    @EnvironmentObject var counterData: StudentData
    
    @State var hasClicked: Bool = false
    
    private func saveCoreData(chosenFirstName: String, chosenLastName: String) {
print("保存")
        isSave = true
        self.counterData.name = "\(chosenFirstName) \(chosenLastName)"
    }
    
    private func deleteCoreData() {
print("削除")
        self.hasClicked = true
        self.counterData.name = ""
    }
    
    var body: some View {
        VStack {
            List {
               ForEach(students, id: \.self) { student in
                Text(student)
                }
            }
                HStack {
                Button("保存") {
                    let firstNames = ["Ginny", "Harry", "Hermione", "Luna", "Ron"]
                    let lastNames = ["Granger", "Lovegood", "Potter", "Weasley"]

                    let chosenFirstName = firstNames.randomElement()!
                    let chosenLastName = lastNames.randomElement()!

                    self.saveCoreData(chosenFirstName: chosenFirstName, chosenLastName: chosenLastName)
                }.padding(.all)
                 .border(Color.blue, width: 5)
                    .foregroundColor(.green)
                    .font(.title)
                    .frame(width: 100, height: 0, alignment: .center)
                    Spacer()
                Button(action: {
                    self.deleteCoreData()
                    
                }) {
                    //Text("削除")
                    Image(systemName: "trash")
                }.padding(.all)
                    .background(Color.red)
                    .cornerRadius(40)
                    .foregroundColor(.black)
                    .padding(10)
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.purple, lineWidth: 5))
            }.padding(20)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        .environmentObject(StudentData())
    }
}
