//
//  AddSpendingViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/04/14.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

//参考サイトhttp://d.hatena.ne.jp/kazukingband/20120522/1337638966
//参考サイト http://hajihaji-lemon.com/smartphone/swift/uipickerview/

import UIKit

// MARK: - 参考サイト1-1 http://qiita.com/YusukeHosonuma/items/95315add4004b59e5f00
func execOnce( execute: inout (() -> ())?) {
    if let f = execute {
        f()
        execute = nil
    }
}
// MARK: - ここまで・参考サイト1-1

// MARK: - 表示する値の配列

var 挨拶 = "こんにちは"


var 売掛伝票入金 = [["普通預金","現金","当座預金","相殺"],["三菱東京UFJ","栃木銀行越谷西支店","楽天","埼玉りそな越谷","栃木銀行越谷西支店空調","埼玉りそな越谷空調","現金","当座預金"]]


let 売掛伝票顧客 = [["現金顧客","ポラスグランテック株式会社","瀬野左官工業所","株式会社電美","有限会社萩原工業","左官職山田","株式会社東武園芸","東武谷内田建設株式会社","花菱産業株式会社","宮内建材株式会社","太平洋セメント販売株式会社","豊田建材興業株式会社","東横建材株式会社","高村礦材株式会社","野田(有)福田商店","大木建材工業株式会社","矢鋪タイル工業","草加 宇田川"],["0","1","2","3","3","2","2","3","2","1","2","2","2","2","2","2","2","0"],["1","0","1","0","2","1","0","0","2","0","0","0","0","0","0","0","2","0"],["6","1","6","3","7","6","3","3","7","0","3","7","3","3","3","3","7","3"]]
let 売掛伝票番号 = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"]

let 売掛伝票品名 = [["１号砕石","川砂","中目砂","中目砂(合)","中目砂(ヶ)","フルイ砂","フルイ砂(合)","フルイ砂(ヶ)","8分砂利","8分砂利(合)","8分砂利(ヶ)","40-0","40-0(合)","40-0(ヶ)","残土","生コン18-18","カラ練り18-0","川砂(袋)","8分砂利(袋詰め)","セメント","エースモルタルII","イイモル 25kg","上プラ","Bドライ","四国京カベ","モルター","メタルラス","フェルト 8kg","A-10 並","C-10 並","少量運賃"],["0.1","0.2","0.25","0.3","0.4","0.5","0.6","0.7","0.75","0.8","0.9","1.0","1","1.5","1.8","2.0","2","2.1","2.2","2.5","2.75","2.8","3.0","3","3.5","4.0","4","5.0","5","6","7","8","9","10","11","12","15","20","30","100"],["170","175","185","300","400","500","510","550","560","600","650","750","900","1,320","1,700","1,800","2,000","3,000","4,500","5,000","5,100","5,400","5,600","5,800","6,000","6,400","6,800","7,800","8,500","8,800","9,200","12,100","12,200","171,100"],["m³","m³","m³","合","ヶ","m³","合","ヶ","m³","合","ヶ","m³","合","ヶ","m³","m³","m³","袋","袋","袋","袋","袋","袋","袋","袋","袋","坪","本","本","本","台"],["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"],["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39"],["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33"]]


class KUAddViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
//画面拡大と移動
    @IBOutlet weak var View拡大: UIView!
    var pinchGesture = UIPinchGestureRecognizer()
    var startTransform:CGAffineTransform!
//ここまで

    // MARK: - Properties
    
    @IBOutlet weak var 電卓: UIStackView!
    @IBOutlet weak var 保存: UriageSyUIBounceButton!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var categorySegmentedControl1: UISegmentedControl!
    @IBOutlet weak var categorySegmentedControl2: UISegmentedControl!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var costLabel: UILabel!

    @IBOutlet weak var multiplyButton: UIButton!
    
    @IBOutlet weak var 年ラベル: UILabel!
    @IBOutlet weak var 月ラベル: UILabel!
    @IBOutlet weak var 日ラベル: UILabel!
    
    @IBOutlet weak var 売掛伝票顧客ラベル: UILabel!
    @IBOutlet weak var 売掛伝票顧客ピッカー部品: UIPickerView!
    @IBOutlet weak var 伝票番号テキスト入力: UITextField!
    @IBOutlet weak var 伝票現金顧客テキスト入力: UITextField!
    @IBOutlet weak var 売掛伝票番号ラベル: UILabel!
    @IBOutlet weak var 売掛伝票番号ピッカー部品: UIPickerView!
    @IBOutlet weak var 売掛伝票品名ピッカー部品: UIPickerView!
    
    @IBOutlet weak var 顧客ボタン表示: UIButton!
    @IBOutlet weak var 番号ボタン表示: UIButton!
    @IBOutlet weak var 日付ピッカーボタン表示: UIButton!
    
    @IBOutlet weak var 品名ボタン表示1: UIButton!
    @IBOutlet weak var 品名ボタン表示2: UIButton!
    @IBOutlet weak var 品名ボタン表示3: UIButton!
    @IBOutlet weak var 品名ボタン表示4: UIButton!
    @IBOutlet weak var 品名ボタン表示5: UIButton!
    @IBOutlet weak var 品名ボタン表示6: UIButton!
    @IBOutlet weak var 品名ボタン表示7: UIButton!
    
    @IBOutlet weak var 売掛伝票品名ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル7: UILabel!
    
    // MARK: ラベル
    
    @IBOutlet weak var 売掛伝票数量ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル7: UILabel!
    
    @IBOutlet weak var 売掛伝票単価ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル7: UILabel!
    
    @IBOutlet weak var 売掛伝票単位ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル7: UILabel!
    
    @IBOutlet weak var 売掛伝票小計ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル7: UILabel!

    @IBOutlet weak var 売掛伝票合計ラベル: UILabel!
    
    @IBOutlet weak var 適用テキスト1: UITextField!
    @IBOutlet weak var 適用テキスト2: UITextField!
    @IBOutlet weak var 適用テキスト3: UITextField!
    @IBOutlet weak var 適用テキスト4: UITextField!
    @IBOutlet weak var 適用テキスト5: UITextField!
    @IBOutlet weak var 適用テキスト6: UITextField!
    @IBOutlet weak var 適用テキスト7: UITextField!
    @IBOutlet weak var コメントテキスト6行目入力: UITextField!
    
    @IBOutlet weak var 伝票削除許可ボタン: UIButton!
    

    var 伝票修正 = true
    var ビッカー変更 = true
    var 締切 = ""
    var 顧客ID = ""
    var 保存ボタン = 0
    var 初期日付ピッカー = 0

    
    var 売掛伝票顧客入力 = true
    var 売掛伝票顧客入力済 = false
    var 売掛伝票日付入力 = true
    var 売掛伝票番号入力 = true
    var 売掛伝票番号入力済 = false
    
    var 売掛伝票品名入力1 = false
    var 売掛伝票品名入力2 = false
    var 売掛伝票品名入力3 = false
    var 売掛伝票品名入力4 = false
    var 売掛伝票品名入力5 = false
    var 売掛伝票品名入力6 = false
    var 売掛伝票品名入力7 = false
    
    var 売掛伝票品名入力済1 = false
    var 売掛伝票品名入力済2 = false
    var 売掛伝票品名入力済3 = false
    var 売掛伝票品名入力済4 = false
    var 売掛伝票品名入力済5 = false
    var 売掛伝票品名入力済6 = false
    var 売掛伝票品名入力済7 = false
    
    var 品名rowInt = 0
    var 数量rowInt = 11
    var 単価rowInt = 15
    
    //Optional型での宣言
    var 品名rowString: String? = "11"
    //非Optional型での宣言
    var 数量rowString = "31"
    var 単価rowString = "0"
    
    var 更新伝票番号 = 0
    var 更新伝票数 = 0
    var ラスト現金顧客伝票番号 = 0
    
    var 伝票合計Int = 0
    
    var 売掛伝票小計ラベル1合計 = 0
    var 売掛伝票小計ラベル2合計 = 0
    var 売掛伝票小計ラベル3合計 = 0
    var 売掛伝票小計ラベル4合計 = 0
    var 売掛伝票小計ラベル5合計 = 0
    var 売掛伝票小計ラベル6合計 = 0
    var 売掛伝票小計ラベル7合計 = 0
    
    //アルファ
    @IBOutlet weak var 伝票アルファ: UIImageView!

    // 日付フォーマット
    //年
    var yeardateFormatter: DateFormatter{
        let yearformatter = DateFormatter()
        yearformatter.dateFormat = "y"
        return yearformatter
    }
    //月
    var monthdateFormatter: DateFormatter{
        let monthformatter = DateFormatter()
        monthformatter.dateFormat = "M"//MMならば4は04と表示します
        return monthformatter
    }
    //日
    var daydateFormatter: DateFormatter{
        let dayformatter = DateFormatter()
        dayformatter.dateFormat = "d"//ddなら4は04と表示します
        return dayformatter
    }

    // MARK: - Flags for Inputing Numbers
    
    var multiplyFlag = false
    var placehold = false
    var edNumber = 0
    
//追加
    // MARK: - Properties for Saving data into Core Data
    var myCategory = 売上締日.first
    var myDate: [Int] = {
        var myDate: [Int] = []
        // get current date
        let now = Date()
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: now)
        // assign them to myDate[]
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate.append(year)
            myDate.append(month)
            myDate.append(day)
        }
        return myDate
    }()
    
    // MARK: -
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//ここ
    var uriage: Uriage?
    var taisyaku: Taisyaku?
    
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("挨拶の文字数は\(挨拶.characters.count)文字です")
        //Swift4 print("挨拶の文字数は\(挨拶.count)文字です")
        //Swift4 print("挨拶の文字数は\(挨拶.append("?"))文字です")
        
        伝票現金顧客テキスト入力.delegate = self
        適用テキスト1.delegate = self
        適用テキスト2.delegate = self
        コメントテキスト6行目入力.delegate = self
        伝票現金顧客テキスト入力.alpha = 0
        伝票番号テキスト入力.alpha = 0
//参考サイトhttps://stackoverflow.com/questions/30406379/why-is-the-textfieldshouldreturn-function-not-being-called
//伝票番号テキスト入力後にenterを押すときの処理
//以下がないとenterを押しても変化しません
        伝票番号テキスト入力.delegate = self
        
        //YESなら操作可、NOなら操作不可
        //合計.isEnabled = true
        //合計.isEnabled = false
        
//売掛伝票ピッカー
        売掛伝票顧客ピッカー部品.delegate = self
        売掛伝票顧客ピッカー部品.dataSource = self
        売掛伝票顧客ピッカー部品.alpha = 0
        
        売掛伝票番号ピッカー部品.delegate = self
        売掛伝票番号ピッカー部品.dataSource = self
        売掛伝票番号ピッカー部品.alpha = 0

        売掛伝票品名ピッカー部品.alpha = 0
        
        datePicker.alpha = 0
        
        電卓.alpha = 0
        保存.alpha = 0
        
        伝票削除許可ボタン.alpha = 0
        
        //更新伝票番号
        更新伝票番号 = Int(ラスト伝票番号) + 1
        売掛伝票番号ラベル.text = String(更新伝票番号)
        
        更新伝票数 = Int(伝票数) + 1
        売掛伝票番号ラベル.text = String(更新伝票数)

        
//画面拡大と移動
        ジェスチャーの用意()
//ここまで
        
        // set date got from segue
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        
        if let date = dateFormatter.date(from: "\(myDate[0])/\(myDate[1])/\(myDate[2])") {
            datePicker.date = date
        }
 
        
        // 初回の日付を表示する
        updateDateLabel()
//ここ
        if let uriage = uriage {
            伝票修正 = false
            setEditedSpending(uriage)
        }
        
        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(cancelButtonTapped(_:)))
        downSwipe.direction = .down
        self.view.addGestureRecognizer(downSwipe)

    }
// MARK: - ここまでviewDidLoad()
    

    
// MARK: - 参考サイト2-3
    func printSomething() {
        //print("this method might be executed once.")
    }
// MARK: - ここまで・参考サイト2-3
    
    //画面が表示された直後
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
//テキストフィールドでリターンを検知します
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //print("通過textFieldShouldReturn")
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            伝票現金顧客テキスト入力.alpha = 1
            売掛伝票顧客ラベル.alpha = 0
print("売掛伝票顧客ラベル.text = \(売掛伝票顧客ラベル.text!)")
        }
        伝票番号テキスト入力.resignFirstResponder()
        伝票現金顧客テキスト入力.resignFirstResponder()
        適用テキスト1.resignFirstResponder()
        適用テキスト2.resignFirstResponder()
        コメントテキスト6行目入力.resignFirstResponder()
        return true
    }
//全てのテキストフィールドをタップすると呼ばれます
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
//print("通過")
        return true
    }
    
//個別のテキストフィールドをタップすると呼ばれます
    @IBAction func エンター伝票現金顧客テキスト(_ sender: UITextField) {
//print("通過")
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            売掛伝票顧客ラベル.alpha = 0
        }
    }
    
//売掛伝票ピッカー
     //pickerに表示する列数を返すデータソースメソッド.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //print("通過0")
        if (pickerView.tag == 1) {
            return 売掛伝票顧客.count//return 1
        }
        if (pickerView.tag == 2) {
            return 1
        }
        if (pickerView.tag == 3) {
            return 売掛伝票品名.count
        }
        return 売掛伝票品名.count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する行数を返すデータソースメソッド
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //print("通過1")
        
        if (pickerView.tag == 1) {
            return 売掛伝票顧客[component].count//売掛伝票顧客[component].count
        }
        if (pickerView.tag == 2) {
            return 売掛伝票番号.count
        }
        if (pickerView.tag == 3) {
            return 売掛伝票品名[component].count
        }
        return 売掛伝票品名[component].count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する値を返すデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //print("通過2")
        
        if (pickerView.tag == 1) {
            return 売掛伝票顧客[component][row]//("\(売掛伝票顧客[row])")
        }
        if (pickerView.tag == 2) {
            return ("\(売掛伝票番号[row])")
        }
        if (pickerView.tag == 3) {
            return 売掛伝票品名[component][row]
        }
        return 売掛伝票品名[component][row]//returnは最後に追加したピッカーの変数を返します
    }
    
// MARK: - pickerが選択された際に呼ばれるデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print("通過3")
        
        if (pickerView.tag == 1) {
            売掛伝票顧客ラベル.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
// MARK: - ピッカー連動で項目を追加する
            締切 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 1)!
            顧客ID = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 2)!
            //print("顧客ID = \(顧客ID)")
            売掛伝票品名入力1 = true
            伝票顧客入力終了()
        }
        // MARK: - print("番号ピッカー選択後")
        if (pickerView.tag == 2) {
            売掛伝票番号ラベル.text = ("\(売掛伝票番号[row])")
            伝票番号入力終了()
        }
        if (pickerView.tag == 3) {
            var 品名 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
            var 数量 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
            var 単価 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
            //print("1数量 = \(数量!)")
            //単位は品名と同期しています
            //同期方法の解説・forComponentは配列の順番で設定します、この場合の配列順は品名、数量単価の次なので3になります、inComponentは同期したいinComponentと同様にします
            let 単位 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 0), forComponent: 3)
            //品名rowは品名と同期しています
            
            let 品名row = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 4)
            //数量rowは数量と同期しています
            let 数量row = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 5)
            //単価rowは単価と同期しています
            let 単価row = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 6)
            
            //print("品名 = \(品名!)")
            //print("2数量row = \(数量row!)")
                //print("初期品名ピッカー = \(初期品名ピッカー)")
            //print("1単価 = \(単価!)")
            //print("1単価rowInt = \(単価rowInt)")
            if 売掛伝票顧客ラベル.text == "現金顧客" {
//(有)グットホーム
//(株)ソイルシステム
                if 伝票現金顧客テキスト入力.text == "(有)クエスト" {
                    //print("伝票現金顧客テキスト入力.text = \(伝票現金顧客テキスト入力.text!)")
                    品名rowInt = 22//上プラ
                    数量rowInt = 33//10
                    単価rowInt = 14//1700
                }
            }
                if 品名 == "１号砕石" && ビッカー変更 == true {
                    品名rowInt = 0//１号砕石
                    数量rowInt = 11//1.0
                    単価rowInt = 25//6,400
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            
                if 品名 == "川砂" && ビッカー変更 == true {
                    品名rowInt = 1
                    数量rowInt = 9//0.8
                    単価rowInt = 29//8,800
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
                if 品名 == "中目砂" && ビッカー変更 == true {
                    品名rowInt = 2
                    数量rowInt = 11//1.0
                    単価rowInt = 24//9,200
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            if 品名 == "中目砂(合)" && ビッカー変更 == true {
                品名rowInt = 3
                数量rowInt = 12//1
                単価rowInt = 13//5,100
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "中目砂(ヶ)" && ビッカー変更 == true {
                品名rowInt = 4
                数量rowInt = 28//5
                単価rowInt = 8//560
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "フルイ砂" && ビッカー変更 == true {
                品名rowInt = 5
                数量rowInt = 11//1.0
                単価rowInt = 24//9,200
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "フルイ砂(合)" && ビッカー変更 == true {
                品名rowInt = 6
                数量rowInt = 12//1
                単価rowInt = 19//5,100
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "フルイ砂(ヶ)" && ビッカー変更 == true {
                品名rowInt = 7
                数量rowInt = 26//5
                単価rowInt = 5//510
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "8分砂利" && ビッカー変更 == true {
                品名rowInt = 8
                数量rowInt = 11//1.0
                単価rowInt = 23//8,800
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "8分砂利(合)" && ビッカー変更 == true {
                品名rowInt = 9
                数量rowInt = 12//1
                単価rowInt = 13//5,100
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "8分砂利(ヶ)" && ビッカー変更 == true {
                品名rowInt = 10
                数量rowInt = 26//5
                単価rowInt = 5//510
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
                if 品名 == "40-0" && ビッカー変更 == true {
                    品名rowInt = 11
                    数量rowInt = 11//1.0
                    単価rowInt = 19//5,800
                    ビッカー変更 = false
                    if 売掛伝票顧客ラベル.text == "現金顧客" {
                        単価rowInt = 24//6,000
                    }
                    顧客品名ピッカー雛形設定()
                }
                if 品名 == "40-0(合)" && ビッカー変更 == true {
                    品名rowInt = 12
                    数量rowInt = 12//1
                    単価rowInt = 15//3,000
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
                if 品名 == "40-0(ヶ)" && ビッカー変更 == true {
                    品名rowInt = 13
                    数量rowInt = 26//5
                    単価rowInt = 2//300
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            if 品名 == "残土" && ビッカー変更 == true {
                品名rowInt = 14
                数量rowInt = 19//2.5
                単価rowInt = 18//4,500
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "生コン18-18" && ビッカー変更 == true {
                品名rowInt = 15
                数量rowInt = 11//1.0
                単価rowInt = 0
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "カラ練り18-0" && ビッカー変更 == true {
                品名rowInt = 16
                数量rowInt = 11//1.0
                単価rowInt = 32//12,200
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "川砂(袋)" && ビッカー変更 == true {
                品名rowInt = 16
                数量rowInt = 26//5
                単価rowInt = 3//400
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "8分砂利(袋詰め)" && ビッカー変更 == true {
                品名rowInt = 18
                数量rowInt = 33//10
                単価rowInt = 5//500
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
                if 品名 == "セメント" && ビッカー変更 == true {
                    品名rowInt = 19//セメント
                    数量rowInt = 38//30
                    単価rowInt = 7//550
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            if 品名 == "エースモルタルII" && ビッカー変更 == true {
                品名rowInt = 20//エースモルタルII
                数量rowInt = 28//5
                単価rowInt = 13//1,320
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
                if 品名 == "イイモル 25kg" && ビッカー変更 == true {
                    品名rowInt = 21
                    数量rowInt = 33//10
                    単価rowInt = 12//900
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            if 品名 == "上プラ" && ビッカー変更 == true {
                //print("通過")
                品名rowInt = 22//上プラ
                数量rowInt = 33//10
                単価rowInt = 14//1,700
                ビッカー変更 = false
                if 伝票現金顧客テキスト入力.text == "(有)クエスト" {
                    単価rowInt = 14//1700
                }
                if 伝票現金顧客テキスト入力.text == "(株)ソイルシステム" {
                    単価rowInt = 15//1800
                }
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "Bドライ" && ビッカー変更 == true {
                品名rowInt = 22
                数量rowInt = 15//2
                単価rowInt = 4
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "四国京カベ" && ビッカー変更 == true {
                品名rowInt = 23
                数量rowInt = 26//5
                単価rowInt = 8//650
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "モルター" && ビッカー変更 == true {
                品名rowInt = 25
                数量rowInt = 27//5
                単価rowInt = 0//170
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
                if 品名 == "メタルラス" && ビッカー変更 == true {
                    品名rowInt = 26
                    数量rowInt = 39//100
                    単価rowInt = 9//600
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            if 品名 == "フェルト 8kg" && ビッカー変更 == true {
                品名rowInt = 27
                数量rowInt = 32//9
                単価rowInt = 21//5400
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "A-10 並" && ビッカー変更 == true {
                品名rowInt = 25
                数量rowInt = 33//10
                単価rowInt = 1//175
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "C-10 並" && ビッカー変更 == true {
                品名rowInt = 29//C-10 並
                数量rowInt = 33//10
                単価rowInt = 2//185
                ビッカー変更 = false
                顧客品名ピッカー雛形設定()
            }
                if 品名 == "少量運賃" && ビッカー変更 == true {
                    品名rowInt = 30//少量運賃
                    数量rowInt = 12//1
                    単価rowInt = 14//2000
                    ビッカー変更 = false
                    顧客品名ピッカー雛形設定()
                }
            
            //print("3単価 = \(単価!)")
            //print("3単価rowInt = \(単価rowInt)")
            //顧客品名ピッカー雛形設定()
            //print("4単価 = \(単価!)")
            //print("4単価rowInt = \(単価rowInt)")
            
            品名 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
            数量 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
            単価 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)

            //print("5単価 = \(単価!)")
            //print("5単価rowInt = \(単価rowInt)")
            
//print("4数量 = \(数量!)")
            
            if 売掛伝票品名入力1 {
                売掛伝票品名ラベル1.text = 品名
                売掛伝票数量ラベル1.text = 数量
                売掛伝票単位ラベル1.text = 単位
                売掛伝票単価ラベル1.text = 単価
                
                //String同士で置き換えをしていますがOptional型での宣言(var 品名rowString: String? = "11")で初期化していれば!マークが不要ですが非Optional型での宣言(var 数量rowString = "31")で初期化すると!マークは必要です
                品名rowString = 品名row
                数量rowString = 数量row!
                単価rowString = 単価row!
            }
            
            if 売掛伝票品名入力2 {
                売掛伝票品名ラベル2.text = 品名
                売掛伝票数量ラベル2.text = 数量
                売掛伝票単位ラベル2.text = 単位
                売掛伝票単価ラベル2.text = 単価
            }
            
            if 売掛伝票品名入力3 {
                売掛伝票品名ラベル3.text = 品名
                売掛伝票数量ラベル3.text = 数量
                売掛伝票単位ラベル3.text = 単位
                売掛伝票単価ラベル3.text = 単価
            }
            
            if 売掛伝票品名入力4 {
                売掛伝票品名ラベル4.text = 品名
                売掛伝票数量ラベル4.text = 数量
                売掛伝票単位ラベル4.text = 単位
                売掛伝票単価ラベル4.text = 単価
            }
            
            if 売掛伝票品名入力5 {
                売掛伝票品名ラベル5.text = 品名
                売掛伝票数量ラベル5.text = 数量
                売掛伝票単位ラベル5.text = 単位
                売掛伝票単価ラベル5.text = 単価
            }
            
            if 売掛伝票品名入力6 {
                売掛伝票品名ラベル6.text = 品名
                売掛伝票数量ラベル6.text = 数量
                売掛伝票単位ラベル6.text = 単位
                売掛伝票単価ラベル6.text = 単価
            }
            
            if 売掛伝票品名入力7 {
                売掛伝票品名ラベル7.text = 品名
                売掛伝票数量ラベル7.text = 数量
                売掛伝票単位ラベル7.text = 単位
                売掛伝票単価ラベル7.text = 単価
            }
        }
    }
    
    //参考サイトhttp://stackoverflow.com/questions/33655015/changing-font-and-its-size-of-a-picker-in-swift
    // MARK: - ピッカーのフォントサイズ設定
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        
        var 売上顧客フォント: UILabel
            if let view = view as? UILabel {
                売上顧客フォント = view
            } else {
                売上顧客フォント = UILabel()
        }
        
        売上顧客フォント.textColor = .black
        売上顧客フォント.textAlignment = .center
        売上顧客フォント.font = UIFont.systemFont(ofSize: 12)
        
        // where data is an Array of String
        if pickerView.tag == 1 {
            売上顧客フォント.text = 売掛伝票顧客[component][row]//売掛伝票顧客[row] as? String
            return 売上顧客フォント
        }
        
        var 売上伝票番号フォント: UILabel
        if let view = view as? UILabel {
            売上伝票番号フォント = view
        } else {
            売上伝票番号フォント = UILabel()
        }
        
        売上伝票番号フォント.textColor = .black
        売上伝票番号フォント.textAlignment = .center
        売上伝票番号フォント.font = UIFont.systemFont(ofSize: 18)
        
        if pickerView.tag == 2 {
            売上伝票番号フォント.text = ("\(売掛伝票番号[row])")
            return 売上伝票番号フォント
        }
//ここから
        var 売上伝票品名フォント: UILabel
        if let view = view as? UILabel {
            売上伝票品名フォント = view
        } else {
            売上伝票品名フォント = UILabel()
        }
        
        売上伝票品名フォント.textColor = .black
        売上伝票品名フォント.textAlignment = .center
        売上伝票品名フォント.font = UIFont.systemFont(ofSize: 12)
        
        if pickerView.tag == 3 {
            売上伝票品名フォント.text = 売掛伝票品名[component][row]
            return 売上伝票品名フォント
        }//ここまで
//新規ピッカー追加はここに追加します
        
        return 売上伝票品名フォント//return変数は最後に追加した変数を書きます
}
    
    // MARK: - 品名のピッカーサイズ
    func pickerView(_ pickerView: UIPickerView, widthForComponent component:Int) -> CGFloat {
        
        if (pickerView.tag == 1) {
            return 169
        }
        if (pickerView.tag == 2) {
            return 26
        }
        if (pickerView.tag == 3) {
            switch component {
            case 0:
                return 95//品名の幅
            case 1:
                return 60//数量の幅
            case 2:
                return 54//単価の幅
            case 3:
                return 0//その他の幅
            default: break
            }
        }
        return 0//この場合は最後なので単価の幅です・34以下は万単位で1の桁が表示しません
    }
    
    // MARK: - ホイールのセルの高さの調節
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
    return 20
    }
    //ホイールのセルの幅の調節・しかし反応なしです ?
    func pickerView(_ pickerView: UIPickerView, rowWidthForComponent component: Int) -> CGFloat {
    return 80
    }
    
// MARK: - func・伝票顧客入力終了
    func 伝票顧客入力終了() {
        売掛伝票顧客ピッカー部品.alpha = 0
        売掛伝票顧客ラベル.alpha = 1
        売掛伝票番号入力 = true
        年ラベル.alpha = 1
        月ラベル.alpha = 1
        日ラベル.alpha = 1
        伝票アルファ.alpha = 1
        let 売上締日詳細Index = Int(締切)
        categorySegmentedControl1.selectedSegmentIndex = 売上締日詳細Index!
        myCategory = 売上締日[categorySegmentedControl1.selectedSegmentIndex]
        売掛伝票顧客入力済 = true
//顧客が現金顧客の場合に伝票番号を自由に入力させる
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            伝票番号テキスト入力.alpha = 1
            伝票番号テキスト入力.text = 売掛伝票番号ラベル.text
            売掛伝票番号ラベル.alpha = 0
            伝票現金顧客テキスト入力.alpha = 1
//print("通過")
        }

        入力済()
    }
    
    // MARK: - func・伝票番号入力終了//
    func 伝票番号入力終了() {
        売掛伝票番号ピッカー部品.alpha = 0
        売掛伝票番号ラベル.alpha = 1
        売掛伝票顧客入力 = true
        伝票アルファ.alpha = 1
        売掛伝票番号入力済 = true
        入力済()
    }
    
    // MARK: - func・伝票品名入力終了
    func 伝票品名入力終了() {
        if (売掛伝票品名ラベル1.text != "") {
            売掛伝票品名ピッカー部品.alpha = 1
            売掛伝票品名ピッカー部品.alpha = 0
            //売掛伝票品名ラベル1.tag = 0
            
            売掛伝票品名入力済1 = true
            //売掛伝票品名入力2 = true
            
            売掛伝票品名ラベル1.alpha = 1
            売掛伝票数量ラベル1.alpha = 1
            売掛伝票単価ラベル1.alpha = 1
            伝票アルファ.alpha = 1
            売掛伝票品名入力済1 = true
            入力済()
            if 売掛伝票品名入力済2 {
                売掛伝票品名入力3 = true
            }
            if 売掛伝票品名入力済3 {
                売掛伝票品名入力4 = true
            }
            if 売掛伝票品名入力済4 {
                売掛伝票品名入力5 = true
            }
            if 売掛伝票品名入力済5 {
                売掛伝票品名入力6 = true
            }
            if 売掛伝票品名入力済6 {
                売掛伝票品名入力7 = true
            }
        }
    }
    
    func 入力済() {
        if 売掛伝票顧客入力済 && 売掛伝票番号入力済 && 売掛伝票品名入力済1 {
            保存.alpha = 1
        }
    }
//ここまで
    
    //画面拡大と移動
    func ジェスチャーの用意() {
        View拡大.isUserInteractionEnabled = true
        View拡大.isMultipleTouchEnabled = true
        
        pinchGesture = UIPinchGestureRecognizer(target: self, action:#selector(画像拡大))
        View拡大.addGestureRecognizer(self.pinchGesture)
    }
//ここまで
//日付ラベル更新メソッド
    func updateDateLabel(){
        let now = Date()
        // システムのカレンダーを取得
        let 和暦 = Calendar(identifier: Calendar.Identifier.japanese)
        // 現在時刻のDateComponentsを取り出す
        var 和暦取得 = 和暦.dateComponents([.year, .month, .day, .hour, .minute, .second], from: now as Date)
        //西暦で表示する
        //年ラベル.text = yeardateFormatter.string(from: now as Date)
        //月ラベル.text = monthdateFormatter.string(from: now as Date)
        //日ラベル.text = daydateFormatter.string(from: now as Date)
        //和暦で表示する

            年ラベル.text = ("\(和暦取得.year!)")
            月ラベル.text = ("\(和暦取得.month!)")
            日ラベル.text = ("\(和暦取得.day!)")
        }

// MARK: セッティング
//追加売掛伝票品名ラベル2.text
    func setEditedSpending(_ uriage: Uriage) {
        myDate[0] = Int(uriage.year)
        myDate[1] = Int(uriage.month)
        myDate[2] = Int(uriage.day)
        myCategory = uriage.category!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let uriageDate = dateFormatter.date(from: "\(uriage.year)/\(uriage.month)/\(uriage.day)") {
            datePicker.date = uriageDate
        }
        if let uriageCategoryIndex = 売上締日詳細.index(of: uriage.category!) {
            if uriageCategoryIndex < 5 {
                categorySegmentedControl1.selectedSegmentIndex = uriageCategoryIndex
                
            } else {
                categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
                categorySegmentedControl2.selectedSegmentIndex = uriageCategoryIndex - 5
            }
//伝票の締め日を検知している
            //print("uriageCategoryIndex = \(uriageCategoryIndex)")
        }

//追加
            costLabel.text = String(Int(uriage.unitPrice1))
        
        伝票削除許可ボタン.alpha = 1
//name・顧客
        売掛伝票顧客ラベル.alpha = 1
        売掛伝票顧客ラベル.text = uriage.name
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            売掛伝票顧客ラベル.alpha = 0
            伝票現金顧客テキスト入力.alpha = 1
            伝票現金顧客テキスト入力.font = UIFont.systemFont(ofSize: 18)
            伝票現金顧客テキスト入力.text = uriage.nameGenkin
        }
//number・番号
        売掛伝票番号ラベル.alpha = 1
        売掛伝票番号ラベル.text = String(uriage.number)
        伝票番号テキスト入力.text = String(uriage.number)
//retailer・適用
        適用テキスト1.text = uriage.retailer1
        適用テキスト2.text = uriage.retailer2
        適用テキスト3.text = uriage.retailer3
        適用テキスト4.text = uriage.retailer4
        適用テキスト5.text = uriage.retailer5
        適用テキスト6.text = uriage.retailer6
        if 売掛伝票品名ラベル7.text != "消費税" { //これを追加します
            適用テキスト7.text = uriage.retailer7
        }
        
//MARK: - details・品名 売掛伝票品名ラベル2.text
        売掛伝票品名ラベル1.text = uriage.details1
        売掛伝票品名ラベル2.text = uriage.details2
        売掛伝票品名ラベル3.text = uriage.details3
        売掛伝票品名ラベル4.text = uriage.details4
        売掛伝票品名ラベル5.text = uriage.details5
        売掛伝票品名ラベル6.text = uriage.details6
        //print("uriage.details6 = \(String(describing: uriage.details6))")
        if 売掛伝票品名ラベル7.text != "消費税" { //これを追加します
            売掛伝票品名ラベル7.text = uriage.details7
        }
//コメント6行目の表示
        if 売掛伝票品名ラベル6.text == nil { //これを追加します
            //print("通過")
            売掛伝票品名ラベル6.text = uriage.details
        }

//quantity・数量
        売掛伝票数量ラベル1.text = ("\(String(uriage.quantity1))")
        
        if 売掛伝票品名ラベル2.text != nil {
            売掛伝票数量ラベル2.text = ("\(String(uriage.quantity2))")
        }
        if 売掛伝票品名ラベル3.text != nil {
        売掛伝票数量ラベル3.text = ("\(String(uriage.quantity3))")
        }
        if 売掛伝票品名ラベル4.text != nil {
        売掛伝票数量ラベル4.text = ("\(String(uriage.quantity4))")
        }
        if 売掛伝票品名ラベル5.text != nil {
        売掛伝票数量ラベル5.text = ("\(String(uriage.quantity5))")
        }
        if 売掛伝票品名ラベル6.text != nil {
            売掛伝票数量ラベル6.text = ("\(String(uriage.quantity6))")
        }
        if 売掛伝票品名ラベル7.text != nil { //これを追加します
            売掛伝票数量ラベル7.text = ("\(String(uriage.quantity7))")
            //print("売掛伝票品名ラベル7.text != \(売掛伝票品名ラベル7)")
        }
        if 売掛伝票数量ラベル2.text == "0.0" {
            売掛伝票数量ラベル2.alpha = 0
        }
        if 売掛伝票数量ラベル3.text == "0.0" {
            売掛伝票数量ラベル3.alpha = 0
        }
        if 売掛伝票数量ラベル4.text == "0.0" {
            売掛伝票数量ラベル4.alpha = 0
        }
        if 売掛伝票数量ラベル5.text == "0.0" {
            売掛伝票数量ラベル5.alpha = 0
        }
        if 売掛伝票数量ラベル6.text == "0.0" {
            売掛伝票数量ラベル6.alpha = 0
        }
        if 売掛伝票数量ラベル7.text == "0.0" {
            売掛伝票数量ラベル7.alpha = 0
        }

//unit・単位
        売掛伝票単位ラベル1.text = uriage.unit1
        売掛伝票単位ラベル2.text = uriage.unit2
        売掛伝票単位ラベル3.text = uriage.unit3
        売掛伝票単位ラベル4.text = uriage.unit4
        売掛伝票単位ラベル5.text = uriage.unit5
        売掛伝票単位ラベル6.text = uriage.unit6
        売掛伝票単位ラベル7.text = uriage.unit7
        
        if 売掛伝票単位ラベル1.text != "m³" {
            売掛伝票数量ラベル1.text = ("\(String(Int(uriage.quantity1)))")
        }
        if 売掛伝票単位ラベル2.text != "m³" {
            売掛伝票数量ラベル2.text = ("\(String(Int(uriage.quantity2)))")
        }
        if 売掛伝票単位ラベル3.text != "m³" {
            売掛伝票数量ラベル3.text = ("\(String(Int(uriage.quantity3)))")
        }
        if 売掛伝票単位ラベル4.text != "m³" {
            売掛伝票数量ラベル4.text = ("\(String(Int(uriage.quantity4)))")
        }
        if 売掛伝票単位ラベル5.text != "m³" {
            売掛伝票数量ラベル5.text = ("\(String(Int(uriage.quantity5)))")
        }
        if 売掛伝票単位ラベル6.text != "m³" {
            売掛伝票数量ラベル6.text = ("\(String(Int(uriage.quantity6)))")
        }
        //print("売掛伝票単位ラベル6.text = \(売掛伝票単位ラベル6.text!)")
        if 売掛伝票単位ラベル6.text == nil {
            売掛伝票数量ラベル6.text = ""
        }
        if 売掛伝票単位ラベル7.text != "m³" {
            売掛伝票数量ラベル7.text = ("\(String(Int(uriage.quantity7)))")
        }
            
//MARK: - String単価をIntに変換してカンマを付けます
        let カンマ付き単価ラベル1 = NSNumber(value: uriage.unitPrice1)
        //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        売掛伝票単価ラベル1.text = フォーマッタ.string(from: カンマ付き単価ラベル1)!

        if uriage.unitPrice2 == 0.0 {
            売掛伝票単価ラベル2.text = ""
        } else {
            let カンマ付き単価ラベル2 = NSNumber(value: uriage.unitPrice2)
            //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
            カンマフォーマッタ()
            売掛伝票単価ラベル2.text = フォーマッタ.string(from: カンマ付き単価ラベル2)!
        }
        
        if uriage.unitPrice3 == 0.0 {
            売掛伝票単価ラベル3.text = ""
        } else {
            let カンマ付き単価ラベル3 = NSNumber(value: uriage.unitPrice3)
            カンマフォーマッタ()
            売掛伝票単価ラベル3.text = フォーマッタ.string(from: カンマ付き単価ラベル3)!
        }

        if uriage.unitPrice4 == 0.0 {
            売掛伝票単価ラベル4.text = ""
        } else {
            let カンマ付き単価ラベル4 = NSNumber(value: uriage.unitPrice4)
            カンマフォーマッタ()
            売掛伝票単価ラベル4.text = フォーマッタ.string(from: カンマ付き単価ラベル4)!
        }
        
        //print("uriage.unitPrice5 = \(uriage.unitPrice5)")
        if uriage.unitPrice5 == 0.0 {
            売掛伝票単価ラベル5.text = ""
        } else {
            let カンマ付き単価ラベル5 = NSNumber(value: uriage.unitPrice5)
            カンマフォーマッタ()
            売掛伝票単価ラベル5.text = フォーマッタ.string(from: カンマ付き単価ラベル5)!
        }

        if uriage.unitPrice6 == 0.0 {
            売掛伝票単価ラベル6.text = ""
        } else {
            let カンマ付き単価ラベル6 = NSNumber(value: uriage.unitPrice6)
            カンマフォーマッタ()
            売掛伝票単価ラベル6.text = フォーマッタ.string(from: カンマ付き単価ラベル6)!
        }
        
//小計を変数に入れる
        売掛伝票小計ラベル1合計 = Int(uriage.total1)
        売掛伝票小計ラベル2合計 = Int(uriage.total2)
        売掛伝票小計ラベル3合計 = Int(uriage.total3)
        売掛伝票小計ラベル4合計 = Int(uriage.total4)
        売掛伝票小計ラベル5合計 = Int(uriage.total5)
        売掛伝票小計ラベル6合計 = Int(uriage.total6)
        
//String小計をIntに変換してカンマを付けている
        
        let カンマ付き小計ラベル1合計 = NSNumber(value: uriage.total1)
        //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        売掛伝票小計ラベル1.text = フォーマッタ.string(from: カンマ付き小計ラベル1合計)!

        if uriage.total2 == 0 {
            売掛伝票小計ラベル2.text = ""
        } else {
            let カンマ付き小計ラベル2合計 = NSNumber(value: uriage.total2)
            カンマフォーマッタ()
            売掛伝票小計ラベル2.text = フォーマッタ.string(from: カンマ付き小計ラベル2合計)!
        }
        
        if uriage.total3 == 0 {
            売掛伝票小計ラベル3.text = ""
        } else {
            let カンマ付き小計ラベル3合計 = NSNumber(value: uriage.total3)
            カンマフォーマッタ()
            売掛伝票小計ラベル3.text = フォーマッタ.string(from: カンマ付き小計ラベル3合計)!
        }

        if uriage.total4 == 0 {
            売掛伝票小計ラベル4.text = ""
        } else {
            let カンマ付き小計ラベル4合計 = NSNumber(value: uriage.total4)
            カンマフォーマッタ()
            売掛伝票小計ラベル4.text = フォーマッタ.string(from: カンマ付き小計ラベル4合計)!
        }

        if uriage.total5 == 0 {
            売掛伝票小計ラベル5.text = ""
        } else {
            let カンマ付き小計ラベル5合計 = NSNumber(value: uriage.total5)
            カンマフォーマッタ()
            売掛伝票小計ラベル5.text = フォーマッタ.string(from: カンマ付き小計ラベル5合計)!
        }

        if uriage.total6 == 0 {
            売掛伝票小計ラベル6.text = ""
        } else {
            let カンマ付き小計ラベル6合計 = NSNumber(value: uriage.total6)
            カンマフォーマッタ()
            売掛伝票小計ラベル6.text = フォーマッタ.string(from: カンマ付き小計ラベル6合計)!
        }
        
        伝票合計Int = Int(uriage.total1 + uriage.total2 + uriage.total3 + uriage.total4 + uriage.total5 + uriage.total6)

        if 売掛伝票顧客ラベル.text == "現金顧客" {
//現金顧客は消費税を計算します
            消費税計算()
        }
        //print("売掛伝票顧客ラベル.text = \(売掛伝票顧客ラベル.text!)")
        
        let カンマ付き金額ラベル合計 = NSNumber(value: 伝票合計Int)
        カンマフォーマッタ()
        売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き金額ラベル合計)!

//品名復元
        品名rowInt = Int(uriage.restoredItemName!)!
//数量復元
        数量rowInt = Int(uriage.restoredQuantity!)!
//単価復元
        単価rowInt = Int(uriage.restoredUnitPrice!)!
        
        年ラベル.text = String(uriage.year)
        月ラベル.text = String(uriage.month)
        日ラベル.text = String(uriage.day)
        
        deleteButton.isEnabled = true
        
        売掛伝票品名入力1 = true//編集なので品名1を入力済にしている
        保存.alpha = 1//編集なので保存ボタンを表示します

    }
// MARK: - 伝票完成()
    func 伝票完成() {
        //print("\(String(describing: 売掛伝票顧客ラベル.text))")
        if 売掛伝票顧客ラベル.text == nil { //これを追加しますunit
            
            保存.alpha = 0 //編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
        
        if 売掛伝票品名ラベル1.text == "" { //これを追加しますunit
            保存.alpha = 0 //編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
        
        if 売掛伝票数量ラベル1.text == String(describing: "") {//これを追加しますunit
            保存.alpha = 0//編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
        
        if 売掛伝票単価ラベル1.text == "" {//これを追加しますunit
            保存.alpha = 0//編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }

        if 売掛伝票単位ラベル1.text == nil {//これを追加しますunit
            保存.alpha = 0//編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
            if 売掛伝票顧客ラベル.text == "現金顧客" {
                売掛伝票品名ラベル7.text = "消費税"
            }
        }
    }

    // MARK: - 関数・顧客品名ピッカー雛形設定()
    func 顧客品名ピッカー雛形設定() {
        //print("通過顧客品名ピッカー雛形設定")
        売掛伝票品名ピッカー部品.delegate = self
        売掛伝票品名ピッカー部品.dataSource = self
        // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
        売掛伝票品名ピッカー部品.selectRow(品名rowInt, inComponent: 0, animated: true)
        売掛伝票品名ピッカー部品.selectRow(数量rowInt, inComponent: 1, animated: false)
        売掛伝票品名ピッカー部品.selectRow(単価rowInt, inComponent: 2, animated: false)
        // 選択中の行をハイライト
        売掛伝票品名ピッカー部品.showsSelectionIndicator = true
    }
    func 初期顧客品名ピッカー雛形設定() {
        //print("通過顧客品名ピッカー雛形設定")
        売掛伝票品名ピッカー部品.delegate = self
        売掛伝票品名ピッカー部品.dataSource = self
        // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
        売掛伝票品名ピッカー部品.selectRow(品名rowInt, inComponent: 0, animated: true)
        売掛伝票品名ピッカー部品.selectRow(数量rowInt, inComponent: 1, animated: false)
        売掛伝票品名ピッカー部品.selectRow(単価rowInt, inComponent: 2, animated: false)
        // 選択中の行をハイライト
        売掛伝票品名ピッカー部品.showsSelectionIndicator = true
    }

    // MARK: - 関数・顧客品名雛形()
    func 顧客品名雛形() {
        //print("通過・顧客品名雛形()")
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            if 伝票現金顧客テキスト入力.text == "(有)クエスト" {
//print("伝票現金顧客テキスト入力.text = \(伝票現金顧客テキスト入力.text!)")
                品名rowInt = 22//上プラ
                数量rowInt = 33//10
                単価rowInt = 14//1700
            }
        }
        if 売掛伝票顧客ラベル.text == "ポラスグランテック株式会社" {
//print("通過・顧客品名雛形()")
            品名rowInt = 0//１号砕石
            数量rowInt = 11//1.0
            単価rowInt =  25//6,400
        }
        if 売掛伝票顧客ラベル.text == "瀬野左官工業所" {
            品名rowInt = 1//川砂
            数量rowInt = 9//0.8
            単価rowInt = 29//8,800
        }
        if 売掛伝票顧客ラベル.text == "株式会社電美" {
            品名rowInt = 21//イイモル
            数量rowInt = 33//10
            単価rowInt = 12//900
        }
        if 売掛伝票顧客ラベル.text == "有限会社萩原工業" {
            品名rowInt = 6//フルイ砂(合)
            数量rowInt = 12//1
            単価rowInt = 20//5,100
        }
        if 売掛伝票顧客ラベル.text == "左官職山田" {
            品名rowInt = 4//中目砂(ヶ)
            数量rowInt = 28//5
            単価rowInt = 8//560
        }
        if 売掛伝票顧客ラベル.text == "株式会社東武園芸" {
            品名rowInt = 1//川砂
            数量rowInt = 10//1.0
            単価rowInt = 22//8,800
        }
        if 売掛伝票顧客ラベル.text == "東武谷内田建設株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "花菱産業株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "宮内建材株式会社" {
            品名rowInt = 16//カラ練り18-0
            数量rowInt = 11//1.0
            単価rowInt = 30//12200
        }
        if 売掛伝票顧客ラベル.text == "太平洋セメント販売株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "豊田建材興業株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "東横建材株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "高村礦材株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "野田(有)福田商店" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "大木建材工業株式会社" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        if 売掛伝票顧客ラベル.text == "矢鋪タイル工業" {
            品名rowInt = 5//フルイ砂
            数量rowInt = 3//0.3
            単価rowInt = 22//9,200
        }
        if 売掛伝票顧客ラベル.text == "草加 宇田川" {
            品名rowInt = 20//イイモル
            数量rowInt = 31//10
            単価rowInt = 4//900
        }
        
        初期顧客品名ピッカー雛形設定()
//print("伝票現金顧客テキスト入力.text = \(伝票現金顧客テキスト入力.text!)")
    }

    // MARK: - 電卓ボタン
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func dateChanged(_ sender: UIDatePicker) {
        // Assign selected date to myDate[]
//print("1dateChanged通過")
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: sender.date)
        if 初期日付ピッカー == 0 {
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
//print("2dateChanged通過")
            myDate[0] = year
            myDate[1] = month
            myDate[2] = day
            年ラベル.text = String(year)
            月ラベル.text = String(month)
            日ラベル.text = String(day)
            }
        }
        if 初期日付ピッカー == 1 {
//print("3dateChanged通過")
            if 売掛伝票顧客ラベル.text == "現金顧客" && 伝票現金顧客テキスト入力.text != "" {
//print("4dateChanged通過")
                売掛伝票顧客ラベル.alpha = 0
                伝票現金顧客テキスト入力.alpha = 1
            }
            if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
//print("5dateChanged通過")
                myDate[0] = year
                myDate[1] = month
                myDate[2] = day
                年ラベル.text = String(year)
                月ラベル.text = String(month)
                日ラベル.text = String(day)
            datePicker.alpha = 0
                if 売掛伝票顧客ラベル.text == "現金顧客" && 伝票現金顧客テキスト入力.text != "" {
                    売掛伝票顧客ラベル.alpha = 0
                    } else {
                    売掛伝票顧客ラベル.alpha = 1
                    }
                
            初期日付ピッカー = 0
            伝票アルファ.alpha = 1
            年ラベル.alpha = 1
            月ラベル.alpha = 1
            日ラベル.alpha = 1
            顧客品名雛形()
            }
        }
//print("6dateChanged通過")
        初期日付ピッカー = 1
    }
    
    @IBAction func categoryChosen1(_ sender: UISegmentedControl) {
        myCategory = 売上締日[sender.selectedSegmentIndex]
        categorySegmentedControl2.selectedSegmentIndex = UISegmentedControlNoSegment
    }
    
    @IBAction func categoryChosen2(_ sender: UISegmentedControl) {
        myCategory = 売上締日[sender.selectedSegmentIndex + 5]
        categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
    }
    
    
// MARK: - エンターキー
    @IBAction func 保存(_ sender: UriageSyUIBounceButton) {
        
        if 売掛伝票顧客ラベル.text == "" { //これを追加します
            return
        }
        
        if 売掛伝票番号ラベル.text == "" { //これを追加します
            return
        }
        
// 品名1の行・dismiss if no cost is input
        if 売掛伝票品名ラベル1.text == "" || 売掛伝票単価ラベル1.text == "" || 売掛伝票数量ラベル1.text == "" || 売掛伝票単位ラベル1.text == nil { //これを追加します
            return
        }
        
        // create new Spending object if nothing is got from segue
        if uriage == nil {
            uriage = Uriage(context: context)
            //print("context = \(context)")
            //print("uriage = \(uriage!)")
        }
        //追加4
        // configure Spending object
        if let uriage = uriage {
            uriage.year = Int16(myDate[0])
            uriage.month = Int16(myDate[1])
            
            uriage.category = myCategory//1
            uriage.cost = 0.0//2
            uriage.day = Int16(myDate[2])//3
            uriage.urikake = 0
            
            
            taisyaku?.category = myCategory
            //print("uriage.category = \(uriage.category!)")
            //print("taisyaku?.category = \(taisyaku?.category!)")
            
            
//伝票の締め日・変数myCategoryはOptional型なので!マークを付けると非Optional型になります
            //print("myCategory = \(myCategory!)")
            

//売掛伝票単価ラベル1.textからカンマを取り除いています
            let カンマ無し単価ラベル1 = 売掛伝票単価ラベル1.text?.replacingOccurrences(of: ",", with: "")
//unitPrice1・単価1
            if let unitPrice1 = Int32(カンマ無し単価ラベル1!) {
                uriage.unitPrice1 = Float(unitPrice1)
                //print("単価1は\(売掛伝票単価ラベル1.text!)")

//name・顧客
                let name = String(売掛伝票顧客ラベル.text!)//ここで追加します
                uriage.name = name
                uriage.nameGenkin = String(伝票現金顧客テキスト入力.text!)
//number・伝票番号
                let number = String(売掛伝票番号ラベル.text!)//ここで追加します
                uriage.number = Int16(number!)!
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    //売掛伝票番号ラベル.text = 伝票番号テキスト入力.text
                    uriage.number = Int16(伝票番号テキスト入力.text!)!
                }
//retailer1・適用1
                //リストには適用1のみが表示されます
                if 適用テキスト1.text == "" {
                    適用テキスト1.text = " "
                }
                let retailer1 = 適用テキスト1.text!//ここで追加します
                uriage.retailer1 = retailer1
                //print("102・適用1は\(適用テキスト1.text!)")
//details1・品名1
                let details1 = String(売掛伝票品名ラベル1.text!)//ここで追加します
                uriage.details1 = details1//5
                //print("103・品名1は\(売掛伝票品名ラベル1.text!)")
//quantity1・数量1
                let quantity1 = String(売掛伝票数量ラベル1.text!)//ここで追加します
                uriage.quantity1 = Float(quantity1!)!
                //print("104・数量1は\(売掛伝票数量ラベル1.text!)")
//total1・小計1の計算式
                uriage.total1 = Int32(Float(unitPrice1) * Float(quantity1!)!)//金額と数量をかけている
                //print("105・小計1は\(uriage.total1)")
//unit1・単位1
                let unit1 = String(売掛伝票単位ラベル1.text!)
                uriage.unit1 = unit1//ここで追加します
                //print("106・単位1は\(売掛伝票単位ラベル1.text!)")

                
                //品名復元を保存
                let restoredItemName = 品名rowString//ここで追加します
                uriage.restoredItemName = restoredItemName
                //数量を復元を保存
                let restoredQuantity = 数量rowString//ここで追加します
                uriage.restoredQuantity = restoredQuantity
                //単価を復元を保存
                let restoredUnitPrice = 単価rowString//ここで追加します
                uriage.restoredUnitPrice = restoredUnitPrice
            }
            
//2行目の追加・ここから
            
            if 売掛伝票品名ラベル2.text != "" {
                //print("2行目以降の追加を通過")
                let details2 = String(売掛伝票品名ラベル2.text!)//ここで追加します
                let カンマ無し単価ラベル2 = 売掛伝票単価ラベル2.text?.replacingOccurrences(of: ",", with: "")
                let unit2 = String(売掛伝票単位ラベル2.text!)
                uriage.unit2 = unit2
                if let unitPrice2 = Int32(カンマ無し単価ラベル2!) {
                    uriage.unitPrice2 = Float(unitPrice2)
                    uriage.details2 = details2
                    let quantity2 = String(売掛伝票数量ラベル2.text!)
                    uriage.quantity2 = Float(quantity2!)!
                    uriage.total2 = Int32(Float(unitPrice2) * Float(quantity2!)!)
                }
                
                if 適用テキスト2.text == "" {
                    適用テキスト2.text = " "
                }
                let retailer2 = 適用テキスト2.text!
                uriage.retailer2 = retailer2
            }

            if uriage.total2 == 0 {
                //print("uriage.total2 = \(uriage.total2)")
                uriage.details2 = ""
            }
//2行目の追加・ここまで

//3行目の追加・ここから
            //print("売掛伝票品名ラベル3.text != \(売掛伝票品名ラベル3.text!)")

            if 売掛伝票品名ラベル3.text != "" {
                //print("3行目以降の追加を通過")
                let details3 = String(売掛伝票品名ラベル3.text!)//ここで追加します
                let カンマ無し単価ラベル3 = 売掛伝票単価ラベル3.text?.replacingOccurrences(of: ",", with: "")
                let unit3 = String(売掛伝票単位ラベル3.text!)
                uriage.unit3 = unit3//ここで追加します
                if let unitPrice3 = Int32(カンマ無し単価ラベル3!) {
                    uriage.unitPrice3 = Float(unitPrice3)
                    uriage.details3 = details3
                    let quantity3 = String(売掛伝票数量ラベル3.text!)//ここで追加します
                    uriage.quantity3 = Float(quantity3!)!
                    uriage.total3 = Int32(Float(unitPrice3) * Float(quantity3!)!)
                }
                
                if 適用テキスト3.text == "" {
                    適用テキスト3.text = " "
                }
                let retailer3 = 適用テキスト3.text!//ここで追加します
                uriage.retailer3 = retailer3
            }
            if uriage.total3 == 0 {
                //print("uriage.total3 = \(uriage.total3)")
                uriage.details3 = ""
                uriage.unit3 = ""
            }
//3行目の追加・ここまで

//4行目の追加・ここから
            if 売掛伝票品名ラベル4.text != "" { //これを追加します
                //print("4行目以降の追加を通過")
                let details4 = String(売掛伝票品名ラベル4.text!)
                let カンマ無し単価ラベル4 = 売掛伝票単価ラベル4.text?.replacingOccurrences(of: ",", with: "")
                let unit4 = String(売掛伝票単位ラベル4.text!)
                uriage.unit4 = unit4
                if let unitPrice4 = Int32(カンマ無し単価ラベル4!) {
                    uriage.unitPrice4 = Float(unitPrice4)
                    uriage.details4 = details4
                    let quantity4 = String(売掛伝票数量ラベル4.text!)//ここで追加します
                    uriage.quantity4 = Float(quantity4!)!
                    uriage.total4 = Int32(Float(unitPrice4) * Float(quantity4!)!)
                }
                if 適用テキスト4.text == "" {
                    適用テキスト4.text = " "
                }
                let retailer4 = 適用テキスト4.text!//ここで追加します
                uriage.retailer4 = retailer4
            }
            if uriage.total4 == 0 {
                //print("uriage.total4 = \(uriage.total4)")
                uriage.details4 = ""
                uriage.unit4 = ""
            }
//4行目の追加・ここまで
            
//5行目の追加・ここから
            if 売掛伝票品名ラベル5.text != "" { //これを追加します
                //print("5行目以降の追加を通過")
                let details5 = String(売掛伝票品名ラベル5.text!)
                let カンマ無し単価ラベル5 = 売掛伝票単価ラベル5.text?.replacingOccurrences(of: ",", with: "")
                let unit5 = String(売掛伝票単位ラベル5.text!)
                uriage.unit5 = unit5
                if let unitPrice5 = Int32(カンマ無し単価ラベル5!) {
                    uriage.unitPrice5 = Float(unitPrice5)
                    uriage.details5 = details5
                    let quantity5 = String(売掛伝票数量ラベル5.text!)//ここで追加します
                    uriage.quantity5 = Float(quantity5!)!
                    uriage.total5 = Int32(Float(unitPrice5) * Float(quantity5!)!)
                }
                if 適用テキスト5.text == "" {
                    適用テキスト5.text = " "
                }
                let retailer5 = 適用テキスト5.text!//ここで追加します
                uriage.retailer5 = retailer5
            }
            if uriage.total5 == 0 {
                //print("uriage.total5 = \(uriage.total5)")
                uriage.details5 = ""
                uriage.unit5 = ""
            }
//5行目の追加・ここまで
            
//6行目の追加・ここから
            if 売掛伝票品名ラベル6.text != "" { //これを追加します
                //print("6行目以降の追加を通過")
                if 売掛伝票品名ラベル6.text != nil {
                    let details6 = String(売掛伝票品名ラベル6.text!)
                    let カンマ無し単価ラベル6 = 売掛伝票単価ラベル6.text?.replacingOccurrences(of: ",", with: "")
                    
                    if 売掛伝票単位ラベル6.text != nil {
                        let unit6 = String(売掛伝票単位ラベル6.text!)
                        uriage.unit6 = unit6
                    }
                    
                    if let unitPrice6 = Int32(カンマ無し単価ラベル6!) {
                        uriage.unitPrice6 = Float(unitPrice6)
                        uriage.details6 = details6
                        let quantity6 = String(売掛伝票数量ラベル6.text!)//ここで追加します
                        uriage.quantity6 = Float(quantity6!)!
                        uriage.total6 = Int32(Float(unitPrice6) * Float(quantity6!)!)
                    }
                }
                
                if 適用テキスト6.text == "" {
                    適用テキスト6.text = " "
                }
                let retailer6 = 適用テキスト6.text!//ここで追加します
                uriage.retailer6 = retailer6
            }
/*            if uriage.total6 == 0 {
                print("uriage.total6 = \(uriage.total6)")
                uriage.details6 = ""
                uriage.unit6 = ""
            }*/
//6行目の追加・ここまで
//7行目の追加・ここから
            if 売掛伝票品名ラベル7.text != "消費税" && 売掛伝票単価ラベル7.text != "" { //これを追加します
                //print("7行目以降の追加を通過")
                let details7 = String(売掛伝票品名ラベル7.text!)
                let カンマ無し単価ラベル7 = 売掛伝票単価ラベル7.text?.replacingOccurrences(of: ",", with: "")
                let unit7 = String(売掛伝票単位ラベル7.text!)
                uriage.unit7 = unit7
                if let unitPrice7 = Int32(カンマ無し単価ラベル7!) {
                    uriage.unitPrice7 = Float(unitPrice7)
                    uriage.details7 = details7
                    let quantity7 = String(売掛伝票数量ラベル7.text!)//ここで追加します
                    uriage.quantity7 = Float(quantity7!)!
                    uriage.total7 = Int32(Float(unitPrice7) * Float(quantity7!)!)
                }
                if 適用テキスト7.text == "" {
                    適用テキスト7.text = " "
                }
                let retailer7 = 適用テキスト7.text!//ここで追加します
                uriage.retailer7 = retailer7
            }
            if uriage.total7 == 0 {
                //print("uriage.total7 = \(uriage.total7)")
                uriage.details7 = ""
                uriage.unit7 = ""
            }
            
//7行目の追加・ここまで
                uriage.total = (uriage.total1 + uriage.total2 + uriage.total3 + uriage.total4 + uriage.total5 + uriage.total6 + uriage.total7)
                uriage.uriagedaka = (uriage.total)
//
            if コメントテキスト6行目入力.text != "" {
                //print("コメントテキストを通過")
                売掛伝票品名ラベル6.text = コメントテキスト6行目入力.text
                let details = String(コメントテキスト6行目入力.text!)
                uriage.details = details
            }
            if 売掛伝票顧客ラベル.text == "現金顧客" {
//現金顧客は消費税を計算します
                uriage.total = Int32(Int(Double(uriage.total) * 1.08))
                uriage.uriagedaka = (uriage.total)
                //print("1通過 \(uriage.total)")
            }
            
                if let uriageCategoryIndex = 売上締日詳細.index(of: (uriage.category!)) {
                    //勘定科目の書き込み・売上現金
                    if uriageCategoryIndex == 0 {
                        uriage.genkin = (uriage.total)
                        taisyaku?.genkin = (uriage.total)
                        //print("2通過 \(uriage.total)")
                    }
                    //勘定科目の書き込み・売掛金
                    if uriageCategoryIndex != 0 {
                        uriage.urikake = (uriage.total)
                        taisyaku?.urikakeTotal = (uriage.total)
                    }
                    //締切日のインデックス表示
                    //print("売上のuriageCategoryIndex = \(uriageCategoryIndex)")
            }
        }
//MARK: - 伝票小計の合計を計算して書き込んでいる
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        dismiss(animated: true, completion: nil)
    }
//追加
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        if let uriage = uriage {
            context.delete(uriage)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func insertNumber(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if costLabel.text == "0" {
            costLabel.text = String(sender.tag)
        } else if placehold {
            costLabel.text = String(sender.tag)
            placehold = false
        } else {
            costLabel.text = costLabel.text! + String(sender.tag)
        }
    }
    
    @IBAction func insert0(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if placehold {
            costLabel.text = "0"
            placehold = false
        } else if costLabel.text != "0" {
            if sender.tag == 11 {
                costLabel.text = costLabel.text! + "00"
            } else {
                costLabel.text = costLabel.text! + "0"
            }
        }
    }
    
    //追加5
    @IBAction func clearButtonTapped(_ sender: Any) {
        costLabel.text = "0"
        multiplyFlag = false
        placehold = false
        multiplyButton.isEnabled = true
        
        //追加しました
        /*顧客名.text = ""
        購入先.text = ""
        詳細.text = ""*/
    }
    
    @IBAction func multiplyButtonTapped(_ sender: Any) {
        multiplyFlag = true
        placehold = true
        multiplyButton.isEnabled = false
        edNumber = Int(costLabel.text!)!
    }
    
    @IBAction func equalButtonTapped(_ sender: Any) {
        if multiplyFlag {
            costLabel.text = String(edNumber * Int(costLabel.text!)!)
            multiplyFlag = false
            multiplyButton.isEnabled = true
        }
    }

    // MARK: - 売掛顧客ピッカー
    @IBAction func 売掛伝票顧客ピッカー(_ sender: UIButton) {
        
        if 売掛伝票顧客入力 {
            if 売掛伝票顧客ピッカー部品.alpha == 0 {
                売掛伝票顧客ピッカー部品.alpha = 1
//print("売掛伝票顧客入力通過")
                売掛伝票顧客ラベル.alpha = 0
                売掛伝票番号入力 = false
                年ラベル.alpha = 0.1
                月ラベル.alpha = 0.1
                日ラベル.alpha = 0.1
                伝票アルファ.alpha = 0.3
            } else {
                売掛伝票顧客ピッカー部品.alpha = 0
                売掛伝票顧客ラベル.alpha = 1
                売掛伝票番号入力 = true
		売掛伝票顧客入力済 = true
                年ラベル.alpha = 1
                月ラベル.alpha = 1
                日ラベル.alpha = 1
                伝票アルファ.alpha = 1
            }
        }
    }
    
    // MARK: - 伝票日付ピッカー
    @IBAction func 売上伝票日付ピッカー(_ sender: UIButton) {
        伝票現金顧客テキスト入力.alpha = 0
        if 売掛伝票日付入力 {
//print("1売上伝票日付ピッカー通過")
            売掛伝票日付入力 = false
            伝票アルファ.alpha = 0.3

            売掛伝票顧客ラベル.alpha = 0
            年ラベル.alpha = 0
            月ラベル.alpha = 0
            日ラベル.alpha = 0
            datePicker.alpha = 1
            
            } else {
                売掛伝票日付入力 = true
                datePicker.alpha = 0
//print("2売上伝票日付ピッカー通過")
            伝票現金顧客テキスト入力.alpha = 1
        }
    }
    
    // MARK: - 伝票番号ピッカー
    @IBAction func 売掛伝票番号ピッカー(_ sender: UIButton) {
        if 売掛伝票番号入力 {
            if 売掛伝票番号ピッカー部品.alpha == 0 {
                売掛伝票番号ピッカー部品.alpha = 1
                売掛伝票番号ラベル.alpha = 0
                売掛伝票顧客入力 = false
                伝票アルファ.alpha = 0.3
            } else {
                伝票番号入力終了()
            }
        }
    }
    
    //参考サイトhttps://blog.77jp.net/uipickerview-swift-japanese-document-xcode
    // MARK: - 売掛伝票品名ピッカー1
    @IBAction func 売掛伝票品名ピッカー1(_ sender: UIButton) {

        if 売掛伝票品名入力1 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 104, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                //売掛伝票品名ラベル1.tag = 1
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル1.alpha = 0
                売掛伝票数量ラベル1.alpha = 0
                売掛伝票単価ラベル1.alpha = 0
                伝票アルファ.alpha = 0.3
                顧客品名雛形()
            } else { if (売掛伝票品名ラベル1.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 1
                    売掛伝票品名ピッカー部品.alpha = 0

                
                売掛伝票品名入力済1 = true
                売掛伝票品名入力2 = true
                
                    売掛伝票品名ラベル1.alpha = 1
                    売掛伝票数量ラベル1.alpha = 1
                    売掛伝票単価ラベル1.alpha = 1
                    伝票アルファ.alpha = 1
                売掛伝票品名入力済1 = true
                ビッカー変更 = true
                //print("通過")
//MARK: - 伝票完成()
            伝票完成()

//売掛伝票単価ラベル1.textからカンマを取り除いています
                売掛伝票単価ラベル1.text = 売掛伝票単価ラベル1.text?.replacingOccurrences(of: ",", with: "")
                
//伝票小計1の合計を計算しています
                売掛伝票小計ラベル1合計 = Int(Float(売掛伝票数量ラベル1.text!)! * Float(売掛伝票単価ラベル1.text!)!)
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計
                //print("伝票合計Int = \(伝票合計Int)")
                
                if 売掛伝票顧客ラベル.text == "現金顧客" {
//現金顧客は消費税を計算します
                    消費税計算()
                }

                //参考サイトhttp://pebble8888.hatenablog.com/entry/2015/07/23/114459

                let カンマ付き小計ラベル1 = NSNumber(value: 売掛伝票小計ラベル1合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル1.text = フォーマッタ.string(from: カンマ付き小計ラベル1)!
                
                let カンマ付き合計ラベル = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き合計ラベル)!

                let カンマ変換 = Int(売掛伝票単価ラベル1.text!)
                //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
                カンマフォーマッタ()
                売掛伝票単価ラベル1.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
// MARK: - 新規伝票入力合計計算・ここまで
                
                入力済()

            if 売掛伝票品名入力済2 {
                売掛伝票品名入力3 = true
            }
            if 売掛伝票品名入力済3 {
                売掛伝票品名入力4 = true
            }
            if 売掛伝票品名入力済4 {
                売掛伝票品名入力5 = true
            }
            if 売掛伝票品名入力済5 {
                売掛伝票品名入力6 = true
            }
            if 売掛伝票品名入力済6 {
                売掛伝票品名入力7 = true
            }
                }
            }
        }
    }
    
    @IBAction func 売掛伝票品名ピッカー2(_ sender: UIButton) {
        if 売掛伝票品名入力2 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 127, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル2.alpha = 0
                売掛伝票数量ラベル2.alpha = 0
                売掛伝票単価ラベル2.alpha = 0
                伝票アルファ.alpha = 0.3
            } else { if (売掛伝票品名ラベル2.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                売掛伝票品名入力済2 = true
                    売掛伝票品名入力3 = true
                
                売掛伝票品名入力1 = true
                売掛伝票品名入力2 = true
                売掛伝票品名入力3 = true

                    売掛伝票品名ラベル2.alpha = 1
                    売掛伝票数量ラベル2.alpha = 1
                    売掛伝票単価ラベル2.alpha = 1
                売掛伝票小計ラベル2.alpha = 1
                    伝票アルファ.alpha = 1
                ビッカー変更 = true

// MARK: - 単価ラベル2からカンマを取り去ります
                売掛伝票単価ラベル2.text = 売掛伝票単価ラベル2.text?.replacingOccurrences(of: ",", with: "")
// MARK: - 数量ラベル2 × 単価ラベル2 = 売掛伝票小計ラベル2小計を計算しています
                売掛伝票小計ラベル2合計 = Int(Float(売掛伝票数量ラベル2.text!)! * Float(売掛伝票単価ラベル2.text!)!)
                let カンマ付き小計ラベル2小計 = NSNumber(value: 売掛伝票小計ラベル2合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル2.text = フォーマッタ.string(from: カンマ付き小計ラベル2小計)!
                
// MARK: - //伝票小計2の合計を計算しています
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    消費税計算()
                }
// MARK: - 売掛伝票合計ラベルの値にカンマを付ける
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!

//不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル2.text!)
                //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
                カンマフォーマッタ()
                売掛伝票単価ラベル2.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
                
                
                if 売掛伝票品名入力済3 {
                    売掛伝票品名入力4 = true
                }
                if 売掛伝票品名入力済4 {
                    売掛伝票品名入力5 = true
                }
                if 売掛伝票品名入力済5 {
                    売掛伝票品名入力6 = true
                }
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    
    @IBAction func 売掛伝票品名ピッカー3(_ sender: UIButton) {
        if 売掛伝票品名入力3 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 149, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false
                
                売掛伝票品名ラベル3.alpha = 0
                売掛伝票数量ラベル3.alpha = 0
                売掛伝票単価ラベル3.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル3.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                売掛伝票品名入力済3 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力4 = true

                    売掛伝票品名ラベル3.alpha = 1
                    売掛伝票数量ラベル3.alpha = 1
                    売掛伝票単価ラベル3.alpha = 1
                    伝票アルファ.alpha = 1
                ビッカー変更 = true

//3行目を追加・ここから
//単価ラベル3からカンマを取り去ります
                売掛伝票単価ラベル3.text = 売掛伝票単価ラベル3.text?.replacingOccurrences(of: ",", with: "")
//数量ラベル3 × 単価ラベル3 = 売掛伝票小計ラベル3小計を計算しています
                売掛伝票小計ラベル3合計 = Int(Float(売掛伝票数量ラベル3.text!)! * Float(売掛伝票単価ラベル3.text!)!)
                let カンマ付き小計ラベル3小計 = NSNumber(value: 売掛伝票小計ラベル3合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル3.text = フォーマッタ.string(from: カンマ付き小計ラベル3小計)!
                
//伝票小計3の合計を計算しています
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計 + 売掛伝票小計ラベル3合計
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    消費税計算()
                }
                // MARK: - 売掛伝票合計ラベルの値にカンマを付ける
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!
                
                //不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル3.text!)
                //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
                カンマフォーマッタ()
                売掛伝票単価ラベル3.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
//3行目を追加・ここまで
                if 売掛伝票品名入力済4 {
                    売掛伝票品名入力5 = true
                }
                if 売掛伝票品名入力済5 {
                    売掛伝票品名入力6 = true
                }
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー4(_ sender: UIButton) {
        if 売掛伝票品名入力4 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 171.5, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル4.alpha = 0
                売掛伝票数量ラベル4.alpha = 0
                売掛伝票単価ラベル4.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル4.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                売掛伝票品名入力済4 = true
                    売掛伝票品名入力3 = true
                    売掛伝票品名入力5 = true
                
                    売掛伝票品名ラベル4.alpha = 1
                    売掛伝票数量ラベル4.alpha = 1
                    売掛伝票単価ラベル4.alpha = 1
                    伝票アルファ.alpha = 1
                ビッカー変更 = true
                
//4行目を追加・ここから
                //単価ラベル4からカンマを取り去ります
                売掛伝票単価ラベル4.text = 売掛伝票単価ラベル4.text?.replacingOccurrences(of: ",", with: "")
                //数量ラベル4 × 単価ラベル4 = 売掛伝票小計ラベル4小計を計算しています
                売掛伝票小計ラベル4合計 = Int(Float(売掛伝票数量ラベル4.text!)! * Float(売掛伝票単価ラベル4.text!)!)
                let カンマ付き小計ラベル4小計 = NSNumber(value: 売掛伝票小計ラベル4合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル4.text = フォーマッタ.string(from: カンマ付き小計ラベル4小計)!
                
                //伝票小計4の合計を計算しています
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計 + 売掛伝票小計ラベル3合計 + 売掛伝票小計ラベル4合計
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    消費税計算()
                }
                // MARK: - 売掛伝票合計ラベルの値にカンマを付ける
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!
                
                //不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル4.text!)
                //class KUViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
                カンマフォーマッタ()
                売掛伝票単価ラベル4.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
//4行目を追加・ここまで
                
                if 売掛伝票品名入力済5 {
                    売掛伝票品名入力6 = true
                }
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー5(_ sender: UIButton) {
        if 売掛伝票品名入力5 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 194, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル5.alpha = 0
                売掛伝票数量ラベル5.alpha = 0
                売掛伝票単価ラベル5.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル5.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力3 = true
                売掛伝票品名入力済5 = true
                    売掛伝票品名入力4 = true
                    売掛伝票品名入力6 = true
                
                    売掛伝票品名ラベル5.alpha = 1
                    売掛伝票数量ラベル5.alpha = 1
                    売掛伝票単価ラベル5.alpha = 1
                    伝票アルファ.alpha = 1
                ビッカー変更 = true
                
//5行目を追加・ここから
                売掛伝票単価ラベル5.text = 売掛伝票単価ラベル5.text?.replacingOccurrences(of: ",", with: "")
                売掛伝票小計ラベル5合計 = Int(Float(売掛伝票数量ラベル5.text!)! * Float(売掛伝票単価ラベル5.text!)!)
                let カンマ付き小計ラベル5小計 = NSNumber(value: 売掛伝票小計ラベル5合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル5.text = フォーマッタ.string(from: カンマ付き小計ラベル5小計)!
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計 + 売掛伝票小計ラベル3合計 + 売掛伝票小計ラベル4合計 + 売掛伝票小計ラベル5合計
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    消費税計算()
                }
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!
                
                //不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル5.text!)
                カンマフォーマッタ()
                売掛伝票単価ラベル5.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
//5行目を追加・ここまで
                
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー6(_ sender: UIButton) {
        if 売掛伝票品名入力6 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 216.5, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル6.alpha = 0
                売掛伝票数量ラベル6.alpha = 0
                売掛伝票単価ラベル6.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル6.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力3 = true
                    売掛伝票品名入力4 = true
                    売掛伝票品名入力5 = true
                売掛伝票品名入力済6 = true
                    売掛伝票品名入力7 = true

                    売掛伝票品名ラベル6.alpha = 1
                    売掛伝票数量ラベル6.alpha = 1
                    売掛伝票単価ラベル6.alpha = 1
                    伝票アルファ.alpha = 1
                ビッカー変更 = true
                
//6行目を追加・ここから
                売掛伝票単価ラベル6.text = 売掛伝票単価ラベル6.text?.replacingOccurrences(of: ",", with: "")
                売掛伝票小計ラベル6合計 = Int(Float(売掛伝票数量ラベル6.text!)! * Float(売掛伝票単価ラベル6.text!)!)
                let カンマ付き小計ラベル6小計 = NSNumber(value: 売掛伝票小計ラベル6合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル6.text = フォーマッタ.string(from: カンマ付き小計ラベル6小計)!
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計 + 売掛伝票小計ラベル3合計 + 売掛伝票小計ラベル4合計 + 売掛伝票小計ラベル5合計 + 売掛伝票小計ラベル6合計
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    消費税計算()
                }
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!
                
                //不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル6.text!)
                カンマフォーマッタ()
                売掛伝票単価ラベル6.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
//6行目を追加・ここまで
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー7(_ sender: UIButton) {
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            return
        }
        if 売掛伝票品名入力7 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 239.5, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力済7 = true
                
                売掛伝票品名ラベル7.alpha = 0
                売掛伝票数量ラベル7.alpha = 0
                売掛伝票単価ラベル7.alpha = 0
        } else { if (売掛伝票品名ラベル7.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力3 = true
                    売掛伝票品名入力4 = true
                    売掛伝票品名入力5 = true
                    売掛伝票品名入力6 = true
                
                    売掛伝票品名ラベル7.alpha = 1
                    売掛伝票数量ラベル7.alpha = 1
                    売掛伝票単価ラベル7.alpha = 1
                    伝票アルファ.alpha = 1
                ビッカー変更 = true
//7行目を追加・ここから
                売掛伝票単価ラベル7.text = 売掛伝票単価ラベル7.text?.replacingOccurrences(of: ",", with: "")
                売掛伝票小計ラベル7合計 = Int(Float(売掛伝票数量ラベル7.text!)! * Float(売掛伝票単価ラベル7.text!)!)
                let カンマ付き小計ラベル7小計 = NSNumber(value: 売掛伝票小計ラベル7合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル7.text = フォーマッタ.string(from: カンマ付き小計ラベル7小計)!
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計 + 売掛伝票小計ラベル3合計 + 売掛伝票小計ラベル4合計 + 売掛伝票小計ラベル5合計 + 売掛伝票小計ラベル6合計 + 売掛伝票小計ラベル7合計
                if 売掛伝票顧客ラベル.text == "現金顧客" {
                    消費税計算()
                }
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!
                
                //不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル7.text!)
                カンマフォーマッタ()
                売掛伝票単価ラベル7.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
//7行目を追加・ここまで
                
                }
            }
        }
    }
    
    func 消費税計算() {
        let 消費税 = Int(Double(伝票合計Int) * 消費税率)
        伝票合計Int = Int(Double(伝票合計Int) * (消費税率 + 1))
        let カンマ付き小計ラベル7 = NSNumber(value: 消費税)
        カンマフォーマッタ()
        売掛伝票小計ラベル7.text = フォーマッタ.string(from: カンマ付き小計ラベル7)!
        売掛伝票品名ラベル7.text = "消費税"
    }
    
    func カンマフォーマッタ() {
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
    }
    
//画面拡大と移動
    @IBAction func 画像拡大(_ sender: UIPinchGestureRecognizer) {
        if(sender.state == UIGestureRecognizerState.began){
            //ピンチ開始時のアフィン変換をクラス変数に保持する。
            startTransform = View拡大.transform
        }
        //ピンチ開始時のアフィン変換を引き継いでアフィン変換を行う。
        View拡大.transform = startTransform.scaledBy(x: sender.scale, y: sender.scale)
    }

    @IBAction func 画像移動(_ sender: UIPanGestureRecognizer) {
        //print("パン通過しました")
        //移動量を取得する。
        let move:CGPoint = sender.translation(in: view)
        
        //ドラッグした部品の座標に移動量を加算する。
        sender.view!.center.x += move.x
        sender.view!.center.y += move.y
        
        //参考サイト http://stackoverflow.com/questions/37946990/cgrectmake-cgpointmake-cgsizemake-cgrectzero-cgpointzero-is-unavailable-in-s
        //移動量を0にする。
        sender.setTranslation(CGPoint.zero, in:view)
    }
//ここまで
}
