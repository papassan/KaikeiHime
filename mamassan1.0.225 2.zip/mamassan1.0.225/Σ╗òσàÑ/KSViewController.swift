//
//  RootViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/23.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

//参考サイトhttps://github.com/MasayaHayashi724

import UIKit

var 仕入締日詳細 = ["現金", "20日", "25日", "末日", "随時", "支払い", "交通費"]
var 仕入締日 = ["現金", "20日", "25日", "末日", "随時", "支払い", "交通費"]

class KSViewController: UIViewController, UIPageViewControllerDelegate {

    var pageViewController: UIPageViewController?


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Configure the page view controller and add it as a child view controller.
        //参考サイトhttp://hack-it-iron.hatenablog.com/entry/2015/07/15/102631
        //.horizontal水平と.vrticalで垂直の設定です
        self.pageViewController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: ./*vertical*/horizontal, options: nil)
        self.pageViewController!.delegate = self
		
		// get current month
		let dataComps = Calendar.current.dateComponents([.year, .month], from: Date())
//ここKSDataViewController
        let startingViewController: KSDataViewController = modelController.viewControllerAtIndex(dataComps.month! - 1, dataComps.year! - 2010, storyboard: storyboard!)!
        let viewControllers = [startingViewController]
        pageViewController!.setViewControllers(viewControllers, direction: .forward, animated: false, completion: {done in })

        pageViewController!.dataSource = modelController

        addChildViewController(pageViewController!)
        view.addSubview(pageViewController!.view)

        // Set the page view controller's bounds using an inset rect so that self's view is visible around the edges of the pages.
        var pageViewRect = view.bounds
        if UIDevice.current.userInterfaceIdiom == .pad {
            pageViewRect = pageViewRect.insetBy(dx: 40.0, dy: 40.0)
        }
        pageViewController!.view.frame = pageViewRect
        pageViewController!.didMove(toParentViewController: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//ここKSPageController
    var modelController: KSPageController {
        // Return the model controller object, creating it if necessary.
        // In more complex implementations, the model controller may be passed to the view controller.
        if _modelController == nil {
//ここKSPageController
            _modelController = KSPageController()
        }
        return _modelController!
    }
//ここKSPageController
    var _modelController: KSPageController? = nil

    // MARK: - UIPageViewController delegate methods

    func pageViewController(_ pageViewController: UIPageViewController, spineLocationFor orientation: UIInterfaceOrientation) -> UIPageViewControllerSpineLocation {
        if (orientation == .portrait) || (orientation == .portraitUpsideDown) || (UIDevice.current.userInterfaceIdiom == .phone) {
            // In portrait orientation or on iPhone: Set the spine position to "min" and the page view controller's view controllers array to contain just one view controller. Setting the spine position to 'UIPageViewControllerSpineLocationMid' in landscape orientation sets the doubleSided property to true, so set it to false here.
            let currentViewController = self.pageViewController!.viewControllers![0]
            let viewControllers = [currentViewController]
            self.pageViewController!.setViewControllers(viewControllers, direction: .forward, animated: true, completion: {done in })

            self.pageViewController!.isDoubleSided = false
            return .min
        }

        // In landscape orientation: Set set the spine location to "mid" and the page view controller's view controllers array to contain two view controllers. If the current page is even, set it to contain the current and next view controllers; if it is odd, set the array to contain the previous and current view controllers.
//ここKSDataViewController
        let currentViewController = self.pageViewController!.viewControllers![0] as! KSDataViewController
        var viewControllers: [UIViewController]

        let indexOfCurrentViewController = modelController.monthIndexOfViewController(currentViewController)
        if (indexOfCurrentViewController == 0) || (indexOfCurrentViewController % 2 == 0) {
            let nextViewController = modelController.pageViewController(self.pageViewController!, viewControllerAfter: currentViewController)
            viewControllers = [currentViewController, nextViewController!]
        } else {
            let previousViewController = modelController.pageViewController(self.pageViewController!, viewControllerBefore: currentViewController)
            viewControllers = [previousViewController!, currentViewController]
        }
        self.pageViewController!.setViewControllers(viewControllers, direction: .forward, animated: true, completion: {done in })

        return .mid
    }
}

