//
//  DataViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/27.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit
import CoreData

// MARK: - Global Variables
var sumCost = 0.0

class pKHDataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
//外部CSVへ保存する//ここまで
    //外部CSV部活配列
    var dataList1:[String] = []
    var dataList2:[String] = []
    var dataList4:[String] = []
    var dataList4_0:[String] = []
    var dataList4_1:[String] = []
    
    
//参考サイトhttps://swiftrithm.com/collection-arrays/
    var strArray = ["Google", "Apple", "Facebook"]
    
    //var csvArray = [Dictionary<String, String>]()
    //var csvArray:[String] = []
    
//二次元配列・初期化
    //var csvArray = [String:[String]]()
    var csvArray = [[String]]()
    var ピッカー売掛伝票入金csv = [[String]]()
    //var ピッカー売掛伝票入金csv: [[String]] = [[],[]]

//多次元配列・宣言方法
//参考サイトhttp://qiita.com/art_526/items/9282b63f51d85f58c3e5
    var dataList3 = [[String]]()
    
    var データリスト:[String] = []
    //CSVファイルの保存先
    var userPath1:String!
    var userPath2:String!
    var userPath3:String!
    var userPath4:String!
    
    
    var ユーザパス:String!
    
    let fileManager = FileManager()
//ここまで
    
//1外部CSVへ保存する
    //参考サイトhttps://stackoverflow.com/questions/40222530/how-to-export-core-data-to-csv-in-swift-3

    var export: String = NSLocalizedString("", comment: "")
    var エクスポート: String = NSLocalizedString("", comment: "")
    //var export: String = NSLocalizedString("itemID, productName, Amount \n", comment: "")
    
//ここまで
    
    //管理オブジェクトコンテキスト
    var managedContext: NSManagedObjectContext!
    
    @IBOutlet weak var Barタイトル: UINavigationItem!
    @IBOutlet weak var 日付ラベル: UILabel!
    @IBOutlet weak var testTableView: UITableView!
    
    
    // MARK: - Properties
    
    
    //@IBOutlet weak var myView: UIView!
    
    var spendingTableView: UITableView!
    var sumCostLabel: UILabel!
    var categoryButtons: [UIButton] = []
    
    var sumCost = 0.0
    
    var dataListカウント1 = 0
    var dataListカウント2 = 0
    var dataListカウント3 = 0
    var 売掛伝票入金カウント = 0
    var データリストカウント = 0
    
    // MARK: -
    
    var year: String = ""
    var month: String = ""
    
    // MARK: -
    
    let segueEditSpendingViewController = "SegueEditSpendingViewController"
    let segueAddSpendingViewController = "SegueAddSpendingViewController"
    
    // MARK: - Properties for Fetching
    
    var monthData:[String] = {
        var monthData:[String] = []
        let dateFormatter = DateFormatter()
        monthData = dateFormatter.monthSymbols
        return monthData
    }()
    //ここkaikeiHimes
    //ここKaikeiHime
    var kaikeiHimes: [KaikeiHime] = []
    var retreatedSpendings: [KaikeiHime] = []
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        strArray += ["Twitter"]
        strArray.append("Instagram")
        //print("strArray = \(strArray)")
        
        csvToArray()

//外部CSV読み込み
        do {

            //ユーザーが保存したCSVファイルのパス
            //userPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/KaikeiHime.csv"
            
            userPath1 = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/UrikakeDenpyoNyukin1.csv"
            var path1 = userPath1
            if (fileManager.fileExists(atPath: path1!) == false) {
                //ユーザーが保存したCSVファイルが無い場合は、初期CSVファイルから読み込む。
                //path = Bundle.main.path(forResource: "KaikeiHime", ofType: "csv")!
                path1 = Bundle.main.path(forResource: "UrikakeDenpyoNyukin1", ofType: "csv")!
            }
            userPath2 = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/UrikakeDenpyoNyukin2.csv"
            var path2 = userPath2
            if (fileManager.fileExists(atPath: path2!) == false) {
                //ユーザーが保存したCSVファイルが無い場合は、初期CSVファイルから読み込む。
                //path = Bundle.main.path(forResource: "KaikeiHime", ofType: "csv")!
                path2 = Bundle.main.path(forResource: "UrikakeDenpyoNyukin2", ofType: "csv")!
            }
            userPath3 = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/UrikakeDenpyoNyukin3.csv"
            var path3 = userPath3
            if (fileManager.fileExists(atPath: path3!) == false) {
                //ユーザーが保存したCSVファイルが無い場合は、初期CSVファイルから読み込む。
                //path = Bundle.main.path(forResource: "KaikeiHime", ofType: "csv")!
                path3 = Bundle.main.path(forResource: "UrikakeDenpyoNyukin3", ofType: "csv")!
            }
            userPath4 = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/UrikakeDenpyoNyukin4.csv"
            var path4 = userPath4
            if (fileManager.fileExists(atPath: path4!) == false) {
                path4 = Bundle.main.path(forResource: "UrikakeDenpyoNyukin4", ofType: "csv")!
            }

//ユーザーが保存したxmlファイルのパス
            ユーザパス = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] + "/KaikeiHime108.xml"
            
            var パス = ユーザパス
            
            if (fileManager.fileExists(atPath: パス!) == false) {
                //ユーザーが保存したCSVファイルが無い場合は、初期CSVファイルから読み込む。
                パス = Bundle.main.path(forResource: "KaikeiHime108", ofType: "xml")!
            }

//CSVファイルのデータを取得する・UrikakeDenpyoNyukin2.csv
            let csvData1 = try String(contentsOfFile:path1!, encoding:String.Encoding.utf8)
//改行区切りでデータを分割して配列に格納する。
            //dataList = csvData.components(separatedBy: .newlines)//改行で分割
            //dataList1 = csvData1.components(separatedBy: "\n")//改行で分割
            //dataList1 = csvData1.components(separatedBy: ",")//カンマで分割
            dataList1 = csvData1.components(separatedBy: .whitespaces)//空白で分割
            //dataList1 = csvData1.components(separatedBy: "1")//1で分割
            //let dataList1変更:String = dataList1
            //let dataList1代入 = dataList1変更.components(separatedBy: "1")//1で分割
            //print("dataList1代入 = \(dataList1代入)")
            //dataList1 = csvData1.characters.split { $0 == "," }.map(String.init)//カンマで分割
            
            
            let csvData2 = try String(contentsOfFile:path2!, encoding:String.Encoding.utf8)
//改行区切りでデータを分割して配列に格納する。
            dataList2 = csvData2.components(separatedBy: .newlines)
            //dataList2 = csvData2.components(separatedBy: "\n")
            

            let csvData3 = try String(contentsOfFile:path3!, encoding:String.Encoding.utf8)
            //dataList3 = csvData3.components(separatedBy: .whitespaces)//空白で分割
            //csvファイルを改行区切りで配列に格納
            //print("csvData3 = \(csvData3)")
            let csvData3再変更 = csvData3.components(separatedBy: "4")
            let csvData3分割 = csvData3再変更.joined(separator: "\n")
//参考サイトhttp://qiita.com/MTattin/items/bf32562cd7d03c49026f
//参考サイトhttp://qiita.com/eKushida/items/e7dac249cf406ea3ce85
            let Substring: String = "1234567890"
//先頭から？文字 - 結果・先頭から何文字 = 12345
            let 先頭から何文字 = Substring.substring(to: Substring.index(Substring.startIndex, offsetBy: 5))
            //print("先頭から何文字 = \(先頭から何文字)\n")
//末尾から？文字 - 結果・末尾から何文字 = 67890
            let 末尾から何文字 = Substring.substring(from: Substring.index(Substring.endIndex, offsetBy: -5))
            //print("末尾から何文字 = \(末尾から何文字)\n")
            //let csvData4で分割 = csvData3分割.characters.split { $0 == "4" }.map(String.init)
            //let csvDataカンマで分割 = csvData4で分割.joined(separator: ",")
//先頭から3文字〜末尾から3文字の範囲 - 結果・末尾から何文字 = 先頭3文字から末尾3文字の範囲 = 4567
            let 先頭3文字から末尾3文字の範囲 = Substring.substring(with: Substring.index(Substring.startIndex, offsetBy: 3) ..< Substring.index(Substring.endIndex, offsetBy: -3))
            //print("先頭3文字から末尾3文字の範囲 = \(先頭3文字から末尾3文字の範囲)\n")
            
            
            let 配列1 = csvData3.substring(to: csvData3.index(csvData3.startIndex, offsetBy:29))
            //print("配列1 = \(配列1)\n")
            let 配列1分割 = 配列1.components(separatedBy: "\n")//改行で分割
            
            let 配列2 = csvData3.substring(from: csvData3.index(csvData3.endIndex, offsetBy: -72))
            //print("配列2 = \(配列2)\n")
            let 配列2分割 = 配列2.components(separatedBy: "\n")//改行で分割
//特定の文字で分割
            let 特定の数字で分割 = Substring.characters.split{$0 == "4"}.map(String.init)
            //print("特定の数字で分割 = \(特定の数字で分割)\n")
//参考サイトhttps://i-app-tec.com/ios/string-split.html
            //let 配列特定の数字で分割 = csvData3.characters.split{$0 == "4"}.map(String.init)
            let 配列特定の数字で分割 = csvData3.components(separatedBy: "@")
            //print("csvData3 = \(csvData3)\n")
            //print("配列特定の数字で分割 = \(配列特定の数字で分割)\n")
            

            let 特定の数字で分割1改行を取り除く = 配列特定の数字で分割[0].components(separatedBy: "\n")//改行で分割
            let 特定の数字で分割2改行を取り除く = 配列特定の数字で分割[1].components(separatedBy: "\n")//改行で分割
            
            //let csvData4 = try String(contentsOfFile:path4!, encoding:String.Encoding.utf8)
            //改行区切りでデータを分割して配列に格納する。
            //ピッカー売掛伝票入金csv = csvData4.components(separatedBy: .newlines)
            
            do {
//csvのファイルのデータを所得
                let csvData4 = try String(contentsOfFile:path4!, encoding:String.Encoding.utf8)
                //print("csvData4 = \(csvData4)\n")
//csvファイルを改行区切りで配列に格納
                let csvArr = csvData4.components(separatedBy: .newlines)
                for csvFile in csvArr {
//csvファイルをカンマ区切りで多次元配列に格納
                    let csvSplit = csvFile.components(separatedBy: ",")
                    //print("csvSplit = \(csvSplit)\n")
//初期化方法・var csvArray = [[String]]()
                    ピッカー売掛伝票入金csv.append(csvSplit)
//csvデータ・改行までが一つの配列になります、改行が二つあるので配列は2つになります
//普通預金,現金,当座預金,相殺,空白でsplitしています
//三菱東京UFJ,栃木銀行越谷西支店,楽天,埼玉りそな越谷,栃木銀行越谷西支店空調,埼玉りそな越谷空調,現金,当座預金,改行でsplitしています
//結果・ピッカー売掛伝票入金csv = [["普通預金", "現金", "当座預金", "相殺", "空白でsplitしています"], ["三菱東京UFJ", "栃木銀行越谷西支店", "楽天", "埼玉りそな越谷", "栃木銀行越谷西支店空調", "埼玉りそな越谷空調", "現金", "当座預金", "改行でsplitしています"]]
                }
                //print("ピッカー売掛伝票入金csv = \(ピッカー売掛伝票入金csv)\n")
                //print("csvSplit1[0] = \(csvSplit1[0])\n")
            } catch let error as NSError { 
                print(error.localizedDescription) 
            }
            
//多次元配列の保存変換
            let csvData4 = try String(contentsOfFile:path4!, encoding:String.Encoding.utf8)
            dataList4 = csvData4.components(separatedBy: .newlines)
            //print("dataList4 = \(dataList4)\n")
            //print("dataList4[0] = \(dataList4[0])\n")
            

            let arr = ",追加しました"
            dataList4[0] += arr
            //print("dataList4[0] + arr = \(dataList4[0])\n")
            //print("dataList4[1] = \(dataList4[1])\n")
            //dataList4_0 = dataList4[0].components(separatedBy: ",")
            //dataList4_1 = dataList4[1].components(separatedBy: ",")
            //print("dataList4_0 = \(dataList4_0)\n")
            //print("dataList4_1 = \(dataList4_1)\n")
            dataList4 = [dataList4[0],dataList4[1]]
            //print("dataList4 = \(dataList4)\n")
            
            //for dataList4For in csvData1.characters {
                //print("dataList4For = \(dataList4For)")
            //}
            
//多次元配列
            //ピッカー売掛伝票入金csv
            
            dataList3 = [配列1分割]
            //dataList4 = 配列2分割
            
            dataListカウント1 = dataList1.count
            dataListカウント2 = dataList2.count
            dataListカウント3 = dataList3.count
            売掛伝票入金カウント = 売掛伝票入金.count
            
            //売掛伝票入金 = [(dataList1),(dataList2)]
            //売掛伝票入金 = [dataList1,dataList2]
            //売掛伝票入金 = [配列1分割,配列2分割]
            //売掛伝票入金 = [特定の数字で分割1改行を取り除く,特定の数字で分割2改行を取り除く]
            売掛伝票入金 = ピッカー売掛伝票入金csv
            
            //print("dataListカウント1 = \(dataListカウント1)")
            //print("dataListカウント2 = \(dataListカウント2)")
            //print("dataListカウント3 = \(dataListカウント3)")
            //print("dataListカウント3 = \(dataListカウント3)")
            //print("売掛伝票入金カウント = \(売掛伝票入金.count)")
            //print("dataList1 = \(dataList1)")
            //print("dataList1の2番目は\((dataList1[2]))です")
            //print("dataList2 = \(dataList2)")
            //print("dataList3 = \(dataList3)\n")
            //print("dataList4 = \(dataList4)")
            //print("csvData3再変更 = \(csvData3再変更)")
            print("売掛伝票入金 = \(売掛伝票入金)\n")
//多次元配列の一つを削除して普通の配列にする
            売掛伝票入金.remove(at: 0)
            print("売掛伝票入金.remove(at: 0) = \(売掛伝票入金)\n")
            
//参考サイトhttp://h4s.hatenablog.com/entry/2015/01/15/155834
//多次元配列は以下で表示させます
// 多次元配列へアクセス
    //最初のインディックス[0]は最初の配列を表します
    //2番目のインデックス[0]は配列内のインデックスです
            //結果・売掛伝票入金[0][0] = 普通預金
            //print("売掛伝票入金[0][0] = \(売掛伝票入金[0][0])\n")
            
            var サンプル配列 = [10, 20, 30]
// 代入
            サンプル配列[0...1] = [15, 25]
        //結果・サンプル配列[0...1] = [15, 25, 30]
            //print("サンプル配列[0...1] = \(サンプル配列)\n")
        //結果・サンプル配列[1...2] = [25, 30]
            //print("サンプル配列[1...2] = \(サンプル配列[1...2])\n")
            
// インデックス番号と値を取り出す
        //結果・
            //(index, value) = (0, 15)
            //(index, value) = (1, 25)
            //(index, value) = (2, 30)
            
            for (index, value) in サンプル配列.enumerated() {
                print("(index, value) = \((index, value))") // 結果：(0, 11) (1, 20)  (2, 30)
            }
            
            let xmlData = try String(contentsOfFile:パス!, encoding:String.Encoding.utf8)
            
            
            
            //参考サイトhttps://i-app-tec.com/ios/string-split.html
            データリスト = xmlData.components(separatedBy: "\n")
            データリストカウント = データリスト.count
//print("\nデータリストカウント = \(データリストカウント)\n")
//print("データリスト = \(データリスト)")
            
//let 空白リスト = xmlData.components(separatedBy: ";")
//print("\n空白リスト = \(空白リスト)")
            
            //print("\(String(describing: dataList))")
            
            //CSVファイルの出力先を確認する。
//print("CSVファイルの出力先は\n\(userPath1!)\n")
//print("CSVファイルの出力先は\n\(userPath2!)\n")
//print("CSVファイル4の出力先は\n\(userPath4!)\n")
            
        } catch {
            print(error)
        }
//ここまで
        
        self.日付ラベル!.text = "\(month), \(year)"
/*
//参考サイトhttp://joyplot.com/documents/2016/10/14/swift-file-send-recieve/
        // Documentディレクトリ
        let documentDir = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, .userDomainMask, true).last!
        
        // 送信するファイル名
        let filename = "KaikeiHime108.xml"
        
        // 送信ファイルのパス
        let targetDirPath = "\(documentDir)/\(filename)"
        
//print("targetDirPathは\(targetDirPath)\n")
        
        let documentInteraction = UIDocumentInteractionController(url: URL(fileURLWithPath: targetDirPath))
 
        if !documentInteraction.presentOpenInMenu(from: self.view.frame, in: self.view, animated: true) {
            // 送信できるアプリが見つからなかった時の処理
            let alert = UIAlertController(title: "送信失敗", message: "ファイルを送れるアプリが見つかりません", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
*/
    }
//ここまでviewDidLoad()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchSpendings()
        calculatePercentPerCategory()
//viewWillAppearへ遷移した場合はTableViewはreloadする必要があります
        testTableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        //print("viewWillDisappear() is 別の画面に遷移する直前")
        sumCost = 0.0
        //export = ""
    }
    
    func csvToArray () {
        //csvのファイルパスを取得
        if let csvPath = Bundle.main.path(forResource: "smple", ofType: "csv") {
            do {
                //csvのファイルのデータを所得
                let csvStr = try String(contentsOfFile:csvPath, encoding:String.Encoding.utf8)
                //csvファイルを改行区切りで配列に格納
                let csvArr = csvStr.components(separatedBy: .newlines)
                for csvFile in csvArr {
                    //csvファイルをカンマ区切りで多次元配列に格納
                    let csvSplit = csvFile.components(separatedBy: ",")
                    //print("csvSplit = \(csvSplit)")
                    
//初期化方法・var csvArray = [[String]]()
                    csvArray.append(csvSplit)
//結果・csvArray = [["1", "3A", "野球部"], ["2", "2B", "サッカー部"], ["3", "6C", "テニス部"]]
//上記と同じ結果                    csvArray += [csvSplit]
                    
//初期化方法・var csvArray = [String:[String]]()
                    //csvArray[csvSplit[0]] = [csvSplit[1],csvSplit[2]]//←ここでエラーが出ます
//結果・csvArray = ["2": ["2B", "サッカー部"], "1": ["3A", "野球部"], "3": ["6C", "テニス部"]]
                    //csvArray[csvSplit[0]] = [csvSplit[0],csvSplit[1],csvSplit[2]]
//結果・csvArray = ["2": ["2", "2B", "サッカー部"], "1": ["1", "3A", "野球部"], "3": ["3", "6C", "テニス部"]]
                    //print("csvSplit[0] = \(csvSplit[0])")
                    //print("csvSplit = \(csvSplit)")//←ここでcsvSplitをprintしています。csvArrayではありません。
                }
                //print("csvArray = \(csvArray)")
            } catch let error as NSError { 
                print(error.localizedDescription) 
            } 
        } 
    }
    
//参考サイトhttps://stackoverflow.com/questions/35931946/basic-example-for-sharing-text-or-image-with-uiactivityviewcontroller-in-swift
    @IBAction func sharetext(_ sender: UIButton) {
        // text to share
        let text = "This is some text that I want to share."
        
        // set up activity view controller
        let textToShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        
        // exclude some activity types from the list (optional)
        activityViewController.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook ]
        
        // present the view controller
        present(activityViewController, animated: true, completion: nil)
    }
//参考サイトhttp://yuu.1000quu.com/how_to_use_uiactivityviewcontroller
    @IBAction func shareimage(_ sender: UIButton) {
        // image to share
        let image = UIImage(named: "02")
        
        // set up activity view controller
        let imageToShare = [ image! ]
        let activityViewController = UIActivityViewController(activityItems: imageToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        
        // exclude some activity types from the list (optional)
        activityViewController.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook ]
        
        // present the view controller
        present(activityViewController, animated: true, completion: nil)
    }
//ここまで
//参考サイトhttp://qiita.com/ken0nek/items/d32fce3c7d2123dfbaed
    
    @IBAction func CSV外部へ保存(_ sender: UIButton) {
        saveCSV()
    }
    
    //外部CSVへ保存する
    //CSVファイル保存メソッド
    func saveCSV() {
        
        //改行区切りで部活配列を連結する。
        let outputStr1 = dataList1.joined(separator: "\n")
        //let outputStr1 = 売掛伝票入金.joined().map { $0 }
        let outputStr4 = dataList4.joined(separator: "\n")//ピッカー売掛伝票入金csv
        
        do {
            if(outputStr1 == "") {
                //部活配列が空の場合はユーザーが保存したCSVファイルを削除する。
                try fileManager.removeItem(atPath: userPath1)
            } else {
                //ファイルを出力する。
                try outputStr1.write(toFile: userPath1, atomically: false, encoding: String.Encoding.utf8 )
            }
        } catch {
            print(error)
        }
        do {
            if(outputStr4 == "") {
                //部活配列が空の場合はユーザーが保存したCSVファイルを削除する。
                try fileManager.removeItem(atPath: userPath4)
            } else {
                //ファイルを出力する。
                try outputStr4.write(toFile: userPath4, atomically: false, encoding: String.Encoding.utf8 )
            }
        } catch {
            print(error)
        }
    }
    //ここまで
    
    @IBAction func 外部へ保存(_ sender: UIButton) {
        exportDatabase()
    }

    func exportDatabase() {
        let exportString = エクスポート
        saveAndExport(exportString: exportString)
    }
    
    func saveAndExport(exportString: String) {
        let exportFilePath = NSTemporaryDirectory() + "KaikeiHime108.xml"
        //let exportFilePath = NSTemporaryDirectory() + "KaikeiHime108.csv"
        let exportFileURL = NSURL(fileURLWithPath: exportFilePath)
        FileManager.default.createFile(atPath: exportFilePath, contents: NSData() as Data, attributes: nil)
        //var fileHandleError: NSError? = nil
        var fileHandle: FileHandle? = nil
        do {
            fileHandle = try FileHandle(forWritingTo: exportFileURL as URL)
        } catch {
            print("Error with fileHandle")
        }

        if fileHandle != nil {
            fileHandle!.seekToEndOfFile()
            let csvData = exportString.data(using: String.Encoding.utf8, allowLossyConversion: false)
            fileHandle!.write(csvData!)
            fileHandle!.closeFile()

            let firstActivityItem = NSURL(fileURLWithPath: exportFilePath)
            let activityViewController = UIActivityViewController(
                activityItems: [firstActivityItem], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
            
            activityViewController.excludedActivityTypes = [
                UIActivityType.assignToContact,
                UIActivityType.saveToCameraRoll,
                UIActivityType.postToFlickr,
                UIActivityType.postToVimeo,
                UIActivityType.postToTencentWeibo
            ]
            
            present(activityViewController, animated: true, completion: nil)
        }
//xmlファイルの出力先を確認する。
//print(exportFilePath)
    }
    
    func calculatePercentPerCategory() {
        var percents: [Double] = {
            var percents: [Double] = []
            //ここ会計姫categories
            for _ in 0..<会計姫categories.count {
                percents.append(0.0)
            }
            return percents
        }()
        
//ここkaikeiHimes
        for kaikeiHime in kaikeiHimes {
//ここ会計姫categories
            
            if let categoryIndex = 会計姫categories.index(of: kaikeiHime.category!) {
                
                percents[categoryIndex] += Double(kaikeiHime.cost)
                sumCost += Double(kaikeiHime.cost)
            }
        }
        
        for i in 0..<percents.count {
            percents[i] /= sumCost
        }
        
        var percentsPerCategory: [(category: String, percent: Double)] = []
        //ここ会計姫categories
        for i in 0..<percents.count {
            percentsPerCategory.append((category: 会計姫categories[i], percent: percents[i]))
        }
    }

    func fetchSpendings() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
//ここKaikeiHime
//ここKaikeiHime
//参考サイトhttp://qiita.com/fromage-blanc/items/7f058a81afed2d6d91e5
            let fetchRequest: NSFetchRequest<KaikeiHime> = KaikeiHime.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "day", ascending: true), NSSortDescriptor(key: "cost", ascending: false), NSSortDescriptor(key: "total", ascending: false), NSSortDescriptor(key: "kaikake", ascending: false), NSSortDescriptor(key: "shiiredaka", ascending: false), NSSortDescriptor(key: "genkin", ascending: false), NSSortDescriptor(key: "touza", ascending: false), NSSortDescriptor(key: "futsuu", ascending: false), NSSortDescriptor(key: "category", ascending: false), NSSortDescriptor(key: "hoken", ascending: false), NSSortDescriptor(key: "tsuushin", ascending: false), NSSortDescriptor(key: "gasoline", ascending: false), NSSortDescriptor(key: "suidou", ascending: false), NSSortDescriptor(key: "sozei", ascending: false), NSSortDescriptor(key: "jimu", ascending: false), NSSortDescriptor(key: "bihin", ascending: false), NSSortDescriptor(key: "ryohi", ascending: false), NSSortDescriptor(key: "syuuzen", ascending: false), NSSortDescriptor(key: "zattsu", ascending: false), NSSortDescriptor(key: "mibarai", ascending: false), NSSortDescriptor(key: "azukari", ascending: false), NSSortDescriptor(key: "choukikariire", ascending: false), NSSortDescriptor(key: "kyuuryou", ascending: false), NSSortDescriptor(key: "yakuin", ascending: false), NSSortDescriptor(key: "taisyoku", ascending: false), NSSortDescriptor(key: "koukoku", ascending: false), NSSortDescriptor(key: "kaigi", ascending: false), NSSortDescriptor(key: "syaryou", ascending: false), NSSortDescriptor(key: "syokai", ascending: false), NSSortDescriptor(key: "shiharaite", ascending: false), NSSortDescriptor(key: "nameKarikata1", ascending: false), NSSortDescriptor(key: "nameKashikata1", ascending: false), NSSortDescriptor(key: "nameKashikata2", ascending: false), NSSortDescriptor(key: "kariBumon1", ascending: false), NSSortDescriptor(key: "kariBumon2", ascending: false), NSSortDescriptor(key: "kariBumon3", ascending: false), NSSortDescriptor(key: "kariBumon4", ascending: false), NSSortDescriptor(key: "kariBumon5", ascending: false), NSSortDescriptor(key: "kariBumon6", ascending: false), NSSortDescriptor(key: "kariBumon7", ascending: false), NSSortDescriptor(key: "kariHojyo1", ascending: false), NSSortDescriptor(key: "kariHojyo2", ascending: false), NSSortDescriptor(key: "kariHojyo3", ascending: false), NSSortDescriptor(key: "kariHojyo4", ascending: false), NSSortDescriptor(key: "kariHojyo5", ascending: false), NSSortDescriptor(key: "kariHojyo6", ascending: false), NSSortDescriptor(key: "kariHojyo7", ascending: false), NSSortDescriptor(key: "kashiBumon1", ascending: false), NSSortDescriptor(key: "kashiBumon2", ascending: false), NSSortDescriptor(key: "kashiHojyo1", ascending: false), NSSortDescriptor(key: "kashiHojyo2", ascending: false), NSSortDescriptor(key: "kariTotal1", ascending: false), NSSortDescriptor(key: "kariTotal2", ascending: false), NSSortDescriptor(key: "kariTotal3", ascending: false), NSSortDescriptor(key: "kariTotal4", ascending: false), NSSortDescriptor(key: "kariTotal5", ascending: false), NSSortDescriptor(key: "kariTotal6", ascending: false), NSSortDescriptor(key: "kariTotal7", ascending: false), NSSortDescriptor(key: "kashiTotal1", ascending: false), NSSortDescriptor(key: "kashiTotal2", ascending: false), NSSortDescriptor(key: "kashiTotal3", ascending: false), NSSortDescriptor(key: "kashiTotal4", ascending: false), NSSortDescriptor(key: "kashiTotal5", ascending: false), NSSortDescriptor(key: "kashiTotal6", ascending: false), NSSortDescriptor(key: "kashiTotal7", ascending: false), NSSortDescriptor(key: "kishutana", ascending: false), NSSortDescriptor(key: "shouhin", ascending: false), NSSortDescriptor(key: "kimatsutana", ascending: false), NSSortDescriptor(key: "uketoririsoku", ascending: false)]
            }//mibarai
//ここkaikeiHimes
            kaikeiHimes = try context.fetch(fetchRequest)
            
        } catch {
          print("Spendings Data Fetching Failed.")
        }
    }

    // MARK: - Spending Table View Data Source
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        //設定のTableViewサイズは954です
        let cellRect = CGRect(x: 0, y: 0, width: testTableView.frame.width - 150, height: 30.0)
        let cell = UIView(frame: cellRect)
      
        let sortButtons = UISegmentedControl(items: ["日付順", "金額順", "カテゴリ順"])
        sortButtons.frame.size = CGSize(width: cell.frame.width - 50, height: cell.frame.height)
        sortButtons.center = cell.center
        sortButtons.backgroundColor = self.view.backgroundColor
        sortButtons.tintColor = .orange
        sortButtons.selectedSegmentIndex = 0//初期のボタン選択場所0〜2
        sortButtons.addTarget(self, action: #selector(sortButtonTapped(_:)), for: .valueChanged)
        
        cell.addSubview(sortButtons)
        
// create scost label
        let costLabel = UILabel()
        costLabel.sizeToFit()
        costLabel.font = UIFont.systemFont(ofSize: 24)
//リスト金額にカンマを付けています
        let カンマ付き伝票合計Label = NSNumber(value: sumCost)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        costLabel.text = フォーマッタ.string(from: カンマ付き伝票合計Label)! + "円"

        costLabel.textAlignment = .right
        costLabel.frame = CGRect(x: testTableView.frame.width * 0.635, y: 0.0, width: testTableView.frame.width * 0.35, height: cell.frame.height)
        cell.addSubview(costLabel)
 
        return cell
    }
 
//ここkaikeiHimes
    func sortButtonTapped(_ sortButtons: UISegmentedControl) {
        switch sortButtons.selectedSegmentIndex {
        case 0:
            kaikeiHimes.sort(by: { (kaikeiHime1, kaikeiHime2) -> Bool in
                return kaikeiHime1.day < kaikeiHime2.day
            })
        case 1:
            kaikeiHimes.sort(by: { (kaikeiHime1, kaikeiHime2) -> Bool in
                return kaikeiHime1.cost > kaikeiHime2.cost
            })
        case 2:
            kaikeiHimes.sort(by: { (kaikeiHime1, kaikeiHime2) -> Bool in
                return kaikeiHime1.category! > kaikeiHime2.category!
            })
        default:
            print("default")
        }
        if let indexPathes = testTableView.indexPathsForVisibleRows {
            testTableView.reloadRows(at: indexPathes, with: .automatic)
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//ここkaikeiHimes
        if 他のアプリケーションで開く != "" {
//print("他のアプリケーションで開く != \(他のアプリケーションで開く)")
            //dataListカウント = dataList.count
            dataListカウント1 = kaikeiHimes.count
            
        }
        
        if 他のアプリケーションで開く == "" {
//print("他のアプリケーションで開く == \(他のアプリケーションで開く)")
            dataListカウント1 = kaikeiHimes.count
        }
        //var kaikeiHimes1: [String] = []
        //kaikeiHimes1 = dataList
        //print("\ndataListカウント = \(dataListカウント)\n")
        //print("dataList = \(dataList)\n")
        //print("kaikeiHimes1 = \(kaikeiHimes1)\n")
        //print("kaikeiHimes = \(kaikeiHimes)\n")
        return dataListカウント1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//ここkaikeiHime
//ここkaikeiHimes
        
        let kaikeiHime = kaikeiHimes[indexPath.row]

//セルを取得する。
       let cell = tableView.dequeueReusableCell(withIdentifier: "TestCell", for:indexPath as IndexPath)
 
// Cellにフォント値を設定する
        cell.textLabel?.font = UIFont.systemFont(ofSize: 20)
        cell.textLabel?.text = "\(kaikeiHime.day)日"
        
//参考サイトhttps://i-app-tec.com/ios/tableview.html
// Tag番号 1 で UILabel インスタンスの生成する方法
//すでに自動でtextLabelが生成されていますが独自に生成しました
        
        let label1 = testTableView.viewWithTag(1) as! UILabel
        label1.text = "\(kaikeiHime.day)日"
        
//借方科目1行目の表示

        let 借方科目1行目 = testTableView.viewWithTag(2) as! UILabel
        借方科目1行目.sizeToFit()
        借方科目1行目.font = UIFont.systemFont(ofSize: 24)
        借方科目1行目.frame = CGRect(x: testTableView.frame.width * 0.08, y: 0.0, width: testTableView.frame.width * 0.35, height: cell.frame.height)
        借方科目1行目.textAlignment = .left
        借方科目1行目.text = "\(kaikeiHime.nameKarikata1!)"//ここ
        
        // create category label
        let categoryLabel = testTableView.viewWithTag(3) as! UILabel
        categoryLabel.sizeToFit()
        categoryLabel.frame = CGRect(x: testTableView.frame.width * 0.42, y: 0.0, width: testTableView.frame.width / 2.0, height: cell.frame.height)
        //categoryLabel.textAlignment = .right
        categoryLabel.text = "\(kaikeiHime.category!)"
        
        //print("categoryLabel.text = \(kaikeiHime.category!)")
        if categoryLabel.text == "仕訳の支払い" {
            if 借方科目1行目.text == "給料手当" {
                categoryLabel.text = "給料手当の支払い"
            }
            if 借方科目1行目.text == "役員報酬" {
                categoryLabel.text = "役員報酬の支払い"
            }
            if 借方科目1行目.text == "退職金給付費用" {
                categoryLabel.text = "退職金給付費用の支払い"
            }
            if 借方科目1行目.text == "広告宣伝費" {
                categoryLabel.text = "広告宣伝費の支払い"
            }
            if 借方科目1行目.text == "接待交際費" {
                categoryLabel.text = "接待交際費の支払い"
            }
            if 借方科目1行目.text == "会議費" {
                categoryLabel.text = "会議費の支払い"
            }
            if 借方科目1行目.text == "車両費" {
                categoryLabel.text = "車両費の支払い"
            }
            if 借方科目1行目.text == "諸会費" {
                categoryLabel.text = "諸会費の支払い"
            }
            if 借方科目1行目.text == "支払手数料" {
                categoryLabel.text = "支払手数料の支払い"
            }
            if 借方科目1行目.text == "雑費" {
                categoryLabel.text = "雑費の支払い"
            }
            if 借方科目1行目.text == "期首商品棚卸高" {
                categoryLabel.text = "決算仕訳"
            }
            if 借方科目1行目.text == "商品" {
            categoryLabel.text = "決算仕訳"
            }
        }
        
        
//貸方科目1行目の表示
        let 貸方科目1行目 = testTableView.viewWithTag(4) as! UILabel
        貸方科目1行目.sizeToFit()
        貸方科目1行目.font = UIFont.systemFont(ofSize: 24)
        貸方科目1行目.frame = CGRect(x: testTableView.frame.width * 0.5, y: 0.0, width: testTableView.frame.width * 0.35, height: cell.frame.height)
        //貸方科目1行目.textAlignment = .right
        貸方科目1行目.text = "\(kaikeiHime.nameKashikata1!)"//ここ
        
//リスト金額にカンマを付けています
        let カンマ付き伝票合計Label = NSNumber(value: kaikeiHime.cost)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        //let label2 = testTableView.viewWithTag(2) as! UILabel
        //label2.text = フォーマッタ.string(from: カンマ付き伝票合計Label)! + "円"
        // Cellにフォントカラーを設定する
        cell.detailTextLabel?.textColor = .brown//文字色
        // Cellにフォントサイズを指定する
        cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20)
        cell.detailTextLabel?.text = フォーマッタ.string(from: カンマ付き伝票合計Label)! + "円"
/*
        //var stockStatus
        var stockvar: Bool?
*/
//csv及びxml保存・ここから
//KaikeiHime var
        var 備品var: NSNumber?
        var 詳細var: String?
        var 仕訳合計var: NSNumber?
        var 日var: NSNumber?
        var ガソリン代var: NSNumber?
        var 現金var: NSNumber?
        var 保険料var: NSNumber?
        var 事務用消耗品費var: NSNumber?
        var 会議費var: NSNumber?
        var 買掛金var: NSNumber?
        var 借方部門1var: String?
        var 借方部門2var: String?
        var 借方部門3var: String?
        var 借方部門4var: String?
        var 借方部門5var: String?
        var 借方部門6var: String?
        var 借方部門7var: String?
        var 借方補助1var: String?
        var 借方補助2var: String?
        var 借方補助3var: String?
        var 借方補助4var: String?
        var 借方補助5var: String?
        var 借方補助6var: String?
        var 借方補助7var: String?
        var 借方合計1var: NSNumber?
        var 借方合計2var: NSNumber?
        var 借方合計3var: NSNumber?
        var 借方合計4var: NSNumber?
        var 借方合計5var: NSNumber?
        var 借方合計6var: NSNumber?
        var 借方合計7var: NSNumber?
        var 貸方部門1var: String?
        var 貸方部門2var: String?
        var 貸方補助1var: String?
        var 貸方補助2var: String?
        var 貸方合計1var: NSNumber?
        var 貸方合計2var: NSNumber?
        var 貸方合計3var: NSNumber?
        var 貸方合計4var: NSNumber?
        var 貸方合計5var: NSNumber?
        var 貸方合計6var: NSNumber?
        var 貸方合計7var: NSNumber?
        var 広告宣伝費var: NSNumber?
        var 給料手当var: NSNumber?
        var 月var: NSNumber?
        var 借方科目1行目var: String?
        var 貸方科目1行目var: String?
        var 貸方科目2行目var: String?
        var 旅費交通費var: NSNumber?
        var 接待交際費var: NSNumber?
        var 支払手数料var: NSNumber?
        var 仕入高var: NSNumber?
        var 租税公課var: NSNumber?
        var 水道光熱費var: NSNumber?
        var 車両費var: NSNumber?
        var 諸会費var: NSNumber?
        var 修繕費var: NSNumber?
        var 退職金給付費用var: NSNumber?
        var 合計var: NSNumber?
        var 通信費var: NSNumber?
        var 役員報酬var: NSNumber?
        var 年var: NSNumber?
        var 雑費var: NSNumber?

//KaikeiHime CoreData Attributes
        備品var = kaikeiHime.value(forKey: "bihin") as! NSNumber?
        詳細var = kaikeiHime.value(forKey: "category") as! String?
        仕訳合計var = kaikeiHime.value(forKey: "cost") as! NSNumber?
        日var = kaikeiHime.value(forKey: "day") as! NSNumber?
        ガソリン代var = kaikeiHime.value(forKey: "gasoline") as! NSNumber?
        現金var = kaikeiHime.value(forKey: "genkin") as! NSNumber?
        保険料var = kaikeiHime.value(forKey: "hoken") as! NSNumber?
        事務用消耗品費var = kaikeiHime.value(forKey: "jimu") as! NSNumber?
        会議費var = kaikeiHime.value(forKey: "kaigi") as! NSNumber?
        買掛金var = kaikeiHime.value(forKey: "kaikake") as! NSNumber?
        借方部門1var = kaikeiHime.value(forKey: "kariBumon1") as! String?
        借方部門2var = kaikeiHime.value(forKey: "kariBumon2") as! String?
        借方部門3var = kaikeiHime.value(forKey: "kariBumon3") as! String?
        借方部門4var = kaikeiHime.value(forKey: "kariBumon4") as! String?
        借方部門5var = kaikeiHime.value(forKey: "kariBumon5") as! String?
        借方部門6var = kaikeiHime.value(forKey: "kariBumon6") as! String?
        借方部門7var = kaikeiHime.value(forKey: "kariBumon7") as! String?
        借方補助1var = kaikeiHime.value(forKey: "kariHojyo1") as! String?
        借方補助2var = kaikeiHime.value(forKey: "kariHojyo2") as! String?
        借方補助3var = kaikeiHime.value(forKey: "kariHojyo3") as! String?
        借方補助4var = kaikeiHime.value(forKey: "kariHojyo4") as! String?
        借方補助5var = kaikeiHime.value(forKey: "kariHojyo5") as! String?
        借方補助6var = kaikeiHime.value(forKey: "kariHojyo6") as! String?
        借方補助7var = kaikeiHime.value(forKey: "kariHojyo7") as! String?
        借方合計1var = kaikeiHime.value(forKey: "kariTotal1") as! NSNumber?
        借方合計2var = kaikeiHime.value(forKey: "kariTotal2") as! NSNumber?
        借方合計3var = kaikeiHime.value(forKey: "kariTotal3") as! NSNumber?
        借方合計4var = kaikeiHime.value(forKey: "kariTotal4") as! NSNumber?
        借方合計5var = kaikeiHime.value(forKey: "kariTotal5") as! NSNumber?
        借方合計6var = kaikeiHime.value(forKey: "kariTotal6") as! NSNumber?
        借方合計7var = kaikeiHime.value(forKey: "kariTotal7") as! NSNumber?
        貸方部門1var = kaikeiHime.value(forKey: "kashiBumon1") as! String?
        貸方部門2var = kaikeiHime.value(forKey: "kashiBumon2") as! String?
        貸方補助1var = kaikeiHime.value(forKey: "kashiHojyo1") as! String?
        貸方補助2var = kaikeiHime.value(forKey: "kashiHojyo2") as! String?
        貸方合計1var = kaikeiHime.value(forKey: "kashiTotal1") as! NSNumber?
        貸方合計2var = kaikeiHime.value(forKey: "kashiTotal2") as! NSNumber?
        貸方合計3var = kaikeiHime.value(forKey: "kashiTotal3") as! NSNumber?
        貸方合計4var = kaikeiHime.value(forKey: "kashiTotal4") as! NSNumber?
        貸方合計5var = kaikeiHime.value(forKey: "kashiTotal5") as! NSNumber?
        貸方合計6var = kaikeiHime.value(forKey: "kashiTotal6") as! NSNumber?
        貸方合計7var = kaikeiHime.value(forKey: "kashiTotal7") as! NSNumber?
        広告宣伝費var = kaikeiHime.value(forKey: "koukoku") as! NSNumber?
        給料手当var = kaikeiHime.value(forKey: "kyuuryou") as! NSNumber?
        月var = kaikeiHime.value(forKey: "month") as! NSNumber?
        借方科目1行目var = kaikeiHime.value(forKey: "nameKarikata1") as! String?
        貸方科目1行目var = kaikeiHime.value(forKey: "nameKashikata1") as! String?
        貸方科目2行目var = kaikeiHime.value(forKey: "nameKashikata2") as! String?
        旅費交通費var = kaikeiHime.value(forKey: "ryohi") as! NSNumber?
        接待交際費var = kaikeiHime.value(forKey: "settai") as! NSNumber?
        支払手数料var = kaikeiHime.value(forKey: "shiharaite") as! NSNumber?
        仕入高var = kaikeiHime.value(forKey: "shiiredaka") as! NSNumber?
        租税公課var = kaikeiHime.value(forKey: "sozei") as! NSNumber?
        水道光熱費var = kaikeiHime.value(forKey: "suidou") as! NSNumber?
        車両費var = kaikeiHime.value(forKey: "syaryou") as! NSNumber?
        諸会費var = kaikeiHime.value(forKey: "syokai") as! NSNumber?
        修繕費var = kaikeiHime.value(forKey: "syuuzen") as! NSNumber?
        退職金給付費用var = kaikeiHime.value(forKey: "taisyoku") as! NSNumber?
        合計var = kaikeiHime.value(forKey: "total") as! NSNumber?
        通信費var = kaikeiHime.value(forKey: "tsuushin") as! NSNumber?
        役員報酬var = kaikeiHime.value(forKey: "yakuin") as! NSNumber?
        年var = kaikeiHime.value(forKey: "year") as! NSNumber?
        雑費var = kaikeiHime.value(forKey: "zattsu") as! NSNumber?

        
        //ここまで
        //stockvar = kaikeiHime.value(forKey: "stock") as! Bool?
        //let inventoryDatevar = kaikeiHime.value(forKey: "inventoryDate") as! Date
        
        //KaikeiHime varString
        let 備品String = 備品var
        let 詳細String = 詳細var
        let 仕訳合計String = 仕訳合計var
        let 日String = 日var
        let ガソリン代String = ガソリン代var
        let 現金String = 現金var
        let 保険料String = 保険料var
        let 事務用消耗品費String = 事務用消耗品費var
        let 会議費String = 会議費var
        let 買掛金String = 買掛金var
        let 借方部門1String = 借方部門1var
        let 借方部門2String = 借方部門2var
        let 借方部門3String = 借方部門3var
        let 借方部門4String = 借方部門4var
        let 借方部門5String = 借方部門5var
        let 借方部門6String = 借方部門6var
        let 借方部門7String = 借方部門7var
        let 借方補助1String = 借方補助1var
        let 借方補助2String = 借方補助2var
        let 借方補助3String = 借方補助3var
        let 借方補助4String = 借方補助4var
        let 借方補助5String = 借方補助5var
        let 借方補助6String = 借方補助6var
        let 借方補助7String = 借方補助7var
        let 借方合計1String = 借方合計1var
        let 借方合計2String = 借方合計2var
        let 借方合計3String = 借方合計3var
        let 借方合計4String = 借方合計4var
        let 借方合計5String = 借方合計5var
        let 借方合計6String = 借方合計6var
        let 借方合計7String = 借方合計7var
        let 貸方部門1String = 貸方部門1var
        let 貸方部門2String = 貸方部門2var
        let 貸方補助1String = 貸方補助1var
        let 貸方補助2String = 貸方補助2var
        let 貸方合計1String = 貸方合計1var
        let 貸方合計2String = 貸方合計2var
        let 貸方合計3String = 貸方合計3var
        let 貸方合計4String = 貸方合計4var
        let 貸方合計5String = 貸方合計5var
        let 貸方合計6String = 貸方合計6var
        let 貸方合計7String = 貸方合計7var
        let 広告宣伝費String = 広告宣伝費var
        let 給料手当String = 給料手当var
        let 月String = 月var
        let 借方科目1行目String = 借方科目1行目var
        let 貸方科目1行目String = 貸方科目1行目var
        let 貸方科目2行目String = 貸方科目2行目var
        let 旅費交通費String = 旅費交通費var
        let 接待交際費String = 接待交際費var
        let 支払手数料String = 支払手数料var
        let 仕入高String = 仕入高var
        let 租税公課String = 租税公課var
        let 水道光熱費String = 水道光熱費var
        let 車両費String = 車両費var
        let 諸会費String = 諸会費var
        let 修繕費String = 修繕費var
        let 退職金給付費用String = 退職金給付費用var
        let 合計String = 合計var
        let 通信費String = 通信費var
        let 役員報酬String = 役員報酬var
        let 年String = 年var
        let 雑費String = 雑費var
        
        
        
        
        //ここまで
        //let stockSting = stockvar
        //let inventoryDateSting = "\(inventoryDatevar)"
        
        export += "\(年String!),\(月String!),\(日String!),\(借方科目1行目String!),\(詳細String!),\(貸方科目1行目String!),\(仕訳合計String!) \n"
      
        エクスポート += "<KaikeiHime: 0x60000049d380> (entity: KaikeiHime; id: 0xd0000000001c0000 <x-coredata://2388E9CF-EC12-4DB4-8C47-7E30C9CFCB16/KaikeiHime/p7> ; data: {\nbihin = \(備品String!);\ncategory = \(詳細String!);\ncost = \(仕訳合計String!);\nday = \(日String!);\ngasoline = \(ガソリン代String!);\ngenkin = \(現金String!);\nhoken = \(保険料String!);\njimu = \(事務用消耗品費String!);\nkaigi = \(会議費String!);\nkaikak = \(買掛金String!);\nkariBumon1 = \(借方部門1String!);\nkariBumon2 = \(借方部門2String!);\nkariBumon3 = \(借方部門3String!);\nkariBumon4 = \(借方部門4String!);\nkariBumon5 = \(借方部門5String!);\nkariBumon6 = \(借方部門6String!);\nkariBumon7 = \(借方部門7String!);\nnkariHojyo1 = \(借方補助1String!);\nnkariHojyo2 = \(借方補助2String!);\nnkariHojyo3 = \(借方補助3String!);\nnkariHojyo4 = \(借方補助4String!);\nnkariHojyo5 = \(借方補助5String!);\nnkariHojyo6 = \(借方補助6String!);\nnkariHojyo7 = \(借方補助7String!);\nkariTotal1 = \(借方合計1String!);\nkariTotal2 = \(借方合計2String!);\nkariTotal3 = \(借方合計3String!);\nkariTotal4 = \(借方合計4String!);\nkariTotal5 = \(借方合計5String!);\nkariTotal6 = \(借方合計6String!);\nkariTotal7 = \(借方合計7String!);\nkashiBumon1 = \(貸方部門1String!);\nkashiBumon2 = \(貸方部門2String!);\nkashiHojyo1 = \(貸方補助1String!);\nkashiHojyo2 = \(貸方補助2String!);\nkashiTotal1 = \(貸方合計1String!);\nkashiTotal2 = \(貸方合計2String!);\nkashiTotal3 = \(貸方合計3String!);\nkashiTotal4 = \(貸方合計4String!);\nkashiTotal5 = \(貸方合計5String!);\nkashiTotal6 = \(貸方合計6String!);\nkashiTotal7 = \(貸方合計7String!);\nkoukoku = \(広告宣伝費String!);\nkyuuryou = \(給料手当String!);\nmonth = \(月String!);\nnameKarikata1 = \(借方科目1行目String!);\nnameKashikata1 = \(貸方科目1行目String!);\nnameKashikata2 = \(貸方科目2行目String!);\nryohi = \(旅費交通費String!);\nsettai = \(接待交際費String!);\nshiharaite = \(支払手数料String!);\nshiiredaka = \(仕入高String!);\nsozei = \(租税公課String!);\nsuidou = \(水道光熱費String!);\nsyaryou = \(車両費String!);\nsyokai = \(諸会費String!);\nsyuuzen = \(修繕費String!);\ntaisyoku = \(退職金給付費用String!);\ntotal = \(合計String!);\ntsuushin = \(通信費String!);\nyakuin = \(役員報酬String!);\nyear = \(年String!);\nzattsu = \(雑費String!)\n})"
        
//print("\nCSV書込みの内容は\n\(export)")
//print("\nエクスポート書込みの内容は\n\(エクスポート)")
//csv及びxml保存・ここまで
        //}
        
        
        
        
        
//バックアップからの読み込み・ここから

        if 他のアプリケーションで開く != "" {
//print("\n他のアプリケーションで開く = \(他のアプリケーションで開く)")
            
            //カンマでデータを分割して配列に格納する。
            let dataDetail = String(describing: dataList1[indexPath.row]).components(separatedBy: ",")
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "TestCell", for:indexPath as IndexPath)
            
//print("\n読み込みdataList = \(dataList)")
//print("\n読み込みdataDetail = \(dataDetail)")
            
            // Cellにフォント値を設定する.
            cell.textLabel?.font = UIFont.systemFont(ofSize: 20)
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20)
            
            let label1 = testTableView.viewWithTag(1) as! UILabel
            //label1.text = dataDetail[2] + "日"//1列目・日付
            let 読み込み日付 = Int16(dataDetail[2])//読み込みInt16に変更
            kaikeiHime.day = 読み込み日付!//KaikeiHime entity:kaikeiHime.day
            label1.text = "\(kaikeiHime.day)日"//1列目・日付
            
            
            let 借方科目1行目 = testTableView.viewWithTag(2) as! UILabel
            借方科目1行目.sizeToFit()
            借方科目1行目.font = UIFont.systemFont(ofSize: 24)
            借方科目1行目.frame = CGRect(x: testTableView.frame.width * 0.08, y: 0.0, width: testTableView.frame.width * 0.35, height: cell.frame.height)
            借方科目1行目.textAlignment = .left
            //借方科目1行目.text = dataDetail[3]//2列目・借方科目
            let 読み込み借方科目1行目 = dataDetail[3]//2列目・借方科目
            kaikeiHime.nameKarikata1 = 読み込み借方科目1行目
            借方科目1行目.text = "\(kaikeiHime.nameKarikata1!)"
            
            
            let categoryLabel = testTableView.viewWithTag(3) as! UILabel
            categoryLabel.sizeToFit()
            categoryLabel.frame = CGRect(x: testTableView.frame.width * 0.42, y: 0.0, width: testTableView.frame.width / 2.0, height: cell.frame.height)
            categoryLabel.text = dataDetail[4]//3列目・詳細
            let 読み込みcategoryLabel = dataDetail[4]//3列目・詳細
            kaikeiHime.category = 読み込みcategoryLabel
            categoryLabel.text = "\(kaikeiHime.category!)"
            
            
            
            let 貸方科目1行目 = testTableView.viewWithTag(4) as! UILabel
            貸方科目1行目.sizeToFit()
            貸方科目1行目.font = UIFont.systemFont(ofSize: 24)
            貸方科目1行目.frame = CGRect(x: testTableView.frame.width * 0.5, y: 0.0, width: testTableView.frame.width * 0.35, height: cell.frame.height)
            貸方科目1行目.text = dataDetail[5]//4列目・貸方科目
            let 読み込み貸方科目1行目 = dataDetail[5]//4列目・貸方科目
            kaikeiHime.nameKashikata1 = 読み込み貸方科目1行目
            貸方科目1行目.text = "\(kaikeiHime.nameKashikata1!)"
            
            
            
            let 読み込み振替伝票合計 = Int32(dataDetail[6])//読み込みInt16に変更
            kaikeiHime.cost = Int32(読み込み振替伝票合計!)
            
            //let 読み込み振替伝票合計Label = Int(dataDetail[6])
            let カンマ付き読み込み振替伝票合計Label = NSNumber(value: kaikeiHime.cost)
            フォーマッタ.numberStyle = .decimal
            フォーマッタ.groupingSeparator = ","
            フォーマッタ.groupingSize = 3
            // Cellにフォントカラーを設定する
            cell.detailTextLabel?.textColor = .brown//文字色
            // Cellにフォントサイズを指定する
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 20)
            cell.detailTextLabel?.text = フォーマッタ.string(from: カンマ付き読み込み振替伝票合計Label)! + "円"//5列目・振替合計
    }

//バックアップからの読み込み・ここまで
        return cell
    }
    
    // MARK: - Spending Table View Delegate
    //UITableViewDelegate: セルがタップされたときの処理
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//ここkaikeiHimes
        performSegue(withIdentifier: segueEditSpendingViewController, sender: kaikeiHimes[indexPath.row])
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueEditSpendingViewController {
//ここKHAddViewController
            let destinationViewController = segue.destination as! pKHAddViewController//ここ
//ここkaikeiHime
//ここKaikeiHime
            destinationViewController.kaikeiHime = sender as! KaikeiHime?
        } else if segue.identifier == segueAddSpendingViewController {
//ここKHAddViewController
            let destinationViewController = segue.destination as! pKHAddViewController//ここ
            destinationViewController.myDate[0] = Int(year)!
            if let month = monthData.index(of: month) {
                destinationViewController.myDate[1] = month + 1
            }
        }
    }
}
