//
//  ViewController.swift
//  mamassan
//
//  Created by Toshikazu Fukuda on 2017/06/28.
//  Copyright © 2017年 Toshikazu Fukuda. All rights reserved.
//

//参考サイト http://bamka.info/mac-zipcloak
//zip圧縮パスワードの作成方法
//圧縮したいファイルを圧縮作成する
//ターミナルを起動する
//コマンド : zipcloak ここに圧縮後のフォルダをターミナルにドラッグしてEnterを押します
//「Enter password:」と表示されます、パスワードを入力します
//「Verify password:」と表示されます、再度バスワードを入力するとディスクトップにパスワード付きのZipファイルが作成されます

//隠しフォルダ
//defaults write com.apple.finder AppleShowAllFiles TRUE
//killall Finder
//defaults write com.apple.finder AppleShowAllFiles FALSE

//ここから
//注意:Simulatorで起動時の向き ? 縦か横か ? ホームボタンが右か左か ? について解説します
//最初にプロジェクトを作成した際のProduct Nameを決定する際でDevicesをUniversalに設定する場合の意味は ?
//Universalに設定します、次にアプリ名 -> Targets -> General -> Deployment infoで当然ですがDevices名はUniversalになっているでしょう ?
//ここで起動時のデバイスの向きを設定する場所はDevice Orientationです
//Portraitは縦ホームボタンは下
//Upside DownはPortraitの逆です
//Landscape Leftは当然ですが横向きでホームボタンが左です
//Landscape RightはLandscape Leftの逆です
//問題点 ?
//DevicesがUniversalになっています、Landscape Rightにチェックしてあるので
//起動時はそのようにホームボタンが右の状態になるはず ? しかしなりません ?
//問題点解決 1
//Simulatorで設定しないと反映されません
//Simulator設定は ? Debugタブ -> Rotate Device Automaticallyにチェックする
//問題解決 2
//これだけではダメなんです ? つまり、秘密があるのです
//DevicesがUniversalで作成した場合はiPhoneではDevice Orientation設定は反映されますがiPadではDevices設定をUniversalからiPadに選択してからDevice Orientationにチェックしないと設定できません
//設定後はDevicesをUniversalに戻しましょう
//ここまで

import UIKit
import AVFoundation

var 消費税率 = 0.08

class ViewController: UIViewController {
    
    //これは紐付けなしでOKです
    @IBAction func Viewへ戻る(segue: UIStoryboardSegue) {
    }
    @IBOutlet weak var ホーム画面ページコントロール: UIPageControl!
//AVAudioPlayerを使って以下のログの修正方法
//2017-06-28 10:25:12.350256+0900 mamassan[7763:250701] [aqme] 254: AQDefaultDevice (1): skipping input stream 0 0 0x0
//参考サイトhttps://ameblo.jp/onesscripter/entry-12224327485.html
    var ドラム曲Variable: AVAudioPlayer!
    var ダブルタップカウント = 0
    var scrollView: UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//ドラム曲を演奏する
        ドラム曲再生()
//ジェスチャーを使用します
        tapジェスチャー()
    }
    
    //画面が表示される直前
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        //print("viewWillAppear() is 画面が表示される直前")
    }
    
    //画面が表示された直後
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //print("viewDidAppear() is 画面が表示された直後")
        ドラム曲Variable.play()
    }
    
    //別の画面に遷移する直前
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        //print("viewWillDisappear() is 別の画面に遷移する直前")
    }
    
    //別の画面に遷移した直後
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        // print("viewDidDisappear is 別の画面に遷移した直後")
        ドラム曲Variable.stop()
    }
    
    //レイアウト処理開始前
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        //print("viewWillLayoutSubviews() is レイアウト処理開始前")
    }
    
    //レイアウト処理終了後
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        //print("viewDidLayoutSubviews() is レイアウト処理終了後")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//ドラム曲を演奏する
    func ドラム曲再生() {
        if let musicURL = Bundle.main.url(forResource: "ドラム曲", withExtension: "mp3") {
            if let audioPlayer = try? AVAudioPlayer(contentsOf: musicURL) {
                ドラム曲Variable = audioPlayer
                ドラム曲Variable.numberOfLoops = -1
//音量を調整する。
                ドラム曲Variable.volume = 0.1
                ドラム曲Variable.play()
            }
        }
    }
    
    @IBAction func ホーム画面ページコントロール変更(_ sender: UIPageControl) {
        //スクロールビューのX座標を更新する。
        //scrollView.contentOffset.x = scrollView.frame.maxX * CGFloat(sender.currentPage)
    }
    //2017/5/10.
    @IBAction func 売上へ移動(_ sender: UIButton) {
        let storyboard: UIStoryboard = UIStoryboard(name: "KU", bundle: nil)
        let nextView = storyboard.instantiateInitialViewController() as! KUViewController
        self.present(nextView, animated: true, completion: nil)
    }
    //2017/5/23.
    @IBAction func 決算書へ移動(_ sender: UIButton) {
        let storyboard: UIStoryboard = UIStoryboard(name: "Soa", bundle: nil)
        let nextView = storyboard.instantiateInitialViewController() as! SoaRootViewController
        self.present(nextView, animated: true, completion: nil)
    }
    //2017/5/25.
    @IBAction func 仕入へ移動(_ sender: UIButton) {
        let storyboard: UIStoryboard = UIStoryboard(name: "KS", bundle: nil)
        let nextView = storyboard.instantiateInitialViewController() as! KSViewController
        self.present(nextView, animated: true, completion: nil)
    }
    //2017/5/30.
    @IBAction func p会計姫へ移動(_ sender: UIButton) {
        let storyboard: UIStoryboard = UIStoryboard(name: "pKH", bundle: nil)
        let nextView = storyboard.instantiateInitialViewController() as! pKHViewController
        self.present(nextView, animated: true, completion: nil)
    }
    //2017/6/22.
    @IBAction func 売上締切へ移動(_ sender: UIButton) {
        let storyboard: UIStoryboard = UIStoryboard(name: "KUS", bundle: nil)
        let nextView = storyboard.instantiateInitialViewController() as! KUSViewController
        self.present(nextView, animated: true, completion: nil)
    }
    //2017/6/28.
    @IBAction func テストへ移動(_ sender: UIButton) {
        let storyboard: UIStoryboard = UIStoryboard(name: "testViewController", bundle: nil)
        let nextView = storyboard.instantiateInitialViewController() as! testViewController
        self.present(nextView, animated: true, completion: nil)
    }
    func tapジェスチャー() {
        //3本指ダブルタップ
        let 三本指のdoubleTap = UITapGestureRecognizer(target: self, action: #selector(三本指ダブルタップ(sender:)))
        三本指のdoubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(三本指のdoubleTap)
        三本指のdoubleTap.numberOfTouchesRequired = 3
        
        // ダブルタップ
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(tapDouble(sender:)))  //Swift3
        doubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(doubleTap)
        doubleTap.numberOfTouchesRequired = 1
        
        // シングルタップ
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(tapSingle(sender:)))  //Swift3
        singleTap.numberOfTapsRequired = 1
        view.addGestureRecognizer(singleTap)
        singleTap.numberOfTouchesRequired = 1  //こう書くと2本指じゃないとタップに反応しない
        
        // 右タップ
        //Simulatorでの2本指はoptionキーを押しながら操作します
        let tapRight = UITapGestureRecognizer(target: self, action: #selector(tapRight(sender:)))  //Swift3
        tapRight.numberOfTapsRequired = 1
        tapRight.numberOfTouchesRequired = 2
        view.addGestureRecognizer(tapRight)
        
        
        //これを書かないとダブルタップ時にもシングルタップのアクションも実行される
        singleTap.require(toFail: doubleTap)  //Swift3
        
        
        // ロングプレスを定義
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPressView(sender:)))  //Swift3
        
        longPressGesture.minimumPressDuration = 3  //3秒間以上押された場合にロングプレスとする
        longPressGesture.allowableMovement = 30  //ロングプレスを判定する指が動いていい範囲、単位はpx
        
        self.view.addGestureRecognizer(longPressGesture)
        
        // エッジを定義
        let edgeGesture = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(edgeView(sender:)))   //Swift3
        
        edgeGesture.edges = .left  //左端をスワイプするのを検知する
        
        // viewにエッジを登録
        self.view.addGestureRecognizer(edgeGesture)
        
        // ピンチを定義
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchView(sender:)))  //Swift3
        // viewにピンチを登録
        self.view.addGestureRecognizer(pinchGesture)
    }
    
    //シングルタップ時に実行される
    func tapSingle(sender: UITapGestureRecognizer) {
        
    }
    
    //ダブルタップ時に実行される
    func tapDouble(sender: UITapGestureRecognizer) {
        
        if ダブルタップカウント == 0 {
            //print("ドラム曲が停止しました")
            ドラム曲Variable.stop()
            ダブルタップカウント = 1
        } else {
            ドラム曲Variable.play()
            ダブルタップカウント = 0
            //print("ドラム曲が再生しました")
        }
        
    }
    
    func 三本指ダブルタップ(sender: UITapGestureRecognizer) {
        
    }
    
    //右タップ・2本指です
    func tapRight(sender: UITapGestureRecognizer) {
        
    }
    
    //画面長押し
    func longPressView(sender: UILongPressGestureRecognizer) {
        //print("長押ししました")
        
    }
    
    //エッジ時に実行される
    func edgeView(sender: UIScreenEdgePanGestureRecognizer) {
        exit(0)
    }
    
    //ピンチイン・ピンチアウト時に実行される
    func pinchView(sender: UIPinchGestureRecognizer) {
        
        
        // ピンチイン・ピンチアウトの拡大縮小率
        //print("\nピンチスケール幅は : \(sender.scale)\n")
        //print("\n1秒あたりのピンチの速度 : \(sender.velocity)\n")
    }
    
//参考サイト http://stackoverflow.com/questions/38862208/preferredstatusbarstyle-removed-in-swift-3
//ステイタスバーの設定・ここから
    override var preferredStatusBarStyle: UIStatusBarStyle {
        //return .default//この場合は文字色が黒です
        return .lightContent//この場合は文字色が白です
    }
    //参考サイト http://jpfaw.hateblo.jp/entry/2016/11/04/020852
    //ステイタスバーの表示非表示切替
    override var prefersStatusBarHidden: Bool {
        return false//trueで非表示 falseで表示します、時計の部分です
    }
//ここまで

}

