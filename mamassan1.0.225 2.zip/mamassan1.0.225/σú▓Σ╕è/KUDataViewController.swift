//
//  DataViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/04/14.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit
import CoreData

// MARK: - Global Variables

//let colors: [UIColor] = [.red, .orange, .yellow, .green, .cyan, .magenta, .brown]

var ラスト伝票番号 = 0
var 伝票数 = 0

class KUDataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Properties
    
    @IBOutlet weak var dataLabel: UILabel!
    @IBOutlet weak var myView: UIView!
    var spendingTableView: UITableView!
    var graphView: UIView!
    var sumCostLabel: UILabel!
    var categoryButtons: [UIButton] = []
    
    // MARK: -
    
    var year: String = ""
    var month: String = ""
    
    // MARK: -
    
    let segueEditSpendingViewController = "SegueEditSpendingViewController"
    let segueAddSpendingViewController = "SegueAddSpendingViewController"
    
    // MARK: - Properties for Fetching
    
    var monthData:[String] = {
        var monthData:[String] = []
        let dateFormatter = DateFormatter()
        monthData = dateFormatter.monthSymbols
        return monthData
    }()
//ここuriages
//ここUriage
    var uriages: [Uriage] = []
    var retreatedSpendings: [Uriage] = []
    
    var taisyakus: [Taisyaku] = []//貸借対照表のCoreData
    var sonekis: [Soneki] = []//損益計算書のCoreData
    
    var 検索変更 = true
    
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //tableView.contentOffset.y = aTableCellsHeight
        //print("\nviewDidLoad()通過")
        self.dataLabel!.text = "\(month), \(year)"
        createMyView()
        addButtons()
    }
    
    func カンマフォーマッタ() {
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //print("\nviewWillAppear・ラスト伝票番号は\(ラスト伝票番号)番です\n")
        fetchSpendings()
//ボタンの色
        categoryButtonsAllColored()
//グラフ
        drawPieChart()
    }
    
    func drawPieChart() {
        let center = CGPoint(x: graphView.frame.height / 2, y: graphView.frame.height / 2)
        //グラフ円のサイズ
        let radius: CGFloat = graphView.frame.height * 0.12//2

//ここuriages
        //合計を計算する関数をpercentsPerCategoryに代入している
        let percentsPerCategory = calculatePercentPerCategory(uriages)
        if let graphImageView = drawPieChartImageView(center: center, radius: radius, percentsPerCategory: percentsPerCategory) {
            graphView.addSubview(graphImageView)
        }
    }
    
    func createMyView() {
        // create view for graph
        graphView = UIView()
        let graphViewFrame = CGRect(x: 0.0, y: 0.0, width: myView.frame.width, height: myView.frame.width * 0.2)//0.7・分類とかの幅
        //(0.0, 0.0, 984.0, 295.2)
        
        graphView.frame = graphViewFrame
        myView.addSubview(graphView)
        
        // create label for sum cost
        sumCostLabel = UILabel()
        sumCostLabel.frame = CGRect(x: myView.frame.width * 0.5, y: graphView.frame.height-30.0, width: myView.frame.width * 0.45, height: 30.0)
        sumCostLabel.text = "計 0 円"
        sumCostLabel.backgroundColor = .white
        sumCostLabel.textAlignment = NSTextAlignment.right
        myView.addSubview(sumCostLabel)
        
        // create table view for spendings
        spendingTableView = UITableView()
        let tableViewFrame = CGRect(x: 0.0, y: graphView.frame.maxY, width: myView.frame.width, height: myView.frame.height - graphView.frame.height - 56.8)
        //(0.0, 295.2, 984.0, 406.8)//406.8 - 56.8の意味は引かないとスクロールしなくなる
        //print("tableViewFrame = \(tableViewFrame)")
        //print("myView.frame.width = \(myView.frame.width)")
        
        //画面の左端まで線を到達させる、しかし反応しない
        spendingTableView.layoutMargins = .zero
        spendingTableView.separatorInset = .zero
        spendingTableView.frame = tableViewFrame
        myView.addSubview(spendingTableView)
        spendingTableView.delegate = self
        spendingTableView.dataSource = self
        
    }
    //追加1
    func fetchSpendings() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
//Uriage
//Uriage
            let fetchRequest: NSFetchRequest<Uriage> = Uriage.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                //MARK: - 品名追加1 Attributesを追加する
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "day", ascending: true), NSSortDescriptor(key: "cost", ascending: false), NSSortDescriptor(key: "name", ascending: false), NSSortDescriptor(key: "nameGenkin", ascending: false), NSSortDescriptor(key: "retailer", ascending: false),NSSortDescriptor(key: "retailer1", ascending: false),NSSortDescriptor(key: "retailer2", ascending: false),NSSortDescriptor(key: "retailer3", ascending: false), NSSortDescriptor(key: "details", ascending: false),NSSortDescriptor(key: "details1", ascending: false),NSSortDescriptor(key: "details2", ascending: false), NSSortDescriptor(key: "number", ascending: false), NSSortDescriptor(key: "quantity", ascending: false),NSSortDescriptor(key: "quantity1", ascending: false),NSSortDescriptor(key: "quantity2", ascending: false), NSSortDescriptor(key: "total", ascending: false),NSSortDescriptor(key: "total1", ascending: false),NSSortDescriptor(key: "total2", ascending: false),NSSortDescriptor(key: "total3", ascending: false),NSSortDescriptor(key: "total4", ascending: false),NSSortDescriptor(key: "total5", ascending: false),NSSortDescriptor(key: "total6", ascending: false), NSSortDescriptor(key: "unit", ascending: false),NSSortDescriptor(key: "unit1", ascending: false),NSSortDescriptor(key: "unit2", ascending: false), NSSortDescriptor(key: "restoredItemName", ascending: false), NSSortDescriptor(key: "restoredQuantity", ascending: false), NSSortDescriptor(key: "restoredUnitPrice", ascending: false), NSSortDescriptor(key: "unitPrice", ascending: false), NSSortDescriptor(key: "unitPrice1", ascending: false), NSSortDescriptor(key: "unitPrice2", ascending: false), NSSortDescriptor(key: "genkin", ascending: false), NSSortDescriptor(key: "urikake", ascending: false), NSSortDescriptor(key: "uriagedaka", ascending: false)]//ここで追加します
            }//nameGenkin
            //ここuriages
            uriages = try context.fetch(fetchRequest)
            
        } catch {
            print("Spendings Data Fetching Failed.")
        }
        spendingTableView.reloadData()
    }

    
    func arcPercent(center: CGPoint, radius: CGFloat, startAngle: CGFloat, percent: Double) -> UIBezierPath {
        // draw one arc
        let endAngle = 2 * Double.pi * percent + Double(startAngle)
        //188.8
        //print("endAngle = \(endAngle)")
        let path = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: CGFloat(endAngle), clockwise: true)
        //print("path = \(path)")
        path.lineWidth = radius * 2.0
        path.lineCapStyle = .butt
        return path
    }
//円グラフ表示用のボタン
    func addButtons() {
        for i in 0..<売上締日.count {
            let buttonWidth: CGFloat = graphView.frame.width - graphView.frame.height - 500//40ボタンの幅
            //print("buttonWidth = \(buttonWidth)")
            let buttonHeight: CGFloat = (graphView.frame.height - sumCostLabel.frame.height) / CGFloat(売上締日詳細.count) - CGFloat(売上締日詳細.count + 1) + 10
            //print("buttonHeight = \(buttonHeight)")
            let buttonRect = CGRect(x: graphView.frame.height + 10, y: (buttonHeight + 1.0) * CGFloat(i) + 3.0, width: buttonWidth, height: buttonHeight)
            //print("buttonRect = \(buttonRect)")
            categoryButtons.append(UIBounceButton(frame: buttonRect))
            categoryButtons[i].layer.cornerRadius = 5
            categoryButtons[i].backgroundColor = colors[i]
            categoryButtons[i].setTitle(売上締日[i], for: .normal)
            categoryButtons[i].setTitleColor(.black, for: .normal)
            categoryButtons[i].tag = i
            categoryButtons[i].addTarget(self, action: #selector(self.categoryButtonTapped(_:)), for: .touchUpInside)
            graphView.addSubview(categoryButtons[i])
        }
    }
//ここuriages
//ここuriages
    func categoryButtonTapped(_ sender: UIButton) {
        if sender.backgroundColor != .gray {
            categoryButtons[sender.tag].backgroundColor = .gray
            for i in 0..<uriages.count {
                if uriages[i].category! != 売上締日詳細[sender.tag] {
                    retreatedSpendings.append(uriages[i])
                }
                //print("categoryButtonTapped = \(uriages[i])")
            }
//ここuriages
//ここuriages
            uriages = uriages.filter { $0.category! == 売上締日詳細[sender.tag] }
        } else {
            categoryButtons[sender.tag].backgroundColor = colors[sender.tag]
            for retreatedSpending in retreatedSpendings {
                if retreatedSpending.category! != 売上締日詳細[sender.tag] {
//ここuriages
                    uriages.append(retreatedSpending)
                }
            }
            retreatedSpendings = retreatedSpendings.filter { $0.category! == 売上締日詳細[sender.tag] }

//ここuriages
            uriages.sort(by: {$0.day < $1.day})
        }
        spendingTableView.reloadData()
        drawPieChart()
    }
    
//ボタンの色
    func categoryButtonsAllColored() {
        for i in 0..<categoryButtons.count {
            categoryButtons[i].backgroundColor = colors[i]
        }
    }
    
    
//func drawPieChart()で呼ばれます
//ここUriage
    func calculatePercentPerCategory(_ spendings: [Uriage]) -> [(category: String, percent: Double)] {
        var percents: [Double] = {
            var percents: [Double] = []
            for _ in 0..<売上締日詳細.count {
                percents.append(0.0)
            }
//売上締日詳細配列の総数
            //print("売上締日詳細.count = \(売上締日詳細.count)")
            //print("percents = \(percents)")
            return percents
        }()
        var sumCost = 0.0
        
        //totalの合計を計算している
//ここuriages
        for uriage in uriages {
            if let categoryIndex = 売上締日詳細.index(of: uriage.category!) {
                percents[categoryIndex] += Double(uriage.total)
                sumCost += Double(uriage.total)
                //print("categoryIndex = \(categoryIndex)")
                //print("percents[categoryIndex] = \(percents)")
            }
        }
//グラフ用にパーセント変換しています
        for i in 0..<percents.count {
            percents[i] /= sumCost
        }
        //print("percents[i] = \(percents)")
        
        
        let カンマ付きsumCostLabelLabel = NSNumber(value: sumCost)
        //class KUViewControllerletにグローバル設定しました・let フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        sumCostLabel.text = フォーマッタ.string(from: カンマ付きsumCostLabelLabel)! + "円"
        //売上高 = 売上高 + Int(sumCostLabel.text!)!
        
        
        //sumCostLabel.text = "合計 \(Int(sumCost)) 円"
        
        var percentsPerCategory: [(category: String, percent: Double)] = []
        for i in 0..<percents.count {
            percentsPerCategory.append((category: 売上締日詳細[i], percent: percents[i]))
        }
        
        return percentsPerCategory
    }
    // MARK: - 円グラフを描画
    func drawPieChartImageView(center: CGPoint, radius: CGFloat, percentsPerCategory: [(category: String, percent: Double)]) -> UIImageView? {
        // begin drawing
        UIGraphicsBeginImageContextWithOptions(myView.bounds.size, false, 1.0)
        
        // initialization
        var startAngle = -Double.pi
        let sortedPercentsPerCategory = percentsPerCategory.sorted(by: {$0.percent > $1.percent})
        
        // return nil if the number of colors is short
        if sortedPercentsPerCategory.count > colors.count {
            return nil
        }
        
        // draw frame of pie chart
        let contextUriage = UIGraphicsGetCurrentContext()
        let frameWidthRatio: CGFloat = 2.05
        let whiteCircleRect = CGRect(x: center.x - radius * frameWidthRatio, y: center.y - radius * frameWidthRatio, width: 2 * frameWidthRatio * radius, height: 2 * frameWidthRatio * radius)
        let whiteCirclePath = UIBezierPath(ovalIn: whiteCircleRect)
        contextUriage?.setFillColor(UIColor.gray.cgColor)
        whiteCirclePath.fill()
        
        // draw PieChart per category
        for i in 0..<sortedPercentsPerCategory.count {
            if let colorIndex = 売上締日詳細.index(of: sortedPercentsPerCategory[i].category) {
                colors[colorIndex].setStroke()
            }
            let arcPath = arcPercent(center: center, radius: radius, startAngle: CGFloat(startAngle), percent: sortedPercentsPerCategory[i].percent)
            startAngle += 2 * Double.pi * sortedPercentsPerCategory[i].percent
            arcPath.stroke()
        }
        
        // get image from context and end drawing
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return UIImageView(image: image)
    }
    
    // MARK: - Spending Table View Data Source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //検索ボタンと1番上のセルとの隙間
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30.0
    }
    
    //検索ボタン、セクションの文字色、文字サイズ、背景色、配置（中央寄せなど）、フォントを変更する
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        //ボタンセルの高さ・height: 30.0
        let cellRect = CGRect(x: 0, y: 0, width: myView.frame.width, height: 30.0)
        let cell = UIView(frame: cellRect)
        
        
        //検索ボタンの設定
        let sortButtons = UISegmentedControl(items: ["日付", "お客様", "締切", "金額"])
        sortButtons.frame.size = CGSize(width: cell.frame.width - 20, height: cell.frame.height)
        sortButtons.center = cell.center
        sortButtons.backgroundColor = self.view.backgroundColor//押されていないボタンの色、この場合はバックカラーです
        sortButtons.tintColor = .orange//押されたボタンの色
        sortButtons.selectedSegmentIndex = 0//初期のボタン選択場所0〜2
        sortButtons.addTarget(self, action: #selector(sortButtonTapped(_:)), for: .valueChanged)
        cell.addSubview(sortButtons)
        return cell
    }
    
    //4つのボタンが押されたら
//ここuriages
    func sortButtonTapped(_ sortButtons: UISegmentedControl) {
        
        if 検索変更 {
            検索変更 = false
        switch sortButtons.selectedSegmentIndex {
        case 0:
            print("true日付")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.day < uriage2.day
            })
        case 1:
            print("trueお客様")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                return uriage1.name! > uriage2.name!
            })
        case 2:
            print("true締切")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                return uriage1.category! > uriage2.category!
            })
        case 3:
            print("true金額")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                return uriage1.total > uriage2.total
            })
        default:
            print("default")
        }
        } else {
            検索変更 = true
            print("false日付")
            switch sortButtons.selectedSegmentIndex {
            case 0:
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.day > uriage2.day
                })
            case 1:
                print("falseお客様")
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.name! < uriage2.name!
                })
            case 2:
                print("false締切")
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.category! < uriage2.category!
                })
            case 3:
                print("false金額")
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.total < uriage2.total
                })
            default:
                print("default")
            }
        }
        if let indexPathes = spendingTableView.indexPathsForVisibleRows {
            spendingTableView.reloadRows(at: indexPathes, with: .automatic)
        }
    }
    
    // MARK: - スクロール
    //参考サイトhttp://qiita.com/noppefoxwolf/items/7b7f708de2ec09614282

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//ここuriages
        伝票数 = uriages.count
        return uriages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//ここuriage
//ここuriages
        let uriage = uriages[indexPath.row]
        //print("uriage = \(uriage)")
//ここuriage
        let cell = configureSpendingCell(uriage: uriage)
        cell.layoutMargins = .zero
        return cell
    }
//MARK: - 一番下に来た時の処理
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
            //print("一番下に来た時の処理")
            }

//追加2・KUDataViewControllerに表示する場合はここに追加します
//ここuriage
    func configureSpendingCell(uriage: Uriage) -> UITableViewCell {
        let cell = UITableViewCell()
        //参考サイト http://joyplot.com/documents/2016/10/23/swift-uilabel/
        // create day label
        let dayLabel = UILabel()
        dayLabel.sizeToFit()//文字列に合わせた領域確保
//ここuriage
        dayLabel.text = "\(uriage.day)日"//ここ
        dayLabel.numberOfLines = 0//改行桁・この場合は作動しません
        dayLabel.frame = CGRect(x: myView.frame.width * 0.01, y: 0.0, width: myView.frame.width / 5.0, height: cell.frame.height)
        //print("dayLabel.frame = \(dayLabel.frame)")
        dayLabel.textColor = .brown//文字色
        cell.addSubview(dayLabel)
        
        // create お客様 label
        let お客様Label = UILabel()
        お客様Label.sizeToFit()
//ここuriage
        お客様Label.text = "\(uriage.name!)"//ここ
        お客様Label.frame = CGRect(x: myView.frame.width * 0.06, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        お客様Label.textColor = .red//文字色
        cell.addSubview(お客様Label)

        // create 品名 label
        let 品名Label = UILabel()
        品名Label.sizeToFit()
//ここuriage
        品名Label.text = "\(uriage.details1!)"//ここ
        品名Label.frame = CGRect(x: myView.frame.width * 0.32, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        品名Label.textColor = .green//文字色
        cell.addSubview(品名Label)

        // create 適用 label
        let 適用Label = UILabel()
        適用Label.sizeToFit()
//ここuriage
        適用Label.text = "\(uriage.retailer1!)"//ここ
        if uriage.name == "現金顧客" {
            適用Label.text = "\(uriage.nameGenkin!)" + " 殿"
        }
        //print("uriage.details6 = \(String(describing: uriage.details6))")
        //print("適用Label.text = \(適用Label.text!)")
        if 適用Label.text == " " {
            //print("適用Label.text = \(適用Label.text!)")
            適用Label.text = uriage.details6
        }
        適用Label.frame = CGRect(x: myView.frame.width * 0.58, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        適用Label.textColor = .blue
        cell.addSubview(適用Label)
        
        // create 締切 label
        let 締切Label = UILabel()
        締切Label.sizeToFit()
        //ここuriage
        締切Label.text = "\(uriage.category!)"//ここ
        締切Label.frame = CGRect(x: myView.frame.width * 0.85, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        締切Label.textColor = .orange
        cell.addSubview(締切Label)
        
        // create 伝票合計 label
        let 伝票合計Label = UILabel()
        伝票合計Label.sizeToFit()
//ここuriage
        let カンマ付き伝票合計Label = NSNumber(value: uriage.total)
        //class KUViewControllerletにグローバル設定しました・let フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        伝票合計Label.text = フォーマッタ.string(from: カンマ付き伝票合計Label)! + "円"
        
        //伝票合計Label.text = "\(Int(uriage.total))円"
        伝票合計Label.textAlignment = .right
        伝票合計Label.frame = CGRect(x: myView.frame.width * 0.64, y: 0.0, width: myView.frame.width * 0.35, height: cell.frame.height)
        伝票合計Label.textColor = .black
        //print("伝票合計Label.text = \(伝票合計Label)です")
        cell.addSubview(伝票合計Label)
        
        //CoreDataのnumber伝票番号はラスト伝票番号に代入されている
        //ラスト伝票番号は+1されて次の伝票番号になる
        ラスト伝票番号 = Int(uriage.number)
        //print("configureSpendingCell・ラスト伝票番号は\(ラスト伝票番号)番です")
        //print("configureSpendingCell・伝票数は\(伝票数)番です")
        
        return cell
    }
    
    // MARK: - Spending Table View Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//ここuriages
        performSegue(withIdentifier: segueEditSpendingViewController, sender: uriages[indexPath.row])
        //print("通過セル選択")
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueEditSpendingViewController {
//ここKUAddViewController
            let destinationViewController = segue.destination as! KUAddViewController//ここ
//ここuriage
//ここUriage
            destinationViewController.uriage = sender as! Uriage?
        } else if segue.identifier == segueAddSpendingViewController {
//ここKUAddViewController
            let destinationViewController = segue.destination as! KUAddViewController//ここ
            destinationViewController.myDate[0] = Int(year)!
            if let month = monthData.index(of: month) {
                destinationViewController.myDate[1] = month + 1
            }
        }
    }
    
}
