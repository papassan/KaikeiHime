//
//  PModelController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/25.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//


import UIKit

/*
 A controller object that manages a simple model -- a collection of month names.
 
 The controller serves as the data source for the page view controller; it therefore implements pageViewController:viewControllerBeforeViewController: and pageViewController:viewControllerAfterViewController:.
 It also implements a custom method, viewControllerAtIndex: which is useful in the implementation of the data source methods, and in the initial configuration of the application.
 
 There is no need to actually create view controllers for each page in advance -- indeed doing so incurs unnecessary overhead. Given the data model, these methods create, configure, and return a new view controller on demand.
 */


class SoaModelController: NSObject, UIPageViewControllerDataSource {

    var pageData = NSArray()


    override init() {
        super.init()
        // Create the data model.
        _ = DateFormatter()
//        pageData = dateFormatter.monthSymbols
        pageData = [ "決 算 書", "貸 借 対 照 表" , "損 益 計 算 書" , "一 般 管 理 費" , "署 名"]
    }
//ここSoaDataViewController
    func viewControllerAtIndex(_ index: Int, storyboard: UIStoryboard) ->
        SoaDataViewController? {
        // Return the data view controller for the given index.
        if (self.pageData.count == 0) || (index >= self.pageData.count) {
            return nil
        }
        // Create a new view controller and pass suitable data.
//ここSoaDataViewController
        let dataViewController = storyboard.instantiateViewController(withIdentifier: "SoaDataViewController") as! SoaDataViewController
//pageDataをSoaDataViewControllerに引き継ぎます
        dataViewController.dataObject = self.pageData[index] as AnyObject
        return dataViewController
    }
//ここSoaDataViewController
    func indexOfViewController(_ viewController: SoaDataViewController) -> Int {
        // Return the index of the given data view controller.
        // For simplicity, this implementation uses a static array of model objects and the view controller stores the model object; you can therefore use the model object to identify the index.
        if let dataObject: AnyObject = viewController.dataObject {
            return self.pageData.index(of: dataObject)
        } else {
            return NSNotFound
        }
    }

    // MARK: - Page View Controller Data Source

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
//ここSoaDataViewController
        var index = self.indexOfViewController(viewController as! SoaDataViewController)
        if index == NSNotFound {
            return nil
        }
        if index == 0 {
           index = self.pageData.count - 1
        } else {
           index -= 1
        }
        //print("Before")
        //print(index)
        return self.viewControllerAtIndex(index, storyboard: viewController.storyboard!)
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
//ここSoaDataViewController
        var index = self.indexOfViewController(viewController as! SoaDataViewController)
        if index == NSNotFound {
            return nil
        }
        index += 1
        if index == self.pageData.count {
            index = 0
        }
        //print("After")
        //print(index)
        return self.viewControllerAtIndex(index, storyboard: viewController.storyboard!)
    }

}

