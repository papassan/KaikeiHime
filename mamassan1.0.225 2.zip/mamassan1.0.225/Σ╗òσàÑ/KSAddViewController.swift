//
//  AddSpendingViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/23.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit

// MARK: - Global Properties for Category Segmented Control

class KSAddViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    let 買掛顧客 = [["現金仕入","太平洋セメント販売株式会社","株式会社吉田東光","大利根建材有限会社","有限会社イシヅカ","小野塚建材株式会社","藤田建材工業株式会社","有限会社玉井建材店","大沢生コン株式会社","有限会社清和建材","丸栄工業株式会社","エスビック株式会社"],["0","2","2","1","2","3","2","3","3","2","2","1"]]
    
    // MARK: - Properties
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var 仕入顧客ピッカー部品: UIPickerView!
    @IBOutlet weak var categorySegmentedControl1: UISegmentedControl!
    @IBOutlet weak var categorySegmentedControl2: UISegmentedControl!
    @IBOutlet weak var deleteButton: UIButton!
    
    @IBOutlet weak var 仕入顧客ラベル: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    @IBOutlet weak var multiplyButton: UIButton!
    
    var 現金買掛選択 = ""
    var 日にちrowInt = 11
    
    // MARK: - Flags for Inputing Numbers
    
    var multiplyFlag = false
    var placehold = false
    var edNumber = 0
    
    // MARK: - Properties for Saving data into Core Data
    
    var myCategory = 仕入締日.first
    var myDate: [Int] = {
        var myDate: [Int] = []
        // get current date
        let now = Date()
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: now)
        // assign them to myDate[]
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate.append(year)
            myDate.append(month)
            myDate.append(day)
        }
        
        return myDate
    }()

    struct 閏年判定 {
        var year, month, day: Int
        static func 閏年(y: Int) -> Bool {
            return (y % 4 == 0) && (y % 100 != 0 || y % 400 == 0)
        }
        static func 月の最後の日付(m: Int, year: Int) -> Int {
            switch m {
            case 2: return self.閏年(y: year) ? 29 : 28
            case 4, 6, 9, 11: return 30
            default: return 31
            }
        }
    }
    // MARK: -
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//ここ
    var shiire: Shiire?
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set date got from segue
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let date = dateFormatter.date(from: "\(myDate[0])/\(myDate[1])/\(myDate[2])") {
            datePicker.date = date
        }
        
//ここ
        if let shiire = shiire {
            setEditedSpending(shiire)
        }
        
//買掛伝票ピッカー
        仕入顧客ピッカー部品.delegate = self
        仕入顧客ピッカー部品.dataSource = self
        //仕入顧客ピッカー部品.alpha = 0
        
        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(self.cancelButtonTapped(_:)))
        downSwipe.direction = .down
        self.view.addGestureRecognizer(downSwipe)
    }
//viewDidLoad()・ここまで
    
    
// MARK: セッティング
//ここ
    func setEditedSpending(_ shiire: Shiire) {
        myDate[0] = Int(shiire.year)
        myDate[1] = Int(shiire.month)
        myDate[2] = Int(shiire.day)
        myCategory = shiire.category!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let shiireDate = dateFormatter.date(from: "\(shiire.year)/\(shiire.month)/\(shiire.day)") {
            datePicker.date = shiireDate
        }
        if let shiireCategoryIndex = 仕入締日.index(of: shiire.category!) {
            if shiireCategoryIndex < 5 {
                categorySegmentedControl1.selectedSegmentIndex = shiireCategoryIndex
            } else {
                categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
                categorySegmentedControl2.selectedSegmentIndex = shiireCategoryIndex - 5
            }
        }
//金額を変数に入れる
        costLabel.text = String(Int(shiire.total))
//編集の為、ビッカーを隠しています
        仕入顧客ピッカー部品.alpha = 0
        仕入顧客ラベル.alpha = 1
        仕入顧客ラベル.text = shiire.name
        deleteButton.isEnabled = true
    }
    
    // MARK: - Actions of Buttons
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func dateChanged(_ sender: UIDatePicker) {
        // Assign selected date to myDate[]
        //print("通過dateChanged")
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: sender.date)
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate[0] = year
            myDate[1] = month
            myDate[2] = day
        }
        仕入日付調整()
    }
    
    @IBAction func categoryChosen1(_ sender: UISegmentedControl) {
        myCategory = 仕入締日[sender.selectedSegmentIndex]
        categorySegmentedControl2.selectedSegmentIndex = UISegmentedControlNoSegment
    }
    
    @IBAction func categoryChosen2(_ sender: UISegmentedControl) {
        myCategory = 仕入締日[sender.selectedSegmentIndex + 5]
        categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
    }
//MARK: - 保存
    @IBAction func enterButtonTapped(_ sender: Any) {
        // dismiss if no cost is input
        if costLabel.text == "0" {
            return
        }
        
        // create new Spending object if nothing is got from segue
        if shiire == nil {
            shiire = Shiire(context: context)
        }
        
        // configure Spending object
        if let shiire = shiire {
            shiire.year = Int16(myDate[0])
            shiire.month = Int16(myDate[1])
            shiire.day = Int16(myDate[2])
            shiire.category = myCategory
            
            if let cost = Int32(costLabel.text!) {
                
                shiire.cost = Int32(cost)
//categories
                if let shiireCategoryIndex = 仕入締日.index(of: (shiire.category!)) {
                    
                    //print("仕入のshiireCategoryIndex = \(shiireCategoryIndex)")

//genkin・仕入現金
                    if shiireCategoryIndex == 0 {
                        shiire.genkin = (shiire.cost)
                    }
                
//sname・仕入顧客
                let name = String(仕入顧客ラベル.text!)//ここで追加します
                shiire.name = name
//勘定科目の書き込み・仕入高
                    shiire.shiiredaka = (shiire.cost)
//勘定科目の書き込み・買掛金
                if shiireCategoryIndex != 0 {
                    shiire.kaikake = (shiire.cost)
                    }
                }
            }
        }
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        if let shiire = shiire {
            context.delete(shiire)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func insertNumber(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if costLabel.text == "0" {
            costLabel.text = String(sender.tag)
        } else if placehold {
            costLabel.text = String(sender.tag)
            placehold = false
        } else {
            costLabel.text = costLabel.text! + String(sender.tag)
        }
    }
    
    @IBAction func insert0(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if placehold {
            costLabel.text = "0"
            placehold = false
        } else if costLabel.text != "0" {
            if sender.tag == 11 {
                costLabel.text = costLabel.text! + "00"
            } else {
                costLabel.text = costLabel.text! + "0"
            }
        }
    }
    
    @IBAction func clearButtonTapped(_ sender: Any) {
        costLabel.text = "0"
        multiplyFlag = false
        placehold = false
        multiplyButton.isEnabled = true
    }
    
    @IBAction func multiplyButtonTapped(_ sender: Any) {
        multiplyFlag = true
        placehold = true
        multiplyButton.isEnabled = false
        edNumber = Int(costLabel.text!)!
    }
    
    @IBAction func equalButtonTapped(_ sender: Any) {
        if multiplyFlag {
            costLabel.text = String(edNumber * Int(costLabel.text!)!)
            multiplyFlag = false
            multiplyButton.isEnabled = true
        }
    }
    
//MARK: - 買掛ピッカーボタン
    @IBAction func 買掛ピッカーボタン(_ sender: UIButton) {
        仕入顧客ピッカー部品.alpha = 1
        仕入顧客ラベル.alpha = 0
    }

//MARK: - 買掛伝票ピッカー
    //pickerに表示する列数を返すデータソースメソッド.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //print("通過0")
        if (pickerView.tag == 1) {
            return 買掛顧客.count//return 1
        }
        return 買掛顧客.count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する行数を返すデータソースメソッド
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //print("通過1")
        
        if (pickerView.tag == 1) {
            return 買掛顧客[component].count//売掛伝票顧客[component].count
        }
        
        return 買掛顧客[component].count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する値を返すデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //print("通過2")
        
        if (pickerView.tag == 1) {
            return 買掛顧客[component][row]//("\(売掛伝票顧客[row])")
        }

        return 買掛顧客[component][row]//returnは最後に追加したピッカーの変数を返します
    }
    
// MARK: - pickerが選択された際に呼ばれるデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print("通過3")
        
        if (pickerView.tag == 1) {
            仕入顧客ラベル.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
            仕入顧客ピッカー部品.alpha = 0
            仕入顧客ラベル.alpha = 1
            // MARK: - ピッカー連動で項目を追加する
            //締切は顧客名と同じ配列順に締切番号を設定してある
            //変数締切ではinComponetは従いたい配列変数に合わせる・この場合ではInCompont: 0
            //forComponentは順番に設定します・この場合ではforComponent: 1
            現金買掛選択 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 1)!
            
//category・現金買掛選択
            let 現金買掛選択Index = Int(現金買掛選択)
            categorySegmentedControl1.selectedSegmentIndex = 現金買掛選択Index!
            myCategory = 仕入締日[categorySegmentedControl1.selectedSegmentIndex]
            仕入日付調整()
        }
    }
    
    func 仕入日付調整() {
        let 閏年判定結果 = 閏年判定.閏年(y: myDate[0])
        //var 閏年判定結果表示 = ""
        if 閏年判定結果 == true {
            _ = "閏年です"
        }else {
            _ = "閏年ではありません"
        }
        //print("閏年判定 = \(myDate[0])年は\(閏年判定結果表示)")
        let 月の最後の日判定結果 = 閏年判定.月の最後の日付(m: myDate[1], year: myDate[0])
        //print("月の最後の日判定結果 = \(月の最後の日判定結果)")
        
        
        if myCategory == "20日" {
            myDate[2] = 20
        }
        if myCategory == "25日" {
            myDate[2] = 25
        }
        if myCategory == "末日" {
            myDate[2] = 月の最後の日判定結果
        }
        if myCategory == "末日" && myDate[1] == 2 {
            if 閏年判定結果 == true {
                myDate[2] = 29
            } else {
                myDate[2] = 月の最後の日判定結果
            }
        }
        //print("myCategory = \(myCategory!)")
        // set date got from segue
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let date = dateFormatter.date(from: "\(myDate[0])/\(myDate[1])/\(myDate[2])") {
            //print("datePicker通過")
            datePicker.date = date
        }
        //datePicker.delegate = self
        //datePicker.dataSource = self
        // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
        //datePicker.selectRow(品名rowInt, inComponent: 0, animated: true)
        //datePicker.selectRow(数量rowInt, inComponent: 1, animated: false)
        //datePicker.selectRow(日にちrowInt, inComponent: 2, animated: false)
    }
    
    //参考サイトhttp://stackoverflow.com/questions/33655015/changing-font-and-its-size-of-a-picker-in-swift
// MARK: - ピッカーのフォントサイズ設定
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
//pickerView1
        var ピッカーフォント: UILabel
        if let view = view as? UILabel {
            ピッカーフォント = view
        } else {
            ピッカーフォント = UILabel()
        }
        
        ピッカーフォント.textColor = .black
        ピッカーフォント.textAlignment = .center
        ピッカーフォント.font = UIFont.systemFont(ofSize: 36)
        
        // where data is an Array of String
        if pickerView.tag == 1 {
            ピッカーフォント.text = 買掛顧客[component][row]//買掛顧客[row] as? String
            return ピッカーフォント
        }
//ここまで
        
        
//新規ピッカーフォントはここに追加します
        
//ここまで
        
        return ピッカーフォント//return変数は最後に追加した変数を書きます
    }
    
    // MARK: - 品名のピッカーサイズ
    func pickerView(_ pickerView: UIPickerView, widthForComponent component:Int) -> CGFloat {
        
        if (pickerView.tag == 1) {
            return 569
        }
        return 569//この場合は最後なので単価の幅です・34以下は万単位で1の桁が表示しません
    }
    
    // MARK: - ホイールのセルの高さの調節
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 50
    }
    //ホイールのセルの幅の調節・しかし反応なしです ?
    func pickerView(_ pickerView: UIPickerView, rowWidthForComponent component: Int) -> CGFloat {
        return 80
    }
    
//ここまで・ピッカー
}
