//
//  AddSpendingViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/27.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit

// MARK: - Global Properties for Category Segmented Control

class pKHAddViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    let 借方勘定科目 = [["給料手当", "役員報酬", "退職金給付費用", "広告宣伝費", "接待交際費", "会議費", "車両費", "諸会費", "支払手数料", "雑費", "未払金", "預り金", "長期借入金", "保険料", "通信費", "ガソリン代", "水道光熱費", "租税公課", "事務用消耗品費", "備品消耗品費", "旅費交通費", "修繕費", "普通預金", "期首商品棚卸高", "商品"],["建材", "空調"],["敏一", "嘉子", "秀雄", "三菱東京 建材", "栃銀空調", "楽天", "りそな空調", "栃銀建材", "りそな建材"],["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "0", "0"]]
    let 貸方勘定科目 = [["現金", "普通預金", "当座預金", "受取利息", "雑収入"],["建材", "空調"],["敏一", "嘉子", "秀雄", "三菱東京 建材", "栃銀空調", "楽天", "りそな空調", "栃銀建材", "りそな建材"]]
    
    // MARK: - Properties
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var 借方ピッカー部品: UIPickerView!
    @IBOutlet weak var 貸方ピッカー部品: UIPickerView!
    @IBOutlet weak var categorySegmentedControl1: UISegmentedControl!
    @IBOutlet weak var categorySegmentedControl2: UISegmentedControl!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    @IBOutlet weak var 振替伝票View: Gesture!
    @IBOutlet weak var 振替伝票貸方View: UIView!
    @IBOutlet weak var 振替伝票借方View: UIView!
    
    @IBOutlet weak var 振替借方科目1行目: UILabel!
    @IBOutlet weak var 振替借方科目2行目: UILabel!
    @IBOutlet weak var 振替借方科目3行目: UILabel!
    @IBOutlet weak var 振替借方科目4行目: UILabel!
    @IBOutlet weak var 振替借方科目5行目: UILabel!
    @IBOutlet weak var 振替借方科目6行目: UILabel!
    @IBOutlet weak var 振替借方科目7行目: UILabel!
    
    @IBOutlet weak var 振替借方部門1行目: UILabel!
    @IBOutlet weak var 振替借方部門2行目: UILabel!
    @IBOutlet weak var 振替借方部門3行目: UILabel!
    @IBOutlet weak var 振替借方部門4行目: UILabel!
    @IBOutlet weak var 振替借方部門5行目: UILabel!
    @IBOutlet weak var 振替借方部門6行目: UILabel!
    @IBOutlet weak var 振替借方部門7行目: UILabel!
    
    @IBOutlet weak var 振替借方補助1行目: UILabel!
    @IBOutlet weak var 振替借方補助2行目: UILabel!
    @IBOutlet weak var 振替借方補助3行目: UILabel!
    @IBOutlet weak var 振替借方補助4行目: UILabel!
    @IBOutlet weak var 振替借方補助5行目: UILabel!
    @IBOutlet weak var 振替借方補助6行目: UILabel!
    @IBOutlet weak var 振替借方補助7行目: UILabel!
    
    @IBOutlet weak var 振替借方小計1行目: UILabel!
    @IBOutlet weak var 振替借方小計2行目: UILabel!
    @IBOutlet weak var 振替借方小計3行目: UILabel!
    @IBOutlet weak var 振替借方小計4行目: UILabel!
    @IBOutlet weak var 振替借方小計5行目: UILabel!
    @IBOutlet weak var 振替借方小計6行目: UILabel!
    @IBOutlet weak var 振替借方小計7行目: UILabel!
    
    @IBOutlet weak var 振替借方合計: UILabel!
    
    @IBOutlet weak var 振替貸方科目1行目: UILabel!
    @IBOutlet weak var 振替貸方科目2行目: UILabel!
    @IBOutlet weak var 振替貸方科目3行目: UILabel!
    @IBOutlet weak var 振替貸方科目4行目: UILabel!
    @IBOutlet weak var 振替貸方科目5行目: UILabel!
    @IBOutlet weak var 振替貸方科目6行目: UILabel!
    @IBOutlet weak var 振替貸方科目7行目: UILabel!
    
    @IBOutlet weak var 振替貸方部門1行目: UILabel!
    @IBOutlet weak var 振替貸方部門2行目: UILabel!
    @IBOutlet weak var 振替貸方部門3行目: UILabel!
    @IBOutlet weak var 振替貸方部門4行目: UILabel!
    @IBOutlet weak var 振替貸方部門5行目: UILabel!
    @IBOutlet weak var 振替貸方部門6行目: UILabel!
    @IBOutlet weak var 振替貸方部門7行目: UILabel!
    
    @IBOutlet weak var 振替貸方補助1行目: UILabel!
    @IBOutlet weak var 振替貸方補助2行目: UILabel!
    @IBOutlet weak var 振替貸方補助3行目: UILabel!
    @IBOutlet weak var 振替貸方補助4行目: UILabel!
    @IBOutlet weak var 振替貸方補助5行目: UILabel!
    @IBOutlet weak var 振替貸方補助6行目: UILabel!
    @IBOutlet weak var 振替貸方補助7行目: UILabel!
    
    @IBOutlet weak var 振替貸方小計1行目: UILabel!
    @IBOutlet weak var 振替貸方小計2行目: UILabel!
    @IBOutlet weak var 振替貸方小計3行目: UILabel!
    @IBOutlet weak var 振替貸方小計4行目: UILabel!
    @IBOutlet weak var 振替貸方小計5行目: UILabel!
    @IBOutlet weak var 振替貸方小計6行目: UILabel!
    @IBOutlet weak var 振替貸方小計7行目: UILabel!
    
    @IBOutlet weak var 振替貸方合計: UILabel!
    
    @IBOutlet weak var 借方振替1行目ボタン値: UIButton!
    @IBOutlet weak var 借方振替2行目ボタン値: UIButton!
    @IBOutlet weak var 借方振替3行目ボタン値: UIButton!
    @IBOutlet weak var 借方振替4行目ボタン値: UIButton!
    @IBOutlet weak var 借方振替5行目ボタン値: UIButton!
    @IBOutlet weak var 借方振替6行目ボタン値: UIButton!
    @IBOutlet weak var 借方振替7行目ボタン値: UIButton!
    
    @IBOutlet weak var 貸方振替1行目ボタン値: UIButton!
    @IBOutlet weak var 貸方振替2行目ボタン値: UIButton!
    @IBOutlet weak var 貸方振替3行目ボタン値: UIButton!
    @IBOutlet weak var 貸方振替4行目ボタン値: UIButton!
    @IBOutlet weak var 貸方振替5行目ボタン値: UIButton!
    @IBOutlet weak var 貸方振替6行目ボタン値: UIButton!
    @IBOutlet weak var 貸方振替7行目ボタン値: UIButton!
    
    @IBOutlet weak var costLabel: UILabel!
    @IBOutlet weak var multiplyButton: UIButton!
    
    @IBOutlet weak var 振替借方合計テキスト: UITextField!
    @IBOutlet weak var 振替借方科目1行目テキスト: UITextField!
    @IBOutlet weak var 振替借方科目2行目テキスト: UITextField!
    @IBOutlet weak var 振替借方科目3行目テキスト: UITextField!
    @IBOutlet weak var 振替借方科目4行目テキスト: UITextField!
    @IBOutlet weak var 振替借方科目5行目テキスト: UITextField!
    @IBOutlet weak var 振替借方科目6行目テキスト: UITextField!
    @IBOutlet weak var 振替借方科目7行目テキスト: UITextField!
    
    @IBOutlet weak var 振替貸方合計テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計1行目テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計2行目テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計3行目テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計4行目テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計5行目テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計6行目テキスト: UITextField!
    @IBOutlet weak var 振替貸方小計7行目テキスト: UITextField!
    
    var 借方ピッカーカウント = 0
    var 貸方ピッカーカウント = 0
    
    var カテゴリー選択カウント = 0
    
    var 借方ピッカー選択 = ""
    var 貸方ピッカー選択 = ""
    
    var カンマ無し振替借方合計:Int32 = 0
    var カンマ無し振替貸方合計:Int32 = 0
    
    var カンマ無し振替借方小計1:Int32 = 0
    var カンマ無し振替借方小計2:Int32 = 0
    var カンマ無し振替借方小計3:Int32 = 0
    var カンマ無し振替借方小計4:Int32 = 0
    var カンマ無し振替借方小計5:Int32 = 0
    var カンマ無し振替借方小計6:Int32 = 0
    var カンマ無し振替借方小計7:Int32 = 0
    
    var カンマ無し振替貸方小計1:Int32 = 0
    var カンマ無し振替貸方小計2:Int32 = 0
    var カンマ無し振替貸方小計3:Int32 = 0
    var カンマ無し振替貸方小計4:Int32 = 0
    var カンマ無し振替貸方小計5:Int32 = 0
    var カンマ無し振替貸方小計6:Int32 = 0
    var カンマ無し振替貸方小計7:Int32 = 0
    
    var 借方振替1行目ボタンが押されました = true
    var 借方振替2行目ボタンが押されました = false
    var 借方振替3行目ボタンが押されました = false
    var 借方振替4行目ボタンが押されました = false
    var 借方振替5行目ボタンが押されました = false
    var 借方振替6行目ボタンが押されました = false
    var 借方振替7行目ボタンが押されました = false
    
    var 貸方振替1行目ボタンが押されました = true
    var 貸方振替2行目ボタンが押されました = false
    var 貸方振替3行目ボタンが押されました = false
    var 貸方振替4行目ボタンが押されました = false
    var 貸方振替5行目ボタンが押されました = false
    var 貸方振替6行目ボタンが押されました = false
    var 貸方振替7行目ボタンが押されました = false
    
    @IBOutlet weak var 電卓: Gesture!
    
    
    
    // MARK: - Flags for Inputing Numbers
    
    var multiplyFlag = false
    var placehold = false
    var edNumber = 0
    
    // MARK: - Properties for Saving data into Core Data
//ここ会計姫categories
    var myCategory = 会計姫categories.first
    
    var myDate: [Int] = {
        var myDate: [Int] = []
        // get current date
        let now = Date()
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: now)
        // assign them to myDate[]
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate.append(year)
            myDate.append(month)
            myDate.append(day)
        }
        
        return myDate
    }()
    
    // MARK: -
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//ここ
    var kaikeiHime: KaikeiHime?
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set date got from segue
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let date = dateFormatter.date(from: "\(myDate[0])/\(myDate[1])/\(myDate[2])") {
            datePicker.date = date
        }
//新規入力では振替伝票Viewは非表示です
        
        振替伝票View.alpha = 0
        電卓.alpha = 0
        
//買掛伝票ピッカー
        借方ピッカー部品.delegate = self
        借方ピッカー部品.dataSource = self
        借方ピッカー部品.alpha = 1
        
        貸方ピッカー部品.delegate = self
        貸方ピッカー部品.dataSource = self
        貸方ピッカー部品.alpha = 0

        
//ここ
        if let kaikeiHime = kaikeiHime {
            categorySegmentedControl1.alpha = 0
            categorySegmentedControl2.alpha = 0
            setEditedSpending(kaikeiHime)
        }
        


        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(self.cancelButtonTapped(_:)))
        downSwipe.direction = .down
        self.view.addGestureRecognizer(downSwipe)
    }
    
//ここまでviewDidLoad()
    
// MARK: セッティング
//ここ
    func setEditedSpending(_ kaikeiHime: KaikeiHime) {
        myDate[0] = Int(kaikeiHime.year)
        myDate[1] = Int(kaikeiHime.month)
        myDate[2] = Int(kaikeiHime.day)
        myCategory = kaikeiHime.category!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let kaikeiHimeDate = dateFormatter.date(from: "\(kaikeiHime.year)/\(kaikeiHime.month)/\(kaikeiHime.day)") {
            datePicker.date = kaikeiHimeDate
        }
//ここ会計姫categories
        if let kaikeiHimeCategoryIndex = 会計姫categories.index(of: kaikeiHime.category!) {
            //print("kaikeiHimeCategoryIndex = \(kaikeiHimeCategoryIndex)")
//編集振替伝票では振替伝票Viewは表示します
            振替伝票View.alpha = 1
            if kaikeiHimeCategoryIndex < 5 {
                categorySegmentedControl1.selectedSegmentIndex = kaikeiHimeCategoryIndex
            } else {
                categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
                categorySegmentedControl2.selectedSegmentIndex = kaikeiHimeCategoryIndex - 5
            }
        }
//金額を変数に入れる
        costLabel.text = String(Int(kaikeiHime.total))
        電卓.frame = CGRect(x: 387, y: 483, width: 249, height: 253)
        電卓.alpha = 1
        借方ピッカー部品.alpha = 0
        振替借方科目1行目.text = kaikeiHime.nameKarikata1
        振替借方部門1行目.text = kaikeiHime.kariBumon1
        振替借方部門2行目.text = kaikeiHime.kariBumon2
        振替借方部門3行目.text = kaikeiHime.kariBumon3
        振替借方部門4行目.text = kaikeiHime.kariBumon4
        振替借方部門5行目.text = kaikeiHime.kariBumon5
        振替借方部門6行目.text = kaikeiHime.kariBumon6
        振替借方部門7行目.text = kaikeiHime.kariBumon7
        
        振替借方補助1行目.text = kaikeiHime.kariHojyo1
        振替借方補助2行目.text = kaikeiHime.kariHojyo2
        振替借方補助3行目.text = kaikeiHime.kariHojyo3
        振替借方補助4行目.text = kaikeiHime.kariHojyo4
        振替借方補助5行目.text = kaikeiHime.kariHojyo5
        振替借方補助6行目.text = kaikeiHime.kariHojyo6
        振替借方補助7行目.text = kaikeiHime.kariHojyo7

        
        //リスト金額にカンマを付けています
        let カンマ付き振替借方小計1行目Label = NSNumber(value: kaikeiHime.kariTotal1)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3

        // Cellにフォントカラーを設定する
        振替借方小計1行目.textColor = .brown//文字色
        // Cellにフォントサイズを指定する
        振替借方小計1行目.font = UIFont.systemFont(ofSize: 20)
        
        振替借方小計2行目.textColor = .brown//文字色
        振替借方小計2行目.font = UIFont.systemFont(ofSize: 20)
        振替借方小計3行目.textColor = .brown//文字色
        振替借方小計3行目.font = UIFont.systemFont(ofSize: 20)
        振替借方小計4行目.textColor = .brown//文字色
        振替借方小計4行目.font = UIFont.systemFont(ofSize: 20)
        振替借方小計5行目.textColor = .brown//文字色
        振替借方小計5行目.font = UIFont.systemFont(ofSize: 20)
        振替借方小計6行目.textColor = .brown//文字色
        振替借方小計6行目.font = UIFont.systemFont(ofSize: 20)
        振替借方小計7行目.textColor = .brown//文字色
        振替借方小計7行目.font = UIFont.systemFont(ofSize: 20)
        
        振替借方小計1行目.text = フォーマッタ.string(from: カンマ付き振替借方小計1行目Label)! + "円"
        
        
        
        カンマ無し振替借方合計 = kaikeiHime.kariTotal1
        
        let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        
        // Cellにフォントカラーを設定する
        振替借方合計.textColor = .brown//文字色
        // Cellにフォントサイズを指定する
        振替借方合計.font = UIFont.systemFont(ofSize: 20)
        
        振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
        //合計.isEnabled = true
        
//テキストフィールドの編集不能
        振替借方合計テキスト.isEnabled = false//編集不可
        振替借方科目1行目テキスト.isEnabled = false
        振替借方科目2行目テキスト.isEnabled = false
        振替借方科目3行目テキスト.isEnabled = false
        振替借方科目4行目テキスト.isEnabled = false
        振替借方科目5行目テキスト.isEnabled = false
        振替借方科目6行目テキスト.isEnabled = false
        振替借方科目7行目テキスト.isEnabled = false

        //振替借方合計テキスト.isEnabled = true//編集可
        //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
        振替貸方合計テキスト.isEnabled = false//編集不可
        //print("振替貸方合計テキスト.isEnabled = false//編集不可")
        振替貸方小計1行目テキスト.isEnabled = false
        振替貸方小計2行目テキスト.isEnabled = false
        振替貸方小計3行目テキスト.isEnabled = false
        振替貸方小計4行目テキスト.isEnabled = false
        振替貸方小計5行目テキスト.isEnabled = false
        振替貸方小計6行目テキスト.isEnabled = false
        振替貸方小計7行目テキスト.isEnabled = false
        
        貸方ピッカー部品.alpha = 0
        
        振替貸方科目1行目.text = kaikeiHime.nameKashikata1
        振替貸方部門1行目.text = kaikeiHime.kashiBumon1
        振替貸方補助1行目.text = kaikeiHime.kashiHojyo1
        
        振替貸方科目2行目.text = kaikeiHime.nameKashikata2
        振替貸方部門2行目.text = kaikeiHime.kashiBumon2
        振替貸方補助2行目.text = kaikeiHime.kashiHojyo2
        
        
        
        //リスト金額にカンマを付けています
//貸方小計1表示
        let カンマ付き振替貸方小計1行目Label = NSNumber(value: kaikeiHime.kashiTotal1)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        
        // Cellにフォントカラーを設定する
        振替貸方小計1行目.textColor = .brown//文字色
        // Cellにフォントサイズを指定する
        振替貸方小計1行目.font = UIFont.systemFont(ofSize: 20)
        
        振替貸方小計1行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計1行目Label)! + "円"

//貸方小計2表示
        let カンマ付き振替貸方小計2行目Label = NSNumber(value: kaikeiHime.kashiTotal2)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        
        振替貸方小計2行目.textColor = .brown//文字色
        振替貸方小計2行目.font = UIFont.systemFont(ofSize: 20)
        if カンマ付き振替貸方小計2行目Label != 0 {
            振替貸方小計2行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計2行目Label)! + "円"
        }
        
//貸方合計表示
        カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + kaikeiHime.kashiTotal2
        
        let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        
        // Cellにフォントカラーを設定する
        振替貸方合計.textColor = .brown//文字色
        // Cellにフォントサイズを指定する
        振替貸方合計.font = UIFont.systemFont(ofSize: 20)
            振替貸方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
        
        //テキストフィールドの編集不能
        振替貸方合計テキスト.isEnabled = false//編集不可
        //振替貸方合計テキスト.isEnabled = true//編集可
        //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"

        deleteButton.isEnabled = true
    }
    
    // MARK: - Actions of Buttons
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func dateChanged(_ sender: UIDatePicker) {
        // Assign selected date to myDate[]
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: sender.date)
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate[0] = year
            myDate[1] = month
            myDate[2] = day
        }
    }
//ここ会計姫categories
    @IBAction func categoryChosen1(_ sender: UISegmentedControl) {
        if カテゴリー選択カウント == 0 {
            借方ピッカーカウント += 1
            カテゴリー選択カウント = 1
        }
        myCategory = 会計姫categories[sender.selectedSegmentIndex]
        categorySegmentedControl2.selectedSegmentIndex = UISegmentedControlNoSegment
        //print("categoryChosen1 = \(myCategory!)")
        振替伝票View.alpha = 1
        貸方ピッカー部品.alpha = 1
        //電卓.alpha = 1
        if myCategory == "仕訳の支払い" {
            //print("仕訳")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(0, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(2, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "保険料の支払い" {
            //print("借方保険料")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(10, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(1, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(1, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "通信費の支払い" {
            //print("借方通信費")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(11, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(1, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "ガソリン代の支払い" {
            //print("借方ガソリン代")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(12, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "水道光熱費の支払い" {
            //print("借方水道光熱費")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(13, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(1, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
    }
//ここ会計姫categories
    @IBAction func categoryChosen2(_ sender: UISegmentedControl) {
        
        if カテゴリー選択カウント == 0 {
            借方ピッカーカウント += 1
            カテゴリー選択カウント = 1
        }
        
        myCategory = 会計姫categories[sender.selectedSegmentIndex + 5]//この5は追加したセグメントの数です、押すセグメントが5個ならば+5と書きます
        categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
        //print("categorySegmentedControl1 = \(UISegmentedControlNoSegment)")
        振替伝票View.alpha = 1
        貸方ピッカー部品.alpha = 1
        //電卓.alpha = 1
        if myCategory == "租税公課の支払い" {
            //print("借方租税公課")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(14, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(2, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "事務用消耗品費の支払い" {
            //print("借方事務用消耗品費")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(15, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(1, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "備品消耗品費の支払い" {
            //print("借方備品消耗品費")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(16, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "旅費交通費の支払い" {
            //print("借方旅費交通費")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(17, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(2, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
        if myCategory == "修繕費の支払い" {
            //print("借方修繕費")
            借方ピッカー部品.alpha = 1
            貸方ピッカー部品.alpha = 0
            振替伝票View.alpha = 0
            借方ピッカー部品.delegate = self
            借方ピッカー部品.dataSource = self
            // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
            借方ピッカー部品.selectRow(18, inComponent: 0, animated: true)
            借方ピッカー部品.selectRow(0, inComponent: 1, animated: false)
            借方ピッカー部品.selectRow(2, inComponent: 2, animated: false)
            借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
            // 選択中の行をハイライト
            借方ピッカー部品.showsSelectionIndicator = true
        }
    }
//MARK: - 保存
    @IBAction func enterButtonTapped(_ sender: Any) {
        // dismiss if no cost is input
        if costLabel.text == "0" {
            return
        }

        // create new Spending object if nothing is got from segue
        if kaikeiHime == nil {
            kaikeiHime = KaikeiHime(context: context)
        }
        
        // configure Spending object
        if let kaikeiHime = kaikeiHime {
            kaikeiHime.year = Int16(myDate[0])
            kaikeiHime.month = Int16(myDate[1])
            kaikeiHime.day = Int16(myDate[2])
            kaikeiHime.category = myCategory


            //print("myCategory = \(myCategory!)")
            //print("kaikeiHime.category = \(kaikeiHime.category!)")
            
            if let cost = Int32(costLabel.text!) {
//借方1行目ボタン
                if 借方振替1行目ボタンが押されました == true {
                    kaikeiHime.cost = Int32(cost)
                    kaikeiHime.kariTotal1 = Int32(cost)

                    kaikeiHime.kashiTotal1 = Int32(cost)
                    借方振替1行目ボタンが押されました = false
                    print("通過・借方振替1行目ボタンが押されました == true -> false")
                }
//借方2行目ボタン
                if 借方振替2行目ボタンが押されました == true {
                    //リスト金額にカンマを付けています
                    カンマ無し振替借方小計2 = cost
                    let カンマ付き振替借方小計Label = NSNumber(value: カンマ無し振替借方小計2)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方小計2行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方小計2行目.font = UIFont.systemFont(ofSize: 20)
                    振替借方小計2行目.text = フォーマッタ.string(from: カンマ付き振替借方小計Label)! + "円"
                    カンマ無し振替借方合計 = kaikeiHime.kariTotal1 + cost
                    let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
//借方2行目テキスト合計
                    //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//借方3行目ボタン
                if 借方振替3行目ボタンが押されました == true {
                    カンマ無し振替借方小計3 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替借方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方小計3行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方小計3行目.font = UIFont.systemFont(ofSize: 20)
                    振替借方小計3行目.text = フォーマッタ.string(from: カンマ付き振替借方小計Label)! + "円"
                    カンマ無し振替借方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替借方小計2
                    let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
//借方3行目テキスト合計
                    //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//借方4行目ボタン
                if 借方振替4行目ボタンが押されました == true {
                    カンマ無し振替借方小計4 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替借方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方小計4行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方小計4行目.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替借方小計4行目.text = フォーマッタ.string(from: カンマ付き振替借方小計Label)! + "円"
                    カンマ無し振替借方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替借方小計2 + カンマ無し振替借方小計3

                    let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
//借方4行目テキスト合計
                    //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//借方5行目ボタン
                if 借方振替5行目ボタンが押されました == true {
                    カンマ無し振替借方小計5 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替借方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方小計5行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方小計5行目.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替借方小計5行目.text = フォーマッタ.string(from: カンマ付き振替借方小計Label)! + "円"
                    
                    //振替借方合計計算
                    カンマ無し振替借方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替借方小計2 + カンマ無し振替借方小計3 + カンマ無し振替借方小計4
                    
                    let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
//借方5行目テキスト合計
                    //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//借方6行目ボタン
                if 借方振替6行目ボタンが押されました == true {
                    カンマ無し振替借方小計6 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替借方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方小計6行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方小計6行目.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替借方小計6行目.text = フォーマッタ.string(from: カンマ付き振替借方小計Label)! + "円"
                    
                    //振替借方合計計算
                    カンマ無し振替借方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替借方小計2 + カンマ無し振替借方小計3 + カンマ無し振替借方小計4 + カンマ無し振替借方小計4
                    
                    let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
//借方6行目テキスト合計
                    //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//借方7行目ボタン
                if 借方振替7行目ボタンが押されました == true {
                    カンマ無し振替借方小計7 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替借方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方小計7行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方小計7行目.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替借方小計7行目.text = フォーマッタ.string(from: カンマ付き振替借方小計Label)! + "円"
                    
                    //振替借方合計計算
                    カンマ無し振替借方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替借方小計2 + カンマ無し振替借方小計3 + カンマ無し振替借方小計4 + カンマ無し振替借方小計5 + カンマ無し振替借方小計6
                    
                    let カンマ付き振替借方合計Label = NSNumber(value: カンマ無し振替借方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替借方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替借方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    電卓.alpha = 0
//借方7行目テキスト合計
                    //振替借方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替借方合計Label)! + "円"
                    costLabel.text = "0"
                    return
                }
//MARK: - 貸方2行目ボタン
                if 貸方振替2行目ボタンが押されました == true {
                    //print("通過・貸方振替2行目ボタンが押されました == true")
                    //リスト金額にカンマを付けています
                    カンマ無し振替貸方小計2 = cost
                    kaikeiHime.kashiTotal2 = Int32(カンマ無し振替貸方小計2)
                    let カンマ付き振替貸方小計Label = NSNumber(value: カンマ無し振替貸方小計2)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方小計2行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方小計2行目.font = UIFont.systemFont(ofSize: 20)
                    振替貸方小計2行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計Label)! + "円"
                    カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + cost
                    let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方合計.font = UIFont.systemFont(ofSize: 20)
                    振替貸方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
//貸方2行目テキスト合計
                    //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"

                    if 振替借方合計.text != 振替貸方合計.text {
                        //print("通過・振替借方合計.text != 振替貸方合計.text")
                        電卓.alpha = 0
                       return
                    }
                    貸方振替2行目ボタンが押されました = false
                    //print("通過・貸方振替2行目ボタンが押されました = false")
                    //return
                }
//貸方3行目ボタン
                if 貸方振替3行目ボタンが押されました == true {
                    カンマ無し振替貸方小計3 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替貸方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方小計3行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方小計3行目.font = UIFont.systemFont(ofSize: 20)
                    振替貸方小計3行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計Label)! + "円"
                    カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替貸方小計2
                    let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方合計.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替貸方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
//貸方3行目テキスト合計
                    //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//貸方4行目ボタン
                if 貸方振替4行目ボタンが押されました == true {
                    カンマ無し振替貸方小計4 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替貸方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方小計4行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方小計4行目.font = UIFont.systemFont(ofSize: 20)
                    振替借方小計4行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計Label)! + "円"
                    カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替貸方小計2 + カンマ無し振替貸方小計3
                    let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方合計.font = UIFont.systemFont(ofSize: 20)
                    振替借方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
//貸方4行目テキスト合計
                    //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//貸方5行目ボタン
                if 貸方振替5行目ボタンが押されました == true {
                    カンマ無し振替貸方小計5 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替貸方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方小計5行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方小計5行目.font = UIFont.systemFont(ofSize: 20)
                    振替借方小計5行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計Label)! + "円"
                    カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替貸方小計2 + カンマ無し振替貸方小計3 + カンマ無し振替貸方小計4
                    
                    let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方合計.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替貸方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
//貸方5行目テキスト合計
                    //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//貸方6行目ボタン
                if 貸方振替6行目ボタンが押されました == true {
                    カンマ無し振替貸方小計6 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替貸方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方小計6行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方小計6行目.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替貸方小計6行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計Label)! + "円"
                    カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替貸方小計2 + カンマ無し振替貸方小計3 + カンマ無し振替借方小計4 + カンマ無し振替貸方小計4
                    let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方合計.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替貸方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
//貸方6行目テキスト合計
                    //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
//貸方7行目ボタン
                if 貸方振替7行目ボタンが押されました == true {
                    カンマ無し振替貸方小計7 = cost
                    //リスト金額にカンマを付けています
                    let カンマ付き振替貸方小計Label = NSNumber(value: cost)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方小計7行目.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方小計7行目.font = UIFont.systemFont(ofSize: 20)
                    //表示位置
                    振替貸方小計7行目.text = フォーマッタ.string(from: カンマ付き振替貸方小計Label)! + "円"
                    カンマ無し振替貸方合計 = kaikeiHime.kashiTotal1 + cost + カンマ無し振替貸方小計2 + カンマ無し振替貸方小計3 + カンマ無し振替貸方小計4 + カンマ無し振替貸方小計5 + カンマ無し振替貸方小計6
                    let カンマ付き振替貸方合計Label = NSNumber(value: カンマ無し振替貸方合計)
                    フォーマッタ.numberStyle = .decimal
                    フォーマッタ.groupingSeparator = ","
                    フォーマッタ.groupingSize = 3
                    
                    // Cellにフォントカラーを設定する
                    振替貸方合計.textColor = .brown//文字色
                    // Cellにフォントサイズを指定する
                    振替貸方合計.font = UIFont.systemFont(ofSize: 20)
                    振替貸方合計.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
//貸方7行目テキスト合計
                    //振替貸方合計テキスト.text = フォーマッタ.string(from: カンマ付き振替貸方合計Label)! + "円"
                    電卓.alpha = 0
                    costLabel.text = "0"
                    return
                }
                
//ここ会計姫categories
                //if let kaikeiHimeCategoryIndex = 会計姫categories.index(of: (kaikeiHime.category)!) {
                    if 会計姫categories.index(of: (kaikeiHime.category)!) != nil {
                    
                    //print("会計姫のkaikeiHimeCategoryIndex = \(kaikeiHimeCategoryIndex)")
//借方仕訳
                        if 振替借方科目1行目.text == "現金" {
                        //借方の現金の仕訳はプラスします

                        }
                        if 振替借方科目1行目.text == "普通預金" {
                            //借方の普通預金の仕訳はプラスします
                            kaikeiHime.futsuu = (kaikeiHime.cost)
                        }
                    if myCategory == "仕訳の支払い" {
                        if 振替借方科目1行目.text == "給料手当" {
                            //print("給料手当を保存しました")
                            kaikeiHime.kyuuryou = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "役員報酬" {
                            //print("役員報酬を保存しました")
                            kaikeiHime.yakuin = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "退職金給付費用" {
                            //print("退職金給付費用を保存しました")
                            kaikeiHime.taisyoku = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "広告宣伝費" {
                            //print("広告宣伝費を保存しました")
                            kaikeiHime.koukoku = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "接待交際費" {
                            //print("接待交際費を保存しました")
                            kaikeiHime.settai = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "会議費" {
                            //print("会議費を保存しました")
                            kaikeiHime.kaigi = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "車両費" {
                            //print("車両費を保存しました")
                            kaikeiHime.syaryou = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "諸会費" {
                            //print("諸会費を保存しました")
                            kaikeiHime.syokai = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "支払手数料" {
                            //print("支払手数料を保存しました")
                            kaikeiHime.shiharaite = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "雑費" {
                            //print("雑費を保存しました")
                            kaikeiHime.zattsu = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "未払金" {
                            //print("未払金を保存しました")
                            kaikeiHime.mibarai = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "預り金" {
                            //print("預り金を保存しました")
                            kaikeiHime.azukari = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "長期借入金" {
                            //print("長期借入金を保存しました")
                            kaikeiHime.choukikariire = (kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "期首商品棚卸高" {
                            //print("期首商品棚卸高を保存しました")
                            kaikeiHime.kishutana = (kaikeiHime.cost)
                            kaikeiHime.shouhin = -(kaikeiHime.cost)
                        }
                        if 振替借方科目1行目.text == "商品" {
                            //print("商品を保存しました")
                            kaikeiHime.shouhin = (kaikeiHime.cost)
                            kaikeiHime.kimatsutana = kaikeiHime.cost
                        }
                    }
//貸方仕訳
                    
                    
//hoken・保険料
                    if myCategory == "保険料の支払い" {
                        //print("保険料を保存しました")
                        kaikeiHime.hoken = (kaikeiHime.cost)
                    }

//tsuushin・通信費
                    if myCategory == "通信費の支払い" {
                        //print("通信費を保存しました")
                        kaikeiHime.tsuushin = (kaikeiHime.cost)
                    }
                
//gasoline・ガソリン代
                    if myCategory == "ガソリン代の支払い" {
                        //print("ガソリン代を保存しました")
                        kaikeiHime.gasoline = (kaikeiHime.cost)
                    }
//suidou・水道光熱費
                    if myCategory == "水道光熱費の支払い" {
                        //print("水道光熱費を保存しました")
                        kaikeiHime.suidou = (kaikeiHime.cost)
                    }
//sozei・租税公課
                    if myCategory == "租税公課の支払い" {
                        //print("租税公課を保存しました")
                        kaikeiHime.sozei = (kaikeiHime.cost)
                    }
//jimu・事務用消耗品費
                    if myCategory == "事務用消耗品費の支払い" {
                        //print("事務用消耗品費を保存しました")
                        kaikeiHime.jimu = (kaikeiHime.cost)
                    }
//bihin・備品消耗品費
                    if myCategory == "備品消耗品費の支払い" {
                        //print("備品消耗品費を保存しました")
                        kaikeiHime.bihin = (kaikeiHime.cost)
                    }
//ryohi・旅費交通費
                    if myCategory == "旅費交通費の支払い" {
                        //print("旅費交通費を保存しました")
                        kaikeiHime.ryohi = (kaikeiHime.cost)
                    }
//syuuzen・修繕費
                    if myCategory == "修繕費の支払い" {
                        //print("修繕費を保存しました")
                        kaikeiHime.syuuzen = (kaikeiHime.cost)
                    }
//zattsu・雑費
                    
                    
//nameKarikata1・借方1行目
                let nameKarikata1 = String(振替借方科目1行目.text!)//
                kaikeiHime.nameKarikata1 = nameKarikata1
                    if 振替貸方科目1行目.text == "現金" {
                        //貸方の現金の仕訳はマイナスします
                        kaikeiHime.genkin = kaikeiHime.cost
                    }
                    if 振替貸方科目1行目.text == "当座預金" {
                        //貸方の当座預金はマイナスします
                        kaikeiHime.touza = kaikeiHime.cost
                    }
                    if 振替貸方科目1行目.text == "普通預金" {
                        //貸方の普通預金はマイナスします
                        kaikeiHime.futsuu = kaikeiHime.cost
                    }
                        if 振替貸方科目1行目.text == "受取利息" {
                            kaikeiHime.uketoririsoku = kaikeiHime.cost
                        }
                        if 振替貸方科目1行目.text == "雑収入" {
                            kaikeiHime.zattsu = kaikeiHime.cost
                        }
//kariBumon1・借方1行目部門
                    let kariBumon1 = String(振替借方部門1行目.text!)//ここで追加します
                    kaikeiHime.kariBumon1 = kariBumon1
//kariHojyo1・借方1行目補助
                    let kariHojyo1 = String(振替借方補助1行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo1 = kariHojyo1
//kariBumon2・借方行目部門
                    let kariBumon2 = String(振替借方部門2行目.text!)//ここで追加します
                    kaikeiHime.kariBumon2 = kariBumon2
//kariHojyo2・借方行目補助
                    let kariHojyo2 = String(振替借方補助2行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo2 = kariHojyo2
//kariBumon3・借方行目部門
                    let kariBumon3 = String(振替借方部門3行目.text!)//ここで追加します
                    kaikeiHime.kariBumon3 = kariBumon3
//kariHojyo3・借方行目補助
                    let kariHojyo3 = String(振替借方補助3行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo3 = kariHojyo3
//kariBumon4・借方行目部門
                    let kariBumon4 = String(振替借方部門4行目.text!)//ここで追加します
                    kaikeiHime.kariBumon4 = kariBumon4
//kariHojyo4・借方行目補助
                    let kariHojyo4 = String(振替借方補助4行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo4 = kariHojyo4
//kariBumon5・借方行目部門
                    let kariBumon5 = String(振替借方部門5行目.text!)//ここで追加します
                    kaikeiHime.kariBumon5 = kariBumon5
//kariHojyo5・借方行目補助
                    let kariHojyo5 = String(振替借方補助5行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo5 = kariHojyo5
//kariBumon6・借方行目部門
                    let kariBumon6 = String(振替借方部門6行目.text!)//ここで追加します
                    kaikeiHime.kariBumon6 = kariBumon6
//kariHojyo6・借方行目補助
                    let kariHojyo6 = String(振替借方補助6行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo6 = kariHojyo6
//kariBumon7・借方行目部門
                    let kariBumon7 = String(振替借方部門7行目.text!)//ここで追加します
                    kaikeiHime.kariBumon7 = kariBumon7
//kariHojyo7・借方行目補助
                    let kariHojyo7 = String(振替借方補助7行目.text!)//ここで追加します
                    kaikeiHime.kariHojyo7 = kariHojyo7

//nameKashikata1・貸方1行目
                let nameKashikata1 = String(振替貸方科目1行目.text!)//ここで追加します
                kaikeiHime.nameKashikata1 = nameKashikata1
                    
                    if 振替貸方科目1行目.text == "現金" {
                        //貸方の現金の仕訳はマイナスします
                        kaikeiHime.genkin = -kaikeiHime.cost
                    }
                    if 振替貸方科目1行目.text == "当座預金" {
                        //貸方の当座預金はマイナスします
                        kaikeiHime.touza = -kaikeiHime.cost
                    }
                    if 振替貸方科目1行目.text == "普通預金" {
                        //貸方の普通預金はマイナスします
                        kaikeiHime.futsuu = -kaikeiHime.cost
                    }
/*                        if 振替貸方科目1行目.text == "期末商品棚卸高" {
                            kaikeiHime.kimatsutana = kaikeiHime.cost
                        }
                        if 振替貸方科目1行目.text == "商品" {
                            //貸方の商品はマイナスします
                            kaikeiHime.shouhin = -kaikeiHime.cost
                        }
*/
//nameKashikata2・貸方2行目
                    let nameKashikata2 = String(振替貸方科目2行目.text!)//ここで追加します
                    kaikeiHime.nameKashikata2 = nameKashikata2
                    
//bumon1・貸方1行目部門
                    let kashiBumon1 = String(振替貸方部門1行目.text!)//ここで追加します
                    kaikeiHime.kashiBumon1 = kashiBumon1
//hojyo1・貸方1行目補助
                    let kashiHojyo1 = String(振替貸方補助1行目.text!)//ここで追加します
                    kaikeiHime.kashiHojyo1 = kashiHojyo1
//bumon1・貸方2行目部門
                    let kashiBumon2 = String(振替貸方部門2行目.text!)//ここで追加します
                    kaikeiHime.kashiBumon2 = kashiBumon2
//hojyo1・貸方2行目補助
                    let kashiHojyo2 = String(振替貸方補助2行目.text!)//ここで追加します
                    kaikeiHime.kashiHojyo2 = kashiHojyo2
                }
            }
        }
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        if let kaikeiHime = kaikeiHime {
            context.delete(kaikeiHime)
            //print("kaikeiHime = \(kaikeiHime)")
            //sumCost = 0.0
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func insertNumber(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if costLabel.text == "0" {
            costLabel.text = String(sender.tag)
        } else if placehold {
            costLabel.text = String(sender.tag)
            placehold = false
        } else {
            costLabel.text = costLabel.text! + String(sender.tag)
        }
    }
    
    @IBAction func insert0(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if placehold {
            costLabel.text = "0"
            placehold = false
        } else if costLabel.text != "0" {
            if sender.tag == 11 {
                costLabel.text = costLabel.text! + "00"
            } else {
                costLabel.text = costLabel.text! + "0"
            }
        }
    }
    
    @IBAction func clearButtonTapped(_ sender: Any) {
        costLabel.text = "0"
        multiplyFlag = false
        placehold = false
        multiplyButton.isEnabled = true
    }
    
    @IBAction func multiplyButtonTapped(_ sender: Any) {
        multiplyFlag = true
        placehold = true
        multiplyButton.isEnabled = false
        edNumber = Int(costLabel.text!)!
    }
    
    @IBAction func equalButtonTapped(_ sender: Any) {
        if multiplyFlag {
            costLabel.text = String(edNumber * Int(costLabel.text!)!)
            multiplyFlag = false
            multiplyButton.isEnabled = true
        }
    }
    
//MARK: - 借方ピッカーボタン

    @IBAction func 借方振替1行目ボタン(_ sender: UIButton) {
        振替伝票View.alpha = 0
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー1")
        借方振替1行目ボタンが押されました = true
        借方振替2行目ボタンが押されました = false
        借方振替3行目ボタンが押されました = false
        借方振替4行目ボタンが押されました = false
        借方振替5行目ボタンが押されました = false
        借方振替6行目ボタンが押されました = false
        借方振替7行目ボタンが押されました = false
        if 振替借方合計.text != 振替貸方合計.text {
            振替伝票View.alpha = 1
            振替伝票借方View.alpha = 1
            振替伝票貸方View.alpha = 1
            借方ピッカー部品.alpha = 0
            電卓.alpha = 1
            return
        }
    }
    @IBAction func 借方振替2行目ボタン(_ sender: UIButton) {
        振替借方小計2行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 0
        振替伝票貸方View.alpha = 1
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー2")
        借方振替1行目ボタンが押されました = false
        借方振替2行目ボタンが押されました = true
        借方振替3行目ボタンが押されました = false
        借方振替4行目ボタンが押されました = false
        借方振替5行目ボタンが押されました = false
        借方振替6行目ボタンが押されました = false
        借方振替7行目ボタンが押されました = false
    }
    @IBAction func 借方振替3行目ボタン(_ sender: UIButton) {
        振替借方小計3行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 0
        振替伝票貸方View.alpha = 1
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー3")
        借方振替1行目ボタンが押されました = false
        借方振替2行目ボタンが押されました = false
        借方振替3行目ボタンが押されました = true
        借方振替4行目ボタンが押されました = false
        借方振替5行目ボタンが押されました = false
        借方振替6行目ボタンが押されました = false
        借方振替7行目ボタンが押されました = false
    }
    @IBAction func 借方振替4行目ボタン(_ sender: UIButton) {
        振替借方小計4行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 0
        振替伝票貸方View.alpha = 1
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー4")
        借方振替1行目ボタンが押されました = false
        借方振替2行目ボタンが押されました = false
        借方振替3行目ボタンが押されました = false
        借方振替4行目ボタンが押されました = true
        借方振替5行目ボタンが押されました = false
        借方振替6行目ボタンが押されました = false
        借方振替7行目ボタンが押されました = false
    }
    @IBAction func 借方振替5行目ボタン(_ sender: UIButton) {
        振替借方小計5行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 0
        振替伝票貸方View.alpha = 1
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー5")
        借方振替1行目ボタンが押されました = false
        借方振替2行目ボタンが押されました = false
        借方振替3行目ボタンが押されました = false
        借方振替4行目ボタンが押されました = false
        借方振替5行目ボタンが押されました = true
        借方振替6行目ボタンが押されました = false
        借方振替7行目ボタンが押されました = false
    }
    @IBAction func 借方振替6行目ボタン(_ sender: UIButton) {
        振替借方小計6行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 0
        振替伝票貸方View.alpha = 1
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー6")
        借方振替1行目ボタンが押されました = false
        借方振替2行目ボタンが押されました = false
        借方振替3行目ボタンが押されました = false
        借方振替4行目ボタンが押されました = false
        借方振替5行目ボタンが押されました = false
        借方振替6行目ボタンが押されました = true
        借方振替7行目ボタンが押されました = false
    }
    @IBAction func 借方振替7行目ボタン(_ sender: UIButton) {
        振替借方小計7行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 0
        振替伝票貸方View.alpha = 1
        借方ピッカー部品.alpha = 1
        //print("借方ピッカー7")
        借方振替1行目ボタンが押されました = false
        借方振替2行目ボタンが押されました = false
        借方振替3行目ボタンが押されました = false
        借方振替4行目ボタンが押されました = false
        借方振替5行目ボタンが押されました = false
        借方振替6行目ボタンが押されました = false
        借方振替7行目ボタンが押されました = true
    }

    @IBAction func 貸方振替1行目ボタン(_ sender: UIButton) {
        電卓.alpha = 0
        振替伝票View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー1")
        貸方振替1行目ボタンが押されました = true
        貸方振替2行目ボタンが押されました = false
        貸方振替3行目ボタンが押されました = false
        貸方振替4行目ボタンが押されました = false
        貸方振替5行目ボタンが押されました = false
        貸方振替6行目ボタンが押されました = false
        貸方振替7行目ボタンが押されました = false
    }
    @IBAction func 貸方振替2行目ボタン(_ sender: UIButton) {
        振替貸方小計2行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 1
        振替伝票貸方View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー2")
        貸方振替1行目ボタンが押されました = false
        貸方振替2行目ボタンが押されました = true
        貸方振替3行目ボタンが押されました = false
        貸方振替4行目ボタンが押されました = false
        貸方振替5行目ボタンが押されました = false
        貸方振替6行目ボタンが押されました = false
        貸方振替7行目ボタンが押されました = false
    }
    @IBAction func 貸方振替3行目ボタン(_ sender: UIButton) {
        振替貸方小計3行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 1
        振替伝票貸方View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー3")
        貸方振替1行目ボタンが押されました = false
        貸方振替2行目ボタンが押されました = false
        貸方振替3行目ボタンが押されました = true
        貸方振替4行目ボタンが押されました = false
        貸方振替5行目ボタンが押されました = false
        貸方振替6行目ボタンが押されました = false
        貸方振替7行目ボタンが押されました = false
    }
    @IBAction func 貸方振替4行目ボタン(_ sender: UIButton) {
        振替貸方小計4行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 1
        振替伝票貸方View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー4")
        貸方振替1行目ボタンが押されました = false
        貸方振替2行目ボタンが押されました = false
        貸方振替3行目ボタンが押されました = false
        貸方振替4行目ボタンが押されました = true
        貸方振替5行目ボタンが押されました = false
        貸方振替6行目ボタンが押されました = false
        貸方振替7行目ボタンが押されました = false
    }
    @IBAction func 貸方振替5行目ボタン(_ sender: UIButton) {
        振替貸方小計5行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 1
        振替伝票貸方View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー5")
        貸方振替1行目ボタンが押されました = false
        貸方振替2行目ボタンが押されました = false
        貸方振替3行目ボタンが押されました = false
        貸方振替4行目ボタンが押されました = false
        貸方振替5行目ボタンが押されました = true
        貸方振替6行目ボタンが押されました = false
        貸方振替7行目ボタンが押されました = false
    }
    @IBAction func 貸方振替6行目ボタン(_ sender: UIButton) {
        振替貸方小計6行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 1
        振替伝票貸方View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー6")
        貸方振替1行目ボタンが押されました = false
        貸方振替2行目ボタンが押されました = false
        貸方振替3行目ボタンが押されました = false
        貸方振替4行目ボタンが押されました = false
        貸方振替5行目ボタンが押されました = false
        貸方振替6行目ボタンが押されました = true
        貸方振替7行目ボタンが押されました = false
    }
    @IBAction func 貸方振替7行目ボタン(_ sender: UIButton) {
        振替貸方小計7行目.text = "0"
        電卓.alpha = 0
        振替伝票借方View.alpha = 1
        振替伝票貸方View.alpha = 0
        貸方ピッカー部品.alpha = 1
        //print("貸方ピッカー7")
        貸方振替1行目ボタンが押されました = false
        貸方振替2行目ボタンが押されました = false
        貸方振替3行目ボタンが押されました = false
        貸方振替4行目ボタンが押されました = false
        貸方振替5行目ボタンが押されました = false
        貸方振替6行目ボタンが押されました = false
        貸方振替7行目ボタンが押されました = true
    }
    
    
    
//MARK: - 買掛伝票ピッカー
    //pickerに表示する列数を返すデータソースメソッド.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //print("通過0")
        if (pickerView.tag == 1) {
            return 借方勘定科目.count
        }
        if (pickerView.tag == 2) {
            return 貸方勘定科目.count
        }
        return 借方勘定科目.count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する行数を返すデータソースメソッド
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //print("通過1")
        
        if (pickerView.tag == 1) {
            return 借方勘定科目[component].count//売掛伝票顧客[component].count
        }
        if (pickerView.tag == 2) {
            return 貸方勘定科目[component].count//売掛伝票顧客[component].count
        }
        
        return 借方勘定科目[component].count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する値を返すデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //print("通過2")
        
        if (pickerView.tag == 1) {
            return 借方勘定科目[component][row]//("\(売掛伝票顧客[row])")
        }
        if (pickerView.tag == 2) {
            return 貸方勘定科目[component][row]//("\(売掛伝票顧客[row])")
        }

        return 借方勘定科目[component][row]//returnは最後に追加したピッカーの変数を返します
    }
    
// MARK: - pickerが選択された際に呼ばれるデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print("通過3")
        
        if (pickerView.tag == 1) {

            if 借方振替1行目ボタンが押されました == true {
                振替借方科目1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                
                

                電卓.alpha = 0
                貸方ピッカー部品.alpha = 0
                貸方振替1行目ボタンが押されました = true
                //print("通過・借方振替1行目ボタンが押されました")
                if 振替借方合計.text != 振替貸方合計.text {
                    貸方ピッカー部品.alpha = 0
                    電卓.alpha = 1
                    振替伝票View.alpha = 1
                    振替伝票借方View.alpha = 1
                    振替伝票貸方View.alpha = 1
                    }
                
                if 借方ピッカーカウント == 2 {
                    借方ピッカー部品.alpha = 0
                    貸方ピッカー部品.alpha = 1
                    振替伝票View.alpha = 1
                    振替伝票借方View.alpha = 1
                    振替伝票貸方View.alpha = 0
                }
                借方ピッカーカウント += 1
                //print("借方ピッカーカウント += \(借方ピッカーカウント)")

                if 振替借方科目1行目.text == "期首商品棚卸高" {
                    print("期首商品棚卸高仕訳")
                    借方ピッカー部品.alpha = 0
                    貸方ピッカー部品.alpha = 0
                    //振替伝票View.alpha = 1
                    //借方ピッカー部品.delegate = self
                    //借方ピッカー部品.dataSource = self
                    // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
                    //借方ピッカー部品.selectRow(22, inComponent: 0, animated: true)
                    //借方ピッカー部品.selectRow(2, inComponent: 1, animated: false)
                    //借方ピッカー部品.selectRow(3, inComponent: 2, animated: false)
                    //借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
                    
                    //振替借方科目1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                    //振替借方部門1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                    //振替借方補助1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                    振替借方部門1行目.text = ""
                    振替借方補助1行目.text = ""
                    
                    振替貸方科目1行目.text = "商品"
                    振替貸方部門1行目.text = ""
                    振替貸方補助1行目.text = ""
                    電卓.alpha = 1
                    振替伝票View.alpha = 1
                    振替伝票借方View.alpha = 1
                    振替伝票貸方View.alpha = 1
                    
                    // 選択中の行をハイライト
                    //借方ピッカー部品.showsSelectionIndicator = true
                }
                
                if 振替借方科目1行目.text == "商品" {
                    print("商品仕訳")
                    借方ピッカー部品.alpha = 0
                    貸方ピッカー部品.alpha = 0
                    //振替伝票View.alpha = 1
                    //借方ピッカー部品.delegate = self
                    //借方ピッカー部品.dataSource = self
                    // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
                    //借方ピッカー部品.selectRow(24, inComponent: 0, animated: true)
                    //借方ピッカー部品.selectRow(2, inComponent: 1, animated: false)
                    //借方ピッカー部品.selectRow(3, inComponent: 2, animated: false)
                    //借方ピッカー部品.selectRow(0, inComponent: 3, animated: false)
                    
                    //振替借方科目1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                    //振替借方部門1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                    //振替借方補助1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                    振替借方部門1行目.text = ""
                    振替借方補助1行目.text = ""

                    振替貸方科目1行目.text = "期末商品棚卸高"
                    振替貸方部門1行目.text = ""
                    振替貸方補助1行目.text = ""
                    電卓.alpha = 1
                    振替伝票View.alpha = 1
                    振替伝票借方View.alpha = 1
                    振替伝票貸方View.alpha = 1
                    
                    // 選択中の行をハイライト
                    //借方ピッカー部品.showsSelectionIndicator = true
                }
            }

            if 借方振替2行目ボタンが押されました == true {
                振替借方科目2行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門2行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助2行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替伝票View.alpha = 1
                振替伝票借方View.alpha = 1
                電卓.alpha = 1
            }
            if 借方振替3行目ボタンが押されました == true {
                振替借方科目3行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門3行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助3行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替借方科目3行目.alpha = 1
                振替伝票借方View.alpha = 1
            }
            if 借方振替4行目ボタンが押されました == true {
                振替借方科目4行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門4行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助4行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替借方科目4行目.alpha = 1
                振替伝票借方View.alpha = 1
                電卓.frame = CGRect(x: 528, y: 483, width: 249, height: 253)
            }
            if 借方振替5行目ボタンが押されました == true {
                振替借方科目5行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門5行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助5行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替借方科目5行目.alpha = 1
                振替伝票借方View.alpha = 1
                電卓.frame = CGRect(x: 528, y: 483, width: 249, height: 253)
            }
            if 借方振替6行目ボタンが押されました == true {
                振替借方科目6行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門6行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助6行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替借方科目6行目.alpha = 1
                振替伝票借方View.alpha = 1
                電卓.frame = CGRect(x: 528, y: 483, width: 249, height: 253)
            }
            if 借方振替7行目ボタンが押されました == true {
                振替借方科目7行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替借方部門7行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替借方補助7行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替借方科目7行目.alpha = 1
                振替伝票借方View.alpha = 1
                電卓.frame = CGRect(x: 528, y: 483, width: 249, height: 253)
            }
            借方ピッカー選択 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 3)!
            
//category・現金買掛選択
            let 借方ピッカー選択Index = Int(借方ピッカー選択)
            if 借方ピッカー選択Index! < 4 {
            categorySegmentedControl1.selectedSegmentIndex = 借方ピッカー選択Index!
            }
            //print("借方ピッカー選択Index = \(借方ピッカー選択Index!)")
            
//ここ会計姫categories
            if 借方ピッカー選択Index! < 4 {
            myCategory = 会計姫categories[categorySegmentedControl1.selectedSegmentIndex]
            }
            //print("myCategory = \(myCategory!)")
            
            if 借方ピッカー選択Index == 0 {
                categorySegmentedControl1.selectedSegmentIndex = 0
                categorySegmentedControl2.selectedSegmentIndex = -1
            }
            
            if 借方ピッカー選択Index == 1 {
                categorySegmentedControl1.selectedSegmentIndex = 1
                categorySegmentedControl2.selectedSegmentIndex = -1
            }
            
            if 借方ピッカー選択Index == 2 {
                categorySegmentedControl1.selectedSegmentIndex = 2
                categorySegmentedControl2.selectedSegmentIndex = -1
            }
            
            if 借方ピッカー選択Index == 3 {
                categorySegmentedControl1.selectedSegmentIndex = 3
                categorySegmentedControl2.selectedSegmentIndex = -1
            }
            
            if 借方ピッカー選択Index == 4 {
                categorySegmentedControl1.selectedSegmentIndex = 4
                categorySegmentedControl2.selectedSegmentIndex = -1
            }
            
            if 借方ピッカー選択Index == 4 {
                categorySegmentedControl1.selectedSegmentIndex = 4
                categorySegmentedControl2.selectedSegmentIndex = -1
            }
            
            if 借方ピッカー選択Index == 5 {
                categorySegmentedControl1.selectedSegmentIndex = -1
                categorySegmentedControl2.selectedSegmentIndex = 0
            }
            if 借方ピッカー選択Index == 6 {
                categorySegmentedControl1.selectedSegmentIndex = -1
                categorySegmentedControl2.selectedSegmentIndex = 1
            }
            if 借方ピッカー選択Index == 7 {
                categorySegmentedControl1.selectedSegmentIndex = -1
                categorySegmentedControl2.selectedSegmentIndex = 2
            }
            if 借方ピッカー選択Index == 8 {
                categorySegmentedControl1.selectedSegmentIndex = -1
                categorySegmentedControl2.selectedSegmentIndex = 3
            }
            if 借方ピッカー選択Index == 9 {
                categorySegmentedControl1.selectedSegmentIndex = -1
                categorySegmentedControl2.selectedSegmentIndex = 4
            }
        }
        
        if (pickerView.tag == 2) {
            
            if 貸方振替1行目ボタンが押されました == true {
                振替貸方科目1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助1行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                
                //print("通過・貸方振替1行目ボタンが押されました")
                if 貸方ピッカーカウント == 2 {
                    借方ピッカー部品.alpha = 0
                    貸方ピッカー部品.alpha = 0
                    振替伝票View.alpha = 1
                    振替伝票借方View.alpha = 1
                    振替伝票貸方View.alpha = 1
                    電卓.alpha = 1
                }
                貸方ピッカーカウント += 1
                //print("貸方ピッカーカウント += \(貸方ピッカーカウント)")
                
            }
            if 貸方振替2行目ボタンが押されました == true {
                振替貸方科目2行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門2行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助2行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替貸方科目2行目.alpha = 1
                振替伝票貸方View.alpha = 1
                借方振替1行目ボタンが押されました = false
                貸方振替1行目ボタンが押されました = false
                //print("通過・貸方振替2行目ボタンが押されました")
            }
            if 貸方振替3行目ボタンが押されました == true {
                振替貸方科目3行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門3行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助3行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替貸方科目3行目.alpha = 1
                振替伝票貸方View.alpha = 1
                //print("通過・貸方振替3行目ボタンが押されました")
            }
            if 貸方振替4行目ボタンが押されました == true {
                振替貸方科目4行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門4行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助4行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替貸方科目4行目.alpha = 1
                振替伝票貸方View.alpha = 1
                電卓.frame = CGRect(x: 234, y: 483, width: 249, height: 253)
            }
            if 貸方振替5行目ボタンが押されました == true {
                振替貸方科目5行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門5行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助5行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替貸方科目5行目.alpha = 1
                振替伝票貸方View.alpha = 1
                電卓.frame = CGRect(x: 234, y: 483, width: 249, height: 253)
            }
            if 貸方振替6行目ボタンが押されました == true {
                振替貸方科目6行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門6行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助6行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替貸方科目6行目.alpha = 1
                振替伝票貸方View.alpha = 1
                電卓.frame = CGRect(x: 234, y: 483, width: 249, height: 253)
            }
            if 貸方振替7行目ボタンが押されました == true {
                振替貸方科目7行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
                振替貸方部門7行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
                振替貸方補助7行目.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
                振替貸方科目7行目.alpha = 1
                振替伝票貸方View.alpha = 1
                電卓.frame = CGRect(x: 234, y: 483, width: 249, height: 253)
            }
            
//ここ会計姫categories
            if categorySegmentedControl1.selectedSegmentIndex != -1 {
                myCategory = 会計姫categories[categorySegmentedControl1.selectedSegmentIndex]
            }
            
            if categorySegmentedControl2.selectedSegmentIndex == 0 {
                myCategory = 会計姫categories[categorySegmentedControl2.selectedSegmentIndex + 5]
            }
            //print("myCategory = \(myCategory!)")
            //print("categorySegmentedControl1.selectedSegmentIndex = \(categorySegmentedControl1.selectedSegmentIndex)")
            //print("categorySegmentedControl2.selectedSegmentIndex = \(categorySegmentedControl2.selectedSegmentIndex)")
        }
    }
    
    //参考サイトhttp://stackoverflow.com/questions/33655015/changing-font-and-its-size-of-a-picker-in-swift
// MARK: - ピッカーのフォントサイズ設定
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
//pickerView1
        var ピッカーフォント1: UILabel
        if let view = view as? UILabel {
            ピッカーフォント1 = view
        } else {
            ピッカーフォント1 = UILabel()
        }
        
        ピッカーフォント1.textColor = .black
        ピッカーフォント1.textAlignment = .center
        ピッカーフォント1.font = UIFont.systemFont(ofSize: 36)
        
        // where data is an Array of String
        if pickerView.tag == 1 {
            ピッカーフォント1.text = 借方勘定科目[component][row]//買掛顧客[row] as? String
            return ピッカーフォント1
        }
//ここまで
        
//pickerView2
        var ピッカーフォント2: UILabel
        if let view = view as? UILabel {
            ピッカーフォント2 = view
        } else {
            ピッカーフォント2 = UILabel()
        }
        
        ピッカーフォント2.textColor = .black
        ピッカーフォント2.textAlignment = .center
        ピッカーフォント2.font = UIFont.systemFont(ofSize: 36)
        
        // where data is an Array of String
        if pickerView.tag == 2 {
            ピッカーフォント2.text = 貸方勘定科目[component][row]//買掛顧客[row] as? String
            return ピッカーフォント2
        }
//ここまで
        
        
//新規ピッカーフォントはここに追加します
        
//ここまで
        
        return ピッカーフォント2//return変数は最後に追加した変数を書きます
    }
    
    // MARK: - 会計姫のピッカーサイズ
    func pickerView(_ pickerView: UIPickerView, widthForComponent component:Int) -> CGFloat {
        
        if (pickerView.tag == 1) {
            //return 569
            switch component {
            case 0:
                return 280//品名の幅
            case 1:
                return 80//数量の幅
            case 2:
                return 280//単価の幅
            case 3:
                return 0//その他の幅
            default: break
            }
        }
        if (pickerView.tag == 2) {
            switch component {
            case 0:
                return 150//品名の幅
            case 1:
                return 80//数量の幅
            case 2:
                return 280//単価の幅
            case 3:
                return 0//その他の幅
            default: break
            }
        }
        return 0//この場合は最後なので単価の幅です・34以下は万単位で1の桁が表示しません
    }
    
    // MARK: - ホイールのセルの高さの調節
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 50
    }
    //ホイールのセルの幅の調節・しかし反応なしです ?
    func pickerView(_ pickerView: UIPickerView, rowWidthForComponent component: Int) -> CGFloat {
        return 80
    }
    
//ここまで・ピッカー
    
}
