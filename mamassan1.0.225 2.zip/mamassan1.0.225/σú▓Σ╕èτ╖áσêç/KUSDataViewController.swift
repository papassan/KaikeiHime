//
//  DataViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/04/14.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit
import CoreData

// MARK: - Global Variables

class KUSDataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var 請求ピッカー部品: UIPickerView!
    @IBOutlet weak var 入金ピッカー部品: UIPickerView!
    @IBOutlet weak var 入金入力テキスト: UITextField!
    @IBOutlet weak var 入金入力差額ラベル: UILabel!
    @IBOutlet weak var 締切消費税ラベル: UILabel!
    @IBOutlet weak var 締切税抜ラベル: UILabel!
    @IBOutlet weak var dataLabel: UILabel!
    @IBOutlet weak var myView: UIView!
    
    var spendingTableView: UITableView!
    var graphView: UIView!
    var sumCostLabel: UILabel!
    var categoryButtons: [UIButton] = []
    
    var categoryButtonTapped結果 = 0
    
    // MARK: -
    
    var year: String = ""
    var month: String = ""
    var day: String = ""
    
    var 先月: Int16 = 6
    var 今月: Int16 = 7
    
    
    // MARK: -
    
    let segueEditSpendingViewController = "SegueEditSpendingViewController"
    let segueAddSpendingViewController = "SegueAddSpendingViewController"
    
    // MARK: - Properties for Fetching
    
    var monthData:[String] = {
        var monthData:[String] = []
        let dateFormatter = DateFormatter()
        monthData = dateFormatter.monthSymbols
//print("dateFormatter = \(dateFormatter)")
//print("monthData = \(monthData)")
        return monthData
    }()
//ここuriages
//ここUriage
    var uriage: Uriage?
    var uriages: [Uriage] = []
    var retreatedSpendings: [Uriage] = []

    var taisyaku: Taisyaku?
    var kaikeiHime: KaikeiHime?
    
    var myDate: [Int] = {
        var myDate: [Int] = []
        // get current date
        let now = Date()
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: now)
        // assign them to myDate[]
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate.append(year)
            myDate.append(month)
            myDate.append(day)
        }
        return myDate
    }()
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    //var taisyakus: [Taisyaku] = []//貸借対照表のCoreData
    //var sonekis: [Soneki] = []//損益計算書のCoreData
    
    var 検索変更 = true
    var 税込価格Int = 0
    var 締切消費税Int = 0
    var 支払方法 = ""
//var 顧客ID: String <- この初期化ではエラーです
    var 支払補助科目: String = ""
    var 普通預金補助科目ピッカーrowInt = 0
    var 売上締切詳細内容 = ""
    var 請求顧客ピッカー選択 = ""
    var 普通預金補助科目 = ""
    var 入金勘定科目 = ""
    var 支払補助科目Int = 0
    var sumCostInt = 0
    var 締切消費税 = 0
    var 締切ボタン = 0
    var 純売上Int = 0
    var 入金入力テキストInt = 0
    var 顧客の締日 = ""
    
    var カテゴリーボタンの状態 = true
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

//伝票数 = uriages.count
//print("伝票数 = \(uriages.count)")
        
        
        入金入力テキスト.delegate = self
//print("year = \(year)")
//print("month = \(month)")
        dataLabel!.text = "\(month), \(year)"
        
        請求ピッカー部品.delegate = self
        請求ピッカー部品.dataSource = self
        請求ピッカー部品.alpha = 1

        入金ピッカー部品.delegate = self
        入金ピッカー部品.dataSource = self
        入金ピッカー部品.alpha = 1
        
        createMyView()
        addButtons()
    }
//テキストフィールドでenterを押すと呼ばれます
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//print("通過textFieldShouldReturn")
//print("1売上締切詳細内容 = \(売上締切詳細内容)")
        var 入金入力テキストString = 入金入力テキスト.text
        if 入金入力テキスト.text == "" || 入金入力テキスト.text == "振込料" {
            //print("通過 = 入金入力テキスト")
            入金入力テキストString = "0"
        }
        
//print("入金入力テキストString = \(入金入力テキストString!)")
            入金入力テキストInt = Int(入金入力テキストString!)!//Int振込料
//print("入金入力テキストInt = \(入金入力テキストInt)")
            純売上Int = 税込価格Int - 入金入力テキストInt
//print("純売上Int = \(純売上Int)")

        let カンマ付き入金入力差額ラベル = NSNumber(value: 純売上Int)
        カンマフォーマッタ()
        入金入力差額ラベル.text = フォーマッタ.string(from: カンマ付き入金入力差額ラベル)! + "円"
            //入金入力差額ラベル.text = String(純売上Int)
//書き込み
        入金入力テキスト.resignFirstResponder()
        保存()
        return true
    }
//金額にカンマを付ける関数
    func カンマフォーマッタ() {
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
    }
    
    func 保存() {
//print("通過・保存")
        // create new Spending object if nothing is got from segue
        if uriage == nil {
            uriage = Uriage(context: context)
        }
        
        let myCategory = 売上締日.first
        // configure Spending object
        if let uriage = uriage {
            uriage.year = Int16(myDate[0])
            uriage.month = Int16(myDate[1])
            uriage.day = Int16(myDate[2])
            uriage.category = 売上締切詳細内容
//print("2売上締切詳細内容 = \(売上締切詳細内容)")
            taisyaku?.category = myCategory
//ナンバー
            uriage.number = 1
//入金処理
            uriage.urikake = -Int32(純売上Int) + Int32(締切消費税)
            uriage.futsuu = Int32(純売上Int)
            uriage.nyuukin = Int32(純売上Int)
            uriage.zeikomikakaku = Int32(税込価格Int)
            uriage.uriagedaka = -Int32(入金入力テキストInt) + Int32(締切消費税)
            
//print("uriage.urikake = \(uriage.urikake)")
            uriage.name = 請求顧客ピッカー選択
            uriage.details1 = "入金しました"
            if 売上締切詳細内容 == "締切" {
                uriage.details1 = "締切しました"
            }
            uriage.retailer1 = 売掛伝票入金[1][支払補助科目Int]
//品名復元
            uriage.restoredItemName = "1"
//数量復元
            uriage.restoredQuantity = "2"
//単価復元
            uriage.restoredUnitPrice = "3"
            fetchSpendings()
            }

//MARK: - 書き込んでいる
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//print("\nviewWillAppear・ラスト伝票番号は\(ラスト伝票番号)番です\n")
//print("通過 = override func viewWillAppear")
        fetchSpendings()
//ボタンの色
        categoryButtonsAllColored()
//グラフ
        drawPieChart()
    }
    
    func drawPieChart() {
        let center = CGPoint(x: graphView.frame.height / 2, y: graphView.frame.height / 2)
        //グラフ円のサイズ
        let radius: CGFloat = graphView.frame.height * 0.12//2

//ここuriages
        //合計を計算する関数をpercentsPerCategoryに代入している
//伝票数 = uriages.count
//print("伝票数 = \(uriages.count)")
        let percentsPerCategory = calculatePercentPerCategory(uriages)
        if let graphImageView = drawPieChartImageView(center: center, radius: radius, percentsPerCategory: percentsPerCategory) {
            graphView.addSubview(graphImageView)
        }
    }
    
    func createMyView() {
        // create view for graph
        graphView = UIView()
        let graphViewFrame = CGRect(x: 0.0, y: 0.0, width: myView.frame.width, height: myView.frame.width * 0.2)//0.7・分類とかの幅
        //(0.0, 0.0, 984.0, 295.2)
        
        graphView.frame = graphViewFrame
        myView.addSubview(graphView)
        
        // create label for sum cost
        sumCostLabel = UILabel()
        sumCostLabel.frame = CGRect(x: myView.frame.width * 0.5, y: graphView.frame.height-30.0, width: myView.frame.width * 0.45, height: 30.0)
        sumCostLabel.text = "計 0 円"
        sumCostLabel.backgroundColor = .white
        sumCostLabel.textAlignment = NSTextAlignment.right
        myView.addSubview(sumCostLabel)
        
        // create table view for spendings
        spendingTableView = UITableView()
        let tableViewFrame = CGRect(x: 0.0, y: graphView.frame.maxY, width: myView.frame.width, height: myView.frame.height - graphView.frame.height - 56.8)
        //(0.0, 295.2, 984.0, 406.8)//406.8 - 56.8の意味は引かないとスクロールしなくなる
        //print("tableViewFrame = \(tableViewFrame)")
        //print("myView.frame.width = \(myView.frame.width)")
        
        //画面の左端まで線を到達させる、しかし反応しない
        spendingTableView.layoutMargins = .zero
        spendingTableView.separatorInset = .zero
        spendingTableView.frame = tableViewFrame
        myView.addSubview(spendingTableView)
        spendingTableView.delegate = self
        spendingTableView.dataSource = self
        
    }
    //追加1
    func fetchSpendings() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
//Uriage
//Uriage
            let fetchRequest: NSFetchRequest<Uriage> = Uriage.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                //fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                fetchRequest.predicate = NSPredicate(format: "month BETWEEN {%d, %d}", monthIndex, monthIndex + 1)
                
                先月 = Int16(monthIndex)
                今月 = Int16(monthIndex + 1)
                
//print("fetchRequest = \(fetchRequest)")
//print("monthIndex = \(monthIndex)")
//print("fetchRequest.predicate = \(fetchRequest.predicate!)")
//print("day = \(day)")
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "category", ascending: true), NSSortDescriptor(key: "cost", ascending: false), NSSortDescriptor(key: "day", ascending: true), NSSortDescriptor(key: "details", ascending: false),NSSortDescriptor(key: "details1", ascending: false),NSSortDescriptor(key: "details2", ascending: false), NSSortDescriptor(key: "details3", ascending: false),NSSortDescriptor(key: "details4", ascending: false),NSSortDescriptor(key: "details5", ascending: false),NSSortDescriptor(key: "details6", ascending: false),NSSortDescriptor(key: "details7", ascending: false), NSSortDescriptor(key: "genkin", ascending: false), NSSortDescriptor(key: "kaikake", ascending: false), NSSortDescriptor(key: "month", ascending: false), NSSortDescriptor(key: "name", ascending: false), NSSortDescriptor(key: "retailer", ascending: false),NSSortDescriptor(key: "retailer1", ascending: false),NSSortDescriptor(key: "retailer2", ascending: false), NSSortDescriptor(key: "number", ascending: false), NSSortDescriptor(key: "quantity", ascending: false),NSSortDescriptor(key: "quantity1", ascending: false),NSSortDescriptor(key: "quantity2", ascending: false), NSSortDescriptor(key: "total", ascending: false),NSSortDescriptor(key: "total1", ascending: false),NSSortDescriptor(key: "total2", ascending: false), NSSortDescriptor(key: "unit", ascending: false),NSSortDescriptor(key: "unit1", ascending: false),NSSortDescriptor(key: "unit2", ascending: false), NSSortDescriptor(key: "restoredItemName", ascending: false), NSSortDescriptor(key: "restoredQuantity", ascending: false), NSSortDescriptor(key: "restoredUnitPrice", ascending: false), NSSortDescriptor(key: "unitPrice", ascending: false), NSSortDescriptor(key: "unitPrice1", ascending: false), NSSortDescriptor(key: "unitPrice2", ascending: false), NSSortDescriptor(key: "urikake", ascending: false), NSSortDescriptor(key: "uriagedaka", ascending: false)]//ここで追加します
            }
            //ここuriages
            uriages = try context.fetch(fetchRequest)
        } catch {
            print("Spendings Data Fetching Failed.")
        }
伝票数 = uriages.count
//print("伝票数 = \(uriages.count)")
//print("uriages = \(uriages)")
        spendingTableView.reloadData()
    }

    func arcPercent(center: CGPoint, radius: CGFloat, startAngle: CGFloat, percent: Double) -> UIBezierPath {
        // draw one arc
        let endAngle = 2 * Double.pi * percent + Double(startAngle)
        //188.8
        //print("endAngle = \(endAngle)")
        let path = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: CGFloat(endAngle), clockwise: true)
        //print("path = \(path)")
        path.lineWidth = radius * 2.0
        path.lineCapStyle = .butt
        return path
    }
//円グラフ表示用のボタン
    func addButtons() {
        for i in 0..<売上締日.count {
            let buttonWidth: CGFloat = graphView.frame.width - graphView.frame.height - 500//40ボタンの幅
            //print("buttonWidth = \(buttonWidth)")
            let buttonHeight: CGFloat = (graphView.frame.height - sumCostLabel.frame.height) / CGFloat(売上締日詳細.count) - CGFloat(売上締日詳細.count + 1) + 10
            //print("buttonHeight = \(buttonHeight)")
            let buttonRect = CGRect(x: graphView.frame.height + 10, y: (buttonHeight + 1.0) * CGFloat(i) + 3.0, width: buttonWidth, height: buttonHeight)
            //print("buttonRect = \(buttonRect)")
            categoryButtons.append(UIBounceButton(frame: buttonRect))
            categoryButtons[i].layer.cornerRadius = 5
            categoryButtons[i].backgroundColor = colors[i]
            categoryButtons[i].setTitle(売上締日[i], for: .normal)
            categoryButtons[i].setTitleColor(.black, for: .normal)
            categoryButtons[i].tag = i
            categoryButtons[i].addTarget(self, action: #selector(self.categoryButtonTapped(_:)), for: .touchUpInside)
            graphView.addSubview(categoryButtons[i])
        }
    }
//ここuriages
//ここuriages
    func categoryButtonTapped(_ sender: UIButton) {
//print("請求顧客ピッカー選択 = \(請求顧客ピッカー選択)")

//print("前uriages.count = \(uriages.count)")
        請求ピッカー部品.alpha = 0
        categoryButtonTapped結果 = sender.tag
//print("categoryButtonTapped結果 = \(categoryButtonTapped結果)")
        for i in 0..<売上締日.count {
        categoryButtons[i].alpha = 0
        }
        categoryButtons[categoryButtonTapped結果].alpha = 1
        if sender.backgroundColor != .gray {
            categoryButtons[sender.tag].backgroundColor = .gray
//print("前categoryButtons[sender.tag] = \(categoryButtons[sender.tag])")
            
//カテゴリーボタンの項目(売上締日詳細[sender.tag])のデータをretreatedSpendingsに保存している
//つまり表示したくないデータを保存している
            if categoryButtonTapped結果 < 5 {
            for i in 0..<uriages.count {
                if uriages[i].category! != 売上締日詳細[sender.tag] {
                    retreatedSpendings.append(uriages[i])
                }
            }
                uriages = uriages.filter { $0.category! == 売上締日詳細[sender.tag] }
            }
            //print("通過categoryButtonTapped結果 < 5 = \(retreatedSpendings)")
            //print("uriages = \(uriages)")
            
            if 売上締日詳細[sender.tag] == "締切" {
                売上締切詳細内容 = 売上締日詳細[sender.tag]
                //print("締切通過1")
//print("伝票数前 = \(uriages.count)")
                締切ボタン = 1
                for i in 0..<uriages.count {
                    if uriages[i].name! != 請求顧客ピッカー選択 {
                        retreatedSpendings.append(uriages[i])
                    }
                }
//請求顧客ピッカー選択の名前だけを選択します
                uriages = uriages.filter { $0.name! == 請求顧客ピッカー選択 }
//更に
                
//print("請求顧客ピッカー選択 = \(請求顧客ピッカー選択)")
//print("顧客の締日 = \(顧客の締日)")
//15日締日
                if 顧客の締日 == "1" {
                    uriages = uriages.filter { $0.month == 先月 && $0.day > 16 || $0.month == 今月 && $0.day <= 15 }
                }
//25日締日
                if 顧客の締日 == "2" {
                uriages = uriages.filter { $0.month == 先月 && $0.day > 26 || $0.month == 今月 && $0.day <= 25 }
                }
//末日締日
                if 顧客の締日 == "3" {
                    uriages = uriages.filter { $0.month == 今月 }
                }
                //print("後通過1")
                //print("uriages = \(uriages)")
                //print("通過if 売上締日詳細[sender.tag] = \(retreatedSpendings)")
                伝票数 = uriages.count
//print("伝票数後 = \(伝票数)")
//print("先月 = \(先月)")
//print("今月 = \(今月)")
            }
            if 売上締日詳細[sender.tag] == "入金" {
                売上締切詳細内容 = 売上締日詳細[sender.tag]
                //print("入金通過1")
//print("3売上締切詳細内容 = \(売上締切詳細内容)")
                for i in 0..<uriages.count {
                    if uriages[i].name! != 請求顧客ピッカー選択 {
                        retreatedSpendings.append(uriages[i])
                    }
                }
                //print("入金通過1retreatedSpendings = \(retreatedSpendings)")
                uriages = uriages.filter { $0.name! == 請求顧客ピッカー選択 }
                //15日締日
                if 顧客の締日 == "1" {
                    uriages = uriages.filter { $0.month == 先月 && $0.day > 16 || $0.month == 今月 && $0.day <= 15 }
                }
                //25日締日
                if 顧客の締日 == "2" {
                    uriages = uriages.filter { $0.month == 先月 && $0.day > 26 || $0.month == 今月 && $0.day <= 25 }
                }
                //末日締日
                if 顧客の締日 == "3" {
                    uriages = uriages.filter { $0.month == 今月 }
                }
            }
//ここuriages
//ここuriages
//カテゴリーボタンの項目のデータを総データから取り除いています
//つまり表示したくないデータを取り除いている
        } else {
            請求ピッカー部品.alpha = 1
            for i in 0..<売上締日.count {
                categoryButtons[i].alpha = 1
            }
            if categoryButtonTapped結果 < 5 {
//print("categoryButtons[sender.tag].backgroundColor = 通過")
            categoryButtons[sender.tag].backgroundColor = colors[sender.tag]
//表示しているデータに取り除いたデータを結合している
                for retreatedSpending in retreatedSpendings {
                    if retreatedSpending.category! != 売上締日詳細[sender.tag] {
//ここuriages
                        uriages.append(retreatedSpending)
                    }
                }
            }
            if 売上締日詳細[sender.tag] == "締切" {
//print("締切通過2")
                categoryButtons[sender.tag].backgroundColor = colors[sender.tag]
                for retreatedSpending in retreatedSpendings {
                    if retreatedSpending.name! != 請求顧客ピッカー選択 {
//ここuriages
                        uriages.append(retreatedSpending)
                    }
                }
                //print("後通過2")
            }
            if 売上締日詳細[sender.tag] == "入金" {
                //print("入金通過2")
                categoryButtons[sender.tag].backgroundColor = colors[sender.tag]
                for retreatedSpending in retreatedSpendings {
                    if retreatedSpending.name! != 請求顧客ピッカー選択 {
                        //ここuriages
                        uriages.append(retreatedSpending)
                    }
                }
            }
            //print("retreatedSpendings = retreatedSpendings.filter 通過")
            //print("前retreatedSpendings = \(retreatedSpendings)")
//保存している表示したくないデータを削除している
            if categoryButtonTapped結果 < 5 {
            retreatedSpendings = retreatedSpendings.filter { $0.category! == 売上締日詳細[sender.tag] }
            }
            if 売上締日詳細[sender.tag] == "締切" {
                //print("締切通過3")
                retreatedSpendings = retreatedSpendings.filter { $0.name! == 請求顧客ピッカー選択 }
                請求ピッカー部品.alpha = 1
            }
            if 売上締日詳細[sender.tag] == "入金" {
                //print("入金通過3")
                retreatedSpendings = retreatedSpendings.filter { $0.name! == 請求顧客ピッカー選択 }
            }
            //print("後retreatedSpendings = \(retreatedSpendings)")
            //print("$0.category!伝票数 = \(uriages.count)")
//ここuriages
            uriages.sort(by: {$0.day < $1.day})
        }
            //print("通過4")
            //print("通過4伝票数 = \(uriages.count)")
        spendingTableView.reloadData()
        drawPieChart()
    }
//}
    
//ボタンの色
    func categoryButtonsAllColored() {
        for i in 0..<categoryButtons.count {
            categoryButtons[i].backgroundColor = colors[i]
        }
    }
//func drawPieChart()で呼ばれます
//ここUriage
    func calculatePercentPerCategory(_ spendings: [Uriage]) -> [(category: String, percent: Double)] {
        var percents: [Double] = {
            var percents: [Double] = []
            for _ in 0..<売上締日詳細.count {
                percents.append(0.0)
            }
//売上締日詳細配列の総数
            //print("売上締日詳細.count = \(売上締日詳細.count)")
            //print("percents = \(percents)")
            return percents
        }()
        
        var sumCost1: [Double] = {
            var sumCost1: [Double] = []
            for _ in 0..<売上締日詳細.count {
                sumCost1.append(0.0)
            }
            //売上締日詳細配列の総数
            //print("売上締日詳細.count = \(売上締日詳細.count)")
            //print("percents = \(percents)")
            return sumCost1
        }()
        
        var sumCost = 0.0
        
        //totalの合計を計算している
//ここuriages
        for uriage in uriages {
            if let categoryIndex = 売上締日詳細.index(of: uriage.category!) {
                percents[categoryIndex] += Double(uriage.total)
                sumCost += Double(uriage.total)
                税込価格Int = Int(sumCost)
//print("税込価格Int = \(税込価格Int)")
                sumCost1[categoryIndex] += Double(uriage.total)
            }
        }
//グラフ用にパーセント変換しています
        for i in 0..<percents.count {
            percents[i] /= sumCost
        }
//print("percents[i] = \(percents)")
//print("売上締切詳細内容 = \(売上締切詳細内容)")
        
        if (売上締切詳細内容 == "締切" || 売上締切詳細内容 == "入金") && 請求顧客ピッカー選択 != "" {
//print("通過・if 売上締切詳細内容 == 締切 || 売上締切詳細内容 == 入金")
            let sumCost消費税 = sumCost * 1.08
//print("sumCost消費税 = \(sumCost消費税)")
            let 締切税抜金額 = sumCost
            税込価格Int = Int(sumCost消費税)
//print("税込価格Int = \(税込価格Int)")
            sumCostInt = Int(sumCost消費税)
            sumCost = Double(sumCostInt)
            
            締切消費税 = Int(締切税抜金額 * 消費税率)
//print("締切消費税 = \(締切消費税)")
            let 締切消費税Int = Int(締切消費税)
            let カンマ付き締切消費税ラベル = NSNumber(value: 締切消費税Int)
            カンマフォーマッタ()
            締切消費税ラベル.text = フォーマッタ.string(from: カンマ付き締切消費税ラベル)! + "円"
            let 締切税抜金額Int = Int(締切税抜金額)
            let カンマ付き締切税抜金額ラベル = NSNumber(value: 締切税抜金額Int)
            カンマフォーマッタ()
            締切税抜ラベル.text = フォーマッタ.string(from: カンマ付き締切税抜金額ラベル)! + "円"

//print("sumCostInt = \(sumCostInt)")
        }
        
        let カンマ付きsumCostLabelLabel = NSNumber(value: sumCost)
        //class KUSViewControllerletにグローバル設定しました・let フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        sumCostLabel.text = フォーマッタ.string(from: カンマ付きsumCostLabelLabel)! + "円"
        
        //print("sumCostLabel.text = \(sumCostLabel.text!)")
        //売上高 = 売上高 + Int(sumCostLabel.text!)!
        //sumCostLabel.text = "合計 \(Int(sumCost)) 円"
        
        var percentsPerCategory: [(category: String, percent: Double)] = []
        for i in 0..<percents.count {
            percentsPerCategory.append((category: 売上締日詳細[i], percent: percents[i]))
        }
//print("通過5")
        return percentsPerCategory
    }
    // MARK: - 円グラフを描画
    func drawPieChartImageView(center: CGPoint, radius: CGFloat, percentsPerCategory: [(category: String, percent: Double)]) -> UIImageView? {
        // begin drawing
        UIGraphicsBeginImageContextWithOptions(myView.bounds.size, false, 1.0)
        
        // initialization
        var startAngle = -Double.pi
        let sortedPercentsPerCategory = percentsPerCategory.sorted(by: {$0.percent > $1.percent})
        
        // return nil if the number of colors is short
        if sortedPercentsPerCategory.count > colors.count {
            return nil
        }
        
        // draw frame of pie chart
        let contextUriage = UIGraphicsGetCurrentContext()
        let frameWidthRatio: CGFloat = 2.05
        let whiteCircleRect = CGRect(x: center.x - radius * frameWidthRatio, y: center.y - radius * frameWidthRatio, width: 2 * frameWidthRatio * radius, height: 2 * frameWidthRatio * radius)
        let whiteCirclePath = UIBezierPath(ovalIn: whiteCircleRect)
        contextUriage?.setFillColor(UIColor.gray.cgColor)
        whiteCirclePath.fill()
        
        // draw PieChart per category
        for i in 0..<sortedPercentsPerCategory.count {
            if let colorIndex = 売上締日詳細.index(of: sortedPercentsPerCategory[i].category) {
                colors[colorIndex].setStroke()
            }
            let arcPath = arcPercent(center: center, radius: radius, startAngle: CGFloat(startAngle), percent: sortedPercentsPerCategory[i].percent)
            startAngle += 2 * Double.pi * sortedPercentsPerCategory[i].percent
            arcPath.stroke()
        }
        
        // get image from context and end drawing
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return UIImageView(image: image)
    }
    
// MARK: - Spending Table View Data Source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //検索ボタンと1番上のセルとの隙間
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30.0
    }
    
    //検索ボタン、セクションの文字色、文字サイズ、背景色、配置（中央寄せなど）、フォントを変更する
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        //ボタンセルの高さ・height: 30.0
        let cellRect = CGRect(x: 0, y: 0, width: myView.frame.width, height: 30.0)
        let cell = UIView(frame: cellRect)
        
        
        //検索ボタンの設定
        let sortButtons = UISegmentedControl(items: ["日付", "お客様", "締切", "金額"])
        sortButtons.frame.size = CGSize(width: cell.frame.width - 20, height: cell.frame.height)
        sortButtons.center = cell.center
        sortButtons.backgroundColor = self.view.backgroundColor//押されていないボタンの色、この場合はバックカラーです
        sortButtons.tintColor = .orange//押されたボタンの色
        sortButtons.selectedSegmentIndex = 0//初期のボタン選択場所0〜2
        sortButtons.addTarget(self, action: #selector(sortButtonTapped(_:)), for: .valueChanged)
        
        cell.addSubview(sortButtons)
        
        return cell
    }
    
    //4つのボタンが押されたら
//ここuriages
    func sortButtonTapped(_ sortButtons: UISegmentedControl) {
        if 検索変更 {
            検索変更 = false
        switch sortButtons.selectedSegmentIndex {
        case 0:
            print("true日付")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.day < uriage2.day
            })
        case 1:
            print("trueお客様")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                return uriage1.name! > uriage2.name!
            })
        case 2:
            print("true締切")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                return uriage1.category! > uriage2.category!
            })
        case 3:
            print("true金額")
            uriages.sort(by: { (uriage1, uriage2) -> Bool in
                return uriage1.total > uriage2.total
            })
        default:
            print("default")
        }
        } else {
            検索変更 = true
            print("false日付")
            switch sortButtons.selectedSegmentIndex {
            case 0:
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.day > uriage2.day
                })
            case 1:
                print("falseお客様")
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.name! < uriage2.name!
                })
            case 2:
                print("false締切")
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.category! < uriage2.category!
                })
            case 3:
                print("false金額")
                uriages.sort(by: { (uriage1, uriage2) -> Bool in
                    return uriage1.total < uriage2.total
                })
            default:
                print("default")
            }
        }
        if let indexPathes = spendingTableView.indexPathsForVisibleRows {
            spendingTableView.reloadRows(at: indexPathes, with: .automatic)
        }
    }
    
// MARK: - スクロール
//参考サイトhttp://qiita.com/noppefoxwolf/items/7b7f708de2ec09614282

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//ここuriages
        
//print("伝票数 = \(uriages.count)")
        return uriages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//print("通過・func tableView cellForRowAt")
//ここuriage
//ここuriages
        let uriage = uriages[indexPath.row]
        //print("indexPath.row = \(indexPath.row)")
//ここuriage
        let cell = configureSpendingCell(uriage: uriage)
        cell.layoutMargins = .zero
        return cell
    }
    
//MARK: - 一番下に来た時の処理
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
            //print("一番下に来た時の処理")
            }

//追加2・KUSDataViewControllerに表示する場合はここに追加します
//ここuriage
    func configureSpendingCell(uriage: Uriage) -> UITableViewCell {
        let cell = UITableViewCell()
//参考サイト http://joyplot.com/documents/2016/10/23/swift-uilabel/
// create day label
        let dayLabel = UILabel()
        dayLabel.sizeToFit()//文字列に合わせた領域確保
//ここuriage
        dayLabel.text = "\(uriage.day)日"//ここ
        dayLabel.numberOfLines = 0//改行桁・この場合は作動しません
        dayLabel.frame = CGRect(x: myView.frame.width * 0.01, y: 0.0, width: myView.frame.width / 5.0, height: cell.frame.height)
        //print("dayLabel.frame = \(dayLabel.frame)")
        dayLabel.textColor = .brown//文字色
        cell.addSubview(dayLabel)
        
        // create お客様 label
        let お客様Label = UILabel()
        お客様Label.sizeToFit()
//ここuriage
        //print("お客様Label.text = \(uriage.name!)")
        お客様Label.text = "\(uriage.name!)"//ここ
        お客様Label.frame = CGRect(x: myView.frame.width * 0.06, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        お客様Label.textColor = .red//文字色
        cell.addSubview(お客様Label)

        // create 品名 label
        let 品名Label = UILabel()
        品名Label.sizeToFit()
//ここuriage
        品名Label.text = "\(uriage.details1!)"//ここ
        品名Label.frame = CGRect(x: myView.frame.width * 0.32, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        品名Label.textColor = .green//文字色
        cell.addSubview(品名Label)

// create 適用 label
        let 適用Label = UILabel()
        適用Label.sizeToFit()
//ここuriage
        適用Label.text = "\(uriage.retailer1!)"//ここ
        if uriage.name == "現金顧客" {
            適用Label.text = "\(uriage.nameGenkin!)" + " 殿"
        }
        if 適用Label.text == " " {
            //print("適用Label.text = \(適用Label.text!)")
            適用Label.text = uriage.details6
        }
        適用Label.frame = CGRect(x: myView.frame.width * 0.58, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        適用Label.textColor = .blue
        cell.addSubview(適用Label)
        
        // create 締切 label
        let 締切Label = UILabel()
        締切Label.sizeToFit()
        //ここuriage
        締切Label.text = "\(uriage.category!)"//ここ
        締切Label.frame = CGRect(x: myView.frame.width * 0.85, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        締切Label.textColor = .orange
        cell.addSubview(締切Label)
        
        // create 伝票合計 label
        let 伝票合計Label = UILabel()
        伝票合計Label.sizeToFit()
//ここuriage
        var カンマ付き伝票合計Label = NSNumber(value: uriage.total)
        if uriage.nyuukin != 0 {
            カンマ付き伝票合計Label = NSNumber(value: uriage.nyuukin)
        }
        //class KUSViewControllerletにグローバル設定しました・let フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        伝票合計Label.text = フォーマッタ.string(from: カンマ付き伝票合計Label)! + "円"
        
        //伝票合計Label.text = "\(Int(uriage.total))円"
        伝票合計Label.textAlignment = .right
        伝票合計Label.frame = CGRect(x: myView.frame.width * 0.64, y: 0.0, width: myView.frame.width * 0.35, height: cell.frame.height)
        伝票合計Label.textColor = .black
        cell.addSubview(伝票合計Label)
        
        //CoreDataのnumber伝票番号はラスト伝票番号に代入されている
        //ラスト伝票番号は+1されて次の伝票番号になる
        ラスト伝票番号 = Int(uriage.number)
        //print("configureSpendingCell・ラスト伝票番号は\(ラスト伝票番号)番です")
        //print("configureSpendingCell・伝票数は\(伝票数)番です")
//print("通過・func configureSpendingCell")
        return cell
    }
    
    // MARK: - Spending Table View Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//ここuriages
        performSegue(withIdentifier: segueEditSpendingViewController, sender: uriages[indexPath.row])
//print("通過セル選択")
    }
    
    //売掛伝票ピッカー
    //pickerに表示する列数を返すデータソースメソッド.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//print("通過0")
        if (pickerView.tag == 1) {
            return 売掛伝票顧客.count//return 1
        }
        if (pickerView.tag == 2) {
            return 売掛伝票入金.count
        }
        return 売掛伝票入金.count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する行数を返すデータソースメソッド
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//print("通過1")
        if (pickerView.tag == 1) {
            return 売掛伝票顧客[component].count//売掛伝票顧客[component].count
        }
        if (pickerView.tag == 2) {
            return 売掛伝票入金[component].count
        }
        return 売掛伝票入金[component].count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する値を返すデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
//print("通過2")
        if (pickerView.tag == 1) {
            return 売掛伝票顧客[component][row]//("\(売掛伝票顧客[row])")
        }
        if (pickerView.tag == 2) {
            return 売掛伝票入金[component][row]
        }
        return 売掛伝票入金[component][row]//returnは最後に追加したピッカーの変数を返します
    }
    
    // MARK: - pickerが選択された際に呼ばれるデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
//print("通過3")
        if (pickerView.tag == 1) {
            請求顧客ピッカー選択 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)!
//print("請求顧客ピッカー選択 = \(請求顧客ピッカー選択)")
            顧客の締日 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 1)!
//print("顧客の締日 = \(顧客の締日)")
            支払方法 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 2)!
            支払補助科目 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 3)!
            支払補助科目Int = Int(支払補助科目)!
            
            //print("支払補助科目 = \(支払補助科目Int!)")
            //print("売掛伝票入金 = \(売掛伝票入金[1][支払補助科目Int!])")

//顧客の振込銀行のリールをセットする
            普通預金補助科目ピッカー設定(支払方法: 支払方法, 支払補助科目: 支払補助科目)
        }
        
        if (pickerView.tag == 2) {
        入金勘定科目 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)!
        普通預金補助科目 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)!
//print("入金勘定 = \(入金勘定!)")
//print("普通預金補助科目 = \(普通預金補助科目)")
        }
    }
    
    func 普通預金補助科目ピッカー設定(支払方法: String, 支払補助科目: String) {
        入金ピッカー部品.delegate = self
        入金ピッカー部品.dataSource = self
        // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
        let 支払方法Int = Int(支払方法)!//String顧客IDをInt顧客IDInt
        入金ピッカー部品.selectRow(支払方法Int, inComponent: 0, animated: false)
        let 支払補助科目Int = Int(支払補助科目)!//String顧客IDをInt顧客IDInt
        入金ピッカー部品.selectRow(支払補助科目Int, inComponent: 1, animated: false)
        // 選択中の行をハイライト
        入金ピッカー部品.showsSelectionIndicator = true
    }
    
    //参考サイトhttp://stackoverflow.com/questions/33655015/changing-font-and-its-size-of-a-picker-in-swift
    // MARK: - ピッカーのフォントサイズ設定
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        var 売上顧客フォント: UILabel
        if let view = view as? UILabel {
            売上顧客フォント = view
        } else {
            売上顧客フォント = UILabel()
        }
        
        売上顧客フォント.textColor = .black
        売上顧客フォント.textAlignment = .center
        売上顧客フォント.font = UIFont.systemFont(ofSize: 12)
        
        // where data is an Array of String
        if pickerView.tag == 1 {
            売上顧客フォント.text = 売掛伝票顧客[component][row]//売掛伝票顧客[row] as? String
            return 売上顧客フォント
        }

        var 入金ピッカー部品フォント: UILabel
        if let view = view as? UILabel {
            入金ピッカー部品フォント = view
        } else {
            入金ピッカー部品フォント = UILabel()
        }
        
        入金ピッカー部品フォント.textColor = .black
        入金ピッカー部品フォント.textAlignment = .center
        入金ピッカー部品フォント.font = UIFont.systemFont(ofSize: 12)
        
        // where data is an Array of String
        if pickerView.tag == 2 {
            入金ピッカー部品フォント.text = 売掛伝票入金[component][row]
            return 入金ピッカー部品フォント
        }
        
        //新規ピッカー追加はここに追加します
        //return変数は最後に追加した変数を書きます
        
        return 入金ピッカー部品フォント//return変数は最後に追加した変数を書きます
    }
    
    // MARK: - 品名のピッカーサイズ
    func pickerView(_ pickerView: UIPickerView, widthForComponent component:Int) -> CGFloat {
        
        if (pickerView.tag == 1) {
            return 160
        }
        if (pickerView.tag == 2) {
            switch component {
            case 0:
                return 50//品名の幅
            case 1:
                return 150//数量の幅
            default: break
            }
        }
        return 150//この場合は最後なので単価の幅です・34以下は万単位で1の桁が表示しません
    }
    
    // MARK: - ホイールのセルの高さの調節
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 20
    }
    //ホイールのセルの幅の調節・しかし反応なしです ?
    func pickerView(_ pickerView: UIPickerView, rowWidthForComponent component: Int) -> CGFloat {
        return 80
    }
//セルをタップすると呼ばれる
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//print("通過 = override func prepare")
        if segue.identifier == segueEditSpendingViewController {
//ここKUSAddViewController
            let destinationViewController = segue.destination as! KUSAddViewController//ここ
//ここuriage
//ここUriage
            destinationViewController.uriage = sender as! Uriage?
//print("通過 = segue.identifier == segueEditSpendingViewController")
//print("destinationViewController.uriage = \(destinationViewController.uriage!)")

        } else if segue.identifier == segueAddSpendingViewController {
//print("通過 = else if segue.identifier == segueAddSpendingViewController")
//ここKUSAddViewController
            let destinationViewController = segue.destination as! KUSAddViewController//ここ
            destinationViewController.myDate[0] = Int(year)!
            if let month = monthData.index(of: month) {
                destinationViewController.myDate[1] = month + 1
            }
        }
    }
}

