//
//  testViewController.swift
//  mamassan
//
//  Created by Toshikazu Fukuda on 2017/06/28.
//  Copyright © 2017年 Toshikazu Fukuda. All rights reserved.
//

import UIKit

class testViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func 転送(_ sender: UIButton) {
        // 送る対象の画像
        guard let image = imageView.image else {
            print("対象の画像が見つかりません")
            return
        }
//UIImageをPNG形式のデータにするとき
        let data = UIImagePNGRepresentation(image)
//JPEG形式のデータにするとき
        //let dataVar = UIImageJPEGRepresentation(image, <#CGFloat#>)
        
        // ファイル一時保存してNSURLを取得
        let url = NSURL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("アイコン.png")
        
        // 送信するファイル名
        //let filename = "アイコン.png"
        
        // 送信ファイルのパス
        let targetDirPath = "\(url!)"
        print("送信ファイルのパスは\n\(targetDirPath)\n")
        
        do {
        try data?.write(to: url!, options: .atomic)
        } catch {
            print(error)
        }
        
        let text = "sample text"
        let sampleUrl = NSURL(string: "http://www.apple.com/")!
        //let image = UIImage(named: "アイコン.jpg")!
        
        let items = [text, sampleUrl, image] as [Any]

        
        let controller = UIDocumentInteractionController(url: url!)
        
        // UIActivityViewControllerをインスタンス化
        let activityVc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        //iPadでは必要です
        activityVc.popoverPresentationController?.sourceView = view //UIView
        
        // UIAcitivityViewControllerを表示
        present(activityVc, animated: true, completion: nil)
        
        if !(controller.presentOpenInMenu(from: view.frame, in: view, animated: true)) {
//print("ファイルに対応するアプリがありません")
            let alert = UIAlertController(title: "送信失敗", message: "ファイルを送れるアプリが見つかりません", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }

    
    @IBAction func UIActivityViewControllerにURLと画像を渡して表示(_ sender: Any) {
        let text = "sample text"
        let sampleUrl = NSURL(string: "http://www.apple.com/")!
        let image = UIImage(named: "アイコン.jpg")!
        
        let items = [text, sampleUrl, image] as [Any]
        
        
        // UIActivityViewControllerをインスタンス化
        let activityVc = UIActivityViewController(activityItems: items, applicationActivities: nil)
//iPadでは必要です
        activityVc.popoverPresentationController?.sourceView = view //UIView
        
        // UIAcitivityViewControllerを表示
        present(activityVc, animated: true, completion: nil)
    }
}
