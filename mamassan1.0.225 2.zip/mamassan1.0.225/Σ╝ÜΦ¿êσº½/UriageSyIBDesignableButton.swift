//
//  IBDesignableButton.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/04/14.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit

@IBDesignable class UriageSyIBDesignableButton: UIButton {

    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = cornerRadius
        }
    }

}
