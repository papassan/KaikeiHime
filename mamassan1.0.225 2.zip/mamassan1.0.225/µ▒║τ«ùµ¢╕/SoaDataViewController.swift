//
//  PDataViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/25.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit
import CoreData

class SoaDataViewController: UIViewController {

    @IBOutlet weak var dataLabel: UILabel!
    var dataObject: AnyObject?
    
//画像移動・追加
    var pinchGesture = UIPinchGestureRecognizer()
    var startTransform:CGAffineTransform!
//ここまで

    @IBOutlet weak var 決算書: UIView!
    @IBOutlet weak var 貸借対照表: UIView!
    @IBOutlet weak var 現金: UILabel!
    @IBOutlet weak var 当座預金: UILabel!
    @IBOutlet weak var 普通預金: UILabel!
    @IBOutlet weak var 現金と預金の計: UILabel!
    @IBOutlet weak var 売掛金: UILabel!
    @IBOutlet weak var 売掛債権の計: UILabel!
    @IBOutlet weak var 商品: UILabel!
    @IBOutlet weak var 棚卸資産の計: UILabel!
    @IBOutlet weak var 未収収益: UILabel!
    @IBOutlet weak var その他流動資産の計: UILabel!
    @IBOutlet weak var 流動資産の計: UILabel!
    @IBOutlet weak var 車両運搬具: UILabel!
    @IBOutlet weak var 工具器具備品: UILabel!
    @IBOutlet weak var 有形固定資産の計: UILabel!
    @IBOutlet weak var 固定資産の計: UILabel!
    @IBOutlet weak var 繰延資産: UILabel!
    @IBOutlet weak var 繰延資産の計: UILabel!
    @IBOutlet weak var 資産の部の計: UILabel!
    
    @IBOutlet weak var 買掛金: UILabel!
    @IBOutlet weak var 未払金: UILabel!
    @IBOutlet weak var 預り金: UILabel!
    @IBOutlet weak var 流動負債の計: UILabel!
    @IBOutlet weak var 長期借入金: UILabel!
    @IBOutlet weak var 固定負債の計: UILabel!
    @IBOutlet weak var 負債の部の計: UILabel!
    
    @IBOutlet weak var 資本金: UILabel!
    @IBOutlet weak var 利益準備金: UILabel!
    @IBOutlet weak var 繰越利益剰余金: UILabel!
    @IBOutlet weak var 利益常用金の計: UILabel!
    @IBOutlet weak var 株主資本の計: UILabel!
    @IBOutlet weak var 純資産の部計: UILabel!
    @IBOutlet weak var 負債純資産の部計: UILabel!

    @IBOutlet weak var 損益計算書: UIView!
    @IBOutlet weak var 売上高: UILabel!
    @IBOutlet weak var 売上高の計: UILabel!
    @IBOutlet weak var 期首商品棚卸高: UILabel!
    @IBOutlet weak var 期首商品製品棚卸高: UILabel!
    @IBOutlet weak var 仕入高: UILabel!
    @IBOutlet weak var 当期商品仕入高: UILabel!
    @IBOutlet weak var 仕入高計: UILabel!
    @IBOutlet weak var 期末商品棚卸高: UILabel!
    @IBOutlet weak var 期末商品製品棚卸高: UILabel!
    @IBOutlet weak var 売上原価計: UILabel!
    @IBOutlet weak var 売上純利益: UILabel!
    @IBOutlet weak var 人件費計: UILabel!
    @IBOutlet weak var その他経費計: UILabel!
    @IBOutlet weak var 販売費一般管理費計: UILabel!
    @IBOutlet weak var 営業利益: UILabel!
    @IBOutlet weak var 受取利息: UILabel!
    @IBOutlet weak var 雑収入: UILabel!
    @IBOutlet weak var 営業外収益計: UILabel!
    @IBOutlet weak var 営業外費用計: UILabel!
    @IBOutlet weak var 経常利益: UILabel!
    @IBOutlet weak var 特別利益計: UILabel!
    @IBOutlet weak var 特別損失計: UILabel!
    @IBOutlet weak var 税引箭当期純利益損失: UILabel!
    @IBOutlet weak var 当期純利益損失: UILabel!
    
    @IBOutlet weak var 一般管理費: UIView!
    @IBOutlet weak var 給料手当: UILabel!
    @IBOutlet weak var 役員報酬: UILabel!
    @IBOutlet weak var 退職金給付費用: UILabel!
    @IBOutlet weak var 人件費の計: UILabel!
    @IBOutlet weak var 通信費: UILabel!
    @IBOutlet weak var 水道光熱費: UILabel!
    @IBOutlet weak var 旅費交通費: UILabel!
    @IBOutlet weak var 広告宣伝費: UILabel!
    @IBOutlet weak var 接待交際費: UILabel!
    @IBOutlet weak var 会議費: UILabel!
    @IBOutlet weak var 事務用消耗品費: UILabel!
    @IBOutlet weak var 備品消耗品費: UILabel!
    @IBOutlet weak var 修繕費: UILabel!
    @IBOutlet weak var ガソリン代: UILabel!
    @IBOutlet weak var 車両費: UILabel!
    @IBOutlet weak var 保険料: UILabel!
    @IBOutlet weak var 租税公課: UILabel!
    @IBOutlet weak var 諸会費: UILabel!
    @IBOutlet weak var 支払手数料: UILabel!
    @IBOutlet weak var 雑費: UILabel!
    @IBOutlet weak var その他経費の計: UILabel!
    @IBOutlet weak var 販売費一般管理費の計: UILabel!
    
    
    @IBOutlet weak var 棚卸商品View: UIView!
    @IBOutlet weak var 期首商品棚卸高テキスト: UITextField!
    @IBOutlet weak var 期末商品棚卸高テキスト: UITextField!
    
    
    
    @IBOutlet weak var 署名: UIView!
    
    var uriages: [Uriage] = []
    var shiires: [Shiire] = []
    var taisyakus: [Taisyaku] = []
    var kaikeiHimes: [KaikeiHime] = []
    
    
    var year: String = ""
    var month: String = ""
    
    var monthData:[String] = {
        var monthData:[String] = []
        let dateFormatter = DateFormatter()
        monthData = dateFormatter.monthSymbols
        return monthData
    }()
    
    //貸借対照表初期設定
    var 初期現金 = 327882.0
    var 初期当座預金 = 136988.0
    var 初期普通預金 = 2604189.0
    var 初期売掛金 = 1270062.0
    var 初期商品 = 917662.0
    var 初期未収収益 = 999006.0
    var 初期車両運搬具 = 4448194.0
    var 初期工具器具備品 = 507510.0
    var 初期繰延資産 = 954045.0
    var 初期買掛金 = 458877.0
    var 初期未払金 = 9752644.0
    var 初期預り金 = 40242.0
    var 初期長期借入金 = 1300000.0
    var 初期資本金 = 10000000.0
    var 初期利益準備金 = 1000000.0
    var 初期繰越利益剰余金 = -10386225.0
//var 初期利益剰余金計 = -9386225.0
    var 初期株主資本計 = 613775.0
    
    //損益計算書初期設定
    var 初期売上高 = 0.0
    //let 初期売上高の計 = 8110951.0
    var 初期期首商品棚卸高 = 836103.0
    //var 初期期首商品製品棚卸高 = 0.0
    var 初期仕入高 = 0.0
    //let 初期当期商品仕入高 = 4313172.0
    var 初期仕入高計 = 0.0
    var 初期期末商品棚卸高 = -836103.0
    //var 初期期末商品製品棚卸高 = 0.0
    var 初期売上原価計 = 0.0
    var 初期売上純利益 = 0.0
    var 初期人件費計 = 0.0
    var 初期その他経費計 = 0.0
    var 初期販売費一般管理費計 = 0.0
    var 初期営業利益 = 0.0
    var 初期受取利息 = 0.0
    var 初期雑収入 = 0.0
    var 初期営業外収益計 = 0.0
    var 初期営業外費用計 = 0.0
    var 初期経常利益 = 0.0
    var 初期特別利益計 = 0.0
    var 初期特別損失計 = 0.0
    var 初期税引箭当期純利益損失 = 0.0
    var 初期当期純利益損失 = 0.0
    
    //販売費及び一般管理費内訳書初期設定
    var 初期給料手当 = 0.0
    var 初期役員報酬 = 0.0
    var 初期退職金給付費用 = 0.0
    var 初期通信費 = 0.0
    var 初期水道光熱費 = 0.0
    var 初期旅費交通費 = 0.0
    var 初期広告宣伝費 = 0.0
    var 初期接待交際費 = 0.0
    var 初期会議費 = 0.0
    var 初期事務用消耗品費 = 0.0
    var 初期備品消耗品費 = 0.0
    var 初期修繕費 = 0.0
    var 初期ガソリン代 = 0.0
    var 初期車両費 = 0.0
    var 初期保険料 = 0.0
    var 初期租税公課 = 0.0
    var 初期諸会費 = 0.0
    var 初期支払手数料 = 0.0
    var 初期雑費 = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
//画面拡大と移動・追加
        ジェスチャーの用意()
//ここまで
        決算書.alpha = 1
        貸借対照表.alpha = 0
        損益計算書.alpha = 0
        一般管理費.alpha = 0
        署名.alpha = 0
        棚卸商品View.alpha = 0
        
        
        if 期首商品棚卸高.text == "0" {
            //棚卸商品View.alpha = 1
        }

    }
    
    @IBAction func 期首商品棚卸入力テキスト(_ sender: UITextField) {
        //期末商品棚卸高.text = sender.text
    }
    
//画面拡大と移動・追加
    func ジェスチャーの用意() {
        決算書.isUserInteractionEnabled = true
        決算書.isMultipleTouchEnabled = true
        
        pinchGesture = UIPinchGestureRecognizer(target: self, action:#selector(画像拡大))
        決算書.addGestureRecognizer(self.pinchGesture)
        
    }
//ここまで

//MARK: - CoreData設定
    //追加1
    func fetchSpendings() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
            //Uriage
            //Uriage
            let fetchRequest: NSFetchRequest<Uriage> = Uriage.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                //MARK: - 品名追加1 Attributesを追加する
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "day", ascending: true), NSSortDescriptor(key: "cost", ascending: false), NSSortDescriptor(key: "name", ascending: false), NSSortDescriptor(key: "retailer", ascending: false),NSSortDescriptor(key: "retailer1", ascending: false),NSSortDescriptor(key: "retailer2", ascending: false), NSSortDescriptor(key: "details", ascending: false),NSSortDescriptor(key: "details1", ascending: false),NSSortDescriptor(key: "details2", ascending: false), NSSortDescriptor(key: "number", ascending: false), NSSortDescriptor(key: "quantity", ascending: false),NSSortDescriptor(key: "quantity1", ascending: false),NSSortDescriptor(key: "quantity2", ascending: false), NSSortDescriptor(key: "total", ascending: false),NSSortDescriptor(key: "total1", ascending: false),NSSortDescriptor(key: "total2", ascending: false), NSSortDescriptor(key: "unit", ascending: false),NSSortDescriptor(key: "unit1", ascending: false),NSSortDescriptor(key: "unit2", ascending: false), NSSortDescriptor(key: "restoredItemName", ascending: false), NSSortDescriptor(key: "restoredQuantity", ascending: false), NSSortDescriptor(key: "restoredUnitPrice", ascending: false), NSSortDescriptor(key: "unitPrice", ascending: false), NSSortDescriptor(key: "unitPrice1", ascending: false), NSSortDescriptor(key: "unitPrice2", ascending: false), NSSortDescriptor(key: "genkin", ascending: false), NSSortDescriptor(key: "urikake", ascending: false), NSSortDescriptor(key: "uriagedaka", ascending: false)]//ここで追加futsuuします
            }
//ここuriages
            uriages = try context.fetch(fetchRequest)
            
        } catch {
            print("Spendings Data Fetching Failed.")
        }
        
    }
//ここまで
    
    func fetch仕入() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
            //Shiire
            //Shiire
            let fetchRequest: NSFetchRequest<Shiire> = Shiire.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                //MARK: - 品名追加1 Attributesを追加する
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "day", ascending: true), NSSortDescriptor(key: "cost", ascending: false), NSSortDescriptor(key: "name", ascending: false), NSSortDescriptor(key: "total", ascending: false), NSSortDescriptor(key: "urikake", ascending: false), NSSortDescriptor(key: "uriagedaka", ascending: false)]//ここで追加します
            }
//ここuriages
            shiires = try context.fetch(fetchRequest)
            
        } catch {
            print("Spendings Data Fetching Failed.")
        }
    }
    
    func fetch貸借対照表() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
            //Shiire
            //Shiire
            let fetchRequest: NSFetchRequest<Taisyaku> = Taisyaku.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                //MARK: - 品名追加1 Attributesを追加すcategoryる
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "azukari", ascending: true), NSSortDescriptor(key: "category", ascending: false), NSSortDescriptor(key: "chouki", ascending: false), NSSortDescriptor(key: "fusaiTotal", ascending: false), NSSortDescriptor(key: "futsuu", ascending: false), NSSortDescriptor(key: "genkin", ascending: false), NSSortDescriptor(key: "genkinYokinTotal", ascending: false), NSSortDescriptor(key: "kaikake", ascending: false), NSSortDescriptor(key: "koteiFusaiTotal", ascending: false), NSSortDescriptor(key: "mibarai", ascending: false), NSSortDescriptor(key: "touza", ascending: false), NSSortDescriptor(key: "urikakeTotal", ascending: false), NSSortDescriptor(key: "urikaki", ascending: false)]//ここで追加します
            }
//ここuriages
            taisyakus = try context.fetch(fetchRequest)
            
        } catch {
            print("Spendings Data Fetching Failed.")
        }
    }
    
    func fetch会計姫() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
            //Shiire
            //Shiire
            let fetchRequest: NSFetchRequest<KaikeiHime> = KaikeiHime.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                //MARK: - 品名追加1 Attributesを追加する
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "cost", ascending: true), NSSortDescriptor(key: "name", ascending: false), NSSortDescriptor(key: "total", ascending: false), NSSortDescriptor(key: "kaikake", ascending: false), NSSortDescriptor(key: "shiiredaka", ascending: false), NSSortDescriptor(key: "genkin", ascending: false), NSSortDescriptor(key: "category", ascending: false), NSSortDescriptor(key: "hoken", ascending: false), NSSortDescriptor(key: "tsuushin", ascending: false), NSSortDescriptor(key: "gasoline", ascending: false), NSSortDescriptor(key: "suidou", ascending: false), NSSortDescriptor(key: "sozei", ascending: false), NSSortDescriptor(key: "jimu", ascending: false), NSSortDescriptor(key: "bihin", ascending: false), NSSortDescriptor(key: "ryohi", ascending: false), NSSortDescriptor(key: "syuuzen", ascending: false), NSSortDescriptor(key: "zattsu", ascending: false), NSSortDescriptor(key: "kyuuryou", ascending: false), NSSortDescriptor(key: "yakuin", ascending: false), NSSortDescriptor(key: "taisyoku", ascending: false), NSSortDescriptor(key: "koukoku", ascending: false), NSSortDescriptor(key: "kaigi", ascending: false), NSSortDescriptor(key: "syaryou", ascending: false), NSSortDescriptor(key: "syokai", ascending: false), NSSortDescriptor(key: "shiharaite", ascending: false)]//ここで追加します
            }
//ここuriages
            kaikeiHimes = try context.fetch(fetchRequest)
            
        } catch {
            print("Spendings Data Fetching Failed.")
        }
    }
    
//MARK: - 勘定科目の合計をしています
//func drawPieChart(uriages)で呼ばれます
    //ここUriage
    func calculatePercentPerCategory() {

         var percents: [Double] = {
            var percents: [Double] = []
            for _ in 0..<会計姫categories.count {
                percents.append(0.0)
            }
            return percents
        }()
        

        //貸借対照表勘定科目
        var 振替仕訳現金合計 = 0.0
        var 振替仕訳当座預金合計 = 0.0
        var 振替仕訳普通預金合計 = 0.0
        var 普通預金合計 = 0.0
        var 振替仕訳現金預金合計 = 0.0
        var 売上現金合計 = 0.0
        var 売掛金合計 = 0.0
        var 商品合計 = 0.0
        var 棚卸資産合計 = 0.0
        var 未収収益合計 = 0.0
        var その他流動資産合計 = 0.0
        var 車両運搬具合計 = 0.0
        var 工具器具備品合計 = 0.0
        var 有形固定資産合計 = 0.0
        var 流動資産合計 = 0.0
        var 固定資産合計 = 0.0
        var 繰延資産合計 = 0.0
        var 繰延資産の合計 = 0.0
        var 資産の部合計 = 0.0
        var 仕入現金合計 = 0.0//仕入で支払った現金は引かれます
        var 買掛金合計 = 0.0
        var 振替仕訳未払金合計 = 0.0
        var 振替仕訳預り金合計 = 0.0
        var 振替仕訳流動負債合計 = 0.0
        var 振替仕訳長期借入金合計 = 0.0
        var 振替仕訳固定負債合計 = 0.0
        var 振替仕訳負債の部合計 = 0.0
        var 資本金合計 = 0.0
        var 利益準備金合計 = 0.0
        var 繰越利益剰余金合計 = 0.0
        var 利益常用金合計 = 0.0
        var 株主資本合計 = 0.0
        var 純資産の部合計 = 0.0
        var 負債純資産の部計合計 = 0.0
        
        //損益計算書勘定科流動負債の計目
        var 売上高合計 = 0.0
        //var 売上高の計合計 = 0.0
        var 期首商品棚卸高合計 = 0.0
        //var 期首商品製品棚卸高合計 = 0.0
        var 仕入高合計 = 0.0
        //var 当期商品仕入高合計 = 0.0
        var 仕入高計合計 = 0.0
        var 期末商品棚卸高合計 = 0.0
        //var 期末商品製品棚卸高合計 = 0.0
        var 売上原価計合計 = 0.0
        var 売上純利益合計 = 0.0
        var 人件費計合計 = 0.0
        var その他経費計合計 = 0.0
        var 販売費一般管理費計合計 = 0.0
        var 営業利益合計 = 0.0
        var 受取利息合計 = 0.0
        var 雑収入合計 = 0.0
        var 営業外収益計合計 = 0.0
        var 営業外費用計合計 = 0.0
        var 経常利益合計 = 0.0
        var 特別利益計合計 = 0.0
        var 特別損失計合計 = 0.0
        var 税引箭当期純利益損失合計 = 0.0
        var 当期純利益損失合計 = 0.0
        
        //一般管理費勘定科目
        var 給料手当合計 = 0.0
        var 役員報酬合計 = 0.0
        var 退職金給付費用合計 = 0.0
        var 通信費合計 = 0.0
        var 水道光熱費合計 = 0.0
        var 旅費交通費合計 = 0.0
        var 広告宣伝費合計 = 0.0
        var 接待交際費合計 = 0.0
        var 会議費合計 = 0.0
        var 事務用消耗品費合計 = 0.0
        var 備品消耗品費合計 = 0.0
        var 修繕費合計 = 0.0
        var ガソリン代合計 = 0.0
        var 車両費合計 = 0.0
        var 保険料合計 = 0.0
        var 租税公課合計 = 0.0
        var 諸会費合計 = 0.0
        var 支払手数料合計 = 0.0
        var 雑費合計 = 0.0    

//shiharaite・支払手数料
//ここuriages
        //_ = uriages.last!
//売上
        for uriage in uriages {
            //if let categoryIndex = 売上締日詳細.index(of: uriage.category!) {
                //print("uriageを通過しました = \(categoryIndex)")
//貸借対照表勘定科売掛債権の合計目
                //percents[categoryIndex] += Double(uriage.genkin)
                売上現金合計 += Double(uriage.genkin)
                //percents[categoryIndex] += Double(uriage.urikake)
                売掛金合計 += Double(uriage.urikake)
                //percents[categoryIndex] += Double(uriage.futsuu)
                普通預金合計 += Double(uriage.futsuu)
                
//損益計算書勘定科目
                //percents[categoryIndex] += Double(uriage.uriagedaka)
                売上高合計 += Double(uriage.uriagedaka)
            //}
        }
//仕入
        for shiire in shiires {
                //print("shiireを通過しました = \(categoryIndex)")
//貸借対照表勘定科目
                仕入現金合計 += Double(shiire.genkin)
                買掛金合計 += Double(shiire.kaikake)
//損益計算書勘定科目
                仕入高合計 += Double(shiire.shiiredaka)
        }
        for taisyaku in taisyakus {
                //print("taisyakuを通過しました = \(categoryIndex)")
//貸借対照表勘定科目
                売上現金合計 += Double(taisyaku.genkin)
//損益計算書勘定科目
                売上高合計 += Double(taisyaku.urikakeTotal)
        }
        
//会計姫
        for kaikeiHime in kaikeiHimes {
                //print("kaikeiHimeを通過しました = \(categoryIndex)")
                //print("会計姫categoriesを通過しました = \(会計姫categories)")
//貸借対照表勘定科目
                振替仕訳現金合計 += Double(kaikeiHime.genkin)
                振替仕訳当座預金合計 += Double(kaikeiHime.touza)
                振替仕訳普通預金合計 += Double(kaikeiHime.futsuu)
                商品合計 += Double(kaikeiHime.shouhin)
                振替仕訳未払金合計 += Double(kaikeiHime.mibarai)
                振替仕訳預り金合計 += Double(kaikeiHime.azukari)
                振替仕訳長期借入金合計 += Double(kaikeiHime.choukikariire)

//損益計算書勘定科目
                期首商品棚卸高合計 += Double(kaikeiHime.kishutana)
                期末商品棚卸高合計 += Double(kaikeiHime.kimatsutana)
                受取利息合計 += Double(kaikeiHime.uketoririsoku)
                雑収入合計 += Double(kaikeiHime.zattsu)

//通信費一般管理費勘定科目/
                保険料合計 += Double(kaikeiHime.hoken)
                通信費合計 += Double(kaikeiHime.tsuushin)
                ガソリン代合計 += Double(kaikeiHime.gasoline)
                水道光熱費合計 += Double(kaikeiHime.suidou)
                租税公課合計 += Double(kaikeiHime.sozei)
                事務用消耗品費合計 += Double(kaikeiHime.jimu)
                備品消耗品費合計 += Double(kaikeiHime.bihin)
                旅費交通費合計 += Double(kaikeiHime.ryohi)
                修繕費合計 += Double(kaikeiHime.syuuzen)
                給料手当合計 += Double(kaikeiHime.kyuuryou)
                役員報酬合計 += Double(kaikeiHime.yakuin)
                退職金給付費用合計 += Double(kaikeiHime.taisyoku)
                広告宣伝費合計 += Double(kaikeiHime.koukoku)
                接待交際費合計 += Double(kaikeiHime.settai)
                会議費合計 += Double(kaikeiHime.kaigi)
                車両費合計 += Double(kaikeiHime.syaryou)
                諸会費合計 += Double(kaikeiHime.syokai)
                支払手数料合計 += Double(kaikeiHime.shiharaite)
                雑費合計 += Double(kaikeiHime.zattsu)

//shiharaite・支払手数料
        }
        
        
//貸借対照表勘定科目表示
        売上現金合計 = 売上現金合計 - 仕入現金合計 + 振替仕訳現金合計 + 初期現金
        let カンマ付き現金合計 = NSNumber(value: 売上現金合計)
        //class KUViewControllerletにグローバル設定しました・let フォーマッタ = NumberFormatter()
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        現金.text = フォーマッタ.string(from: カンマ付き現金合計)!// + "円"

        振替仕訳当座預金合計 += 初期当座預金
        let カンマ付き振替仕訳当座預金合計 = NSNumber(value: 振替仕訳当座預金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        当座預金.text = フォーマッタ.string(from: カンマ付き振替仕訳当座預金合計)!// + "円"
        
        振替仕訳普通預金合計 += 初期普通預金 + 普通預金合計
        let カンマ付き振替仕訳普通預金合計 = NSNumber(value: 振替仕訳普通預金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        普通預金.text = フォーマッタ.string(from: カンマ付き振替仕訳普通預金合計)!// + "円"
        
        振替仕訳現金預金合計 += 売上現金合計 + 振替仕訳当座預金合計 + 振替仕訳普通預金合計
        let カンマ付き振替仕訳現金預金合計 = NSNumber(value: 振替仕訳現金預金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        現金と預金の計.text = フォーマッタ.string(from: カンマ付き振替仕訳現金預金合計)!// + "円"
        
        売掛金合計 += 初期売掛金
        let カンマ付き売掛金合計 = NSNumber(value: 売掛金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        売掛金.text = フォーマッタ.string(from: カンマ付き売掛金合計)!
        
        売掛債権の計.text = フォーマッタ.string(from: カンマ付き売掛金合計)!
        
        商品合計 += 初期商品
        let カンマ付き商品合計 = NSNumber(value: 商品合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        商品.text = フォーマッタ.string(from: カンマ付き商品合計)!
        
        棚卸資産合計 += 商品合計
        let カンマ付き棚卸資産の合計 = NSNumber(value: 棚卸資産合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        棚卸資産の計.text = フォーマッタ.string(from: カンマ付き棚卸資産の合計)!
        
        未収収益合計 += 初期未収収益
        let カンマ付き未収収益合計 = NSNumber(value: 未収収益合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        未収収益.text = フォーマッタ.string(from: カンマ付き未収収益合計)!
        
        その他流動資産合計 += 未収収益合計
        let カンマ付きその他流動資産合計 = NSNumber(value: その他流動資産合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        その他流動資産の計.text = フォーマッタ.string(from: カンマ付きその他流動資産合計)!
        
        流動資産合計 = その他流動資産合計 + 棚卸資産合計 + 売掛金合計 + 振替仕訳現金預金合計
        let カンマ付き流動資産合計 = NSNumber(value: 流動資産合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        流動資産の計.text = フォーマッタ.string(from: カンマ付き流動資産合計)!
        
        車両運搬具合計 += 初期車両運搬具
        let カンマ付き車両運搬具合計 = NSNumber(value: 車両運搬具合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        車両運搬具.text = フォーマッタ.string(from: カンマ付き車両運搬具合計)!
        
        工具器具備品合計 += 初期工具器具備品
        let カンマ付き工具器具備品合計 = NSNumber(value: 工具器具備品合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        工具器具備品.text = フォーマッタ.string(from: カンマ付き工具器具備品合計)!
        
        有形固定資産合計 += 車両運搬具合計 + 工具器具備品合計
        let カンマ付き有形固定資産合計 = NSNumber(value: 有形固定資産合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        有形固定資産の計.text = フォーマッタ.string(from: カンマ付き有形固定資産合計)!
        
        固定資産合計 += 有形固定資産合計
        let カンマ付き固定資産合計 = NSNumber(value: 固定資産合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        固定資産の計.text = フォーマッタ.string(from: カンマ付き固定資産合計)!
        
        繰延資産合計 += 初期繰延資産
        let カンマ付き繰延資産合計 = NSNumber(value: 繰延資産合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        繰延資産.text = フォーマッタ.string(from: カンマ付き繰延資産合計)!
        
        繰延資産の合計 += 初期繰延資産
        let カンマ付き繰延資産の合計 = NSNumber(value: 繰延資産の合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        繰延資産の計.text = フォーマッタ.string(from: カンマ付き繰延資産の合計)!
        
        資産の部合計 = 繰延資産の合計 + 固定資産合計 + その他流動資産合計 + 棚卸資産合計 + 売掛金合計 + 振替仕訳現金預金合計
        let カンマ付き資産の部合計 = NSNumber(value: 資産の部合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        資産の部の計.text = フォーマッタ.string(from: カンマ付き資産の部合計)!
        
        買掛金合計 += 初期買掛金
        let カンマ付き買掛金合計 = NSNumber(value: 買掛金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        買掛金.text = フォーマッタ.string(from: カンマ付き買掛金合計)!
        
        振替仕訳未払金合計 += 初期未払金
        let カンマ付き未払金合計 = NSNumber(value: 振替仕訳未払金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        未払金.text = フォーマッタ.string(from: カンマ付き未払金合計)!
        
        振替仕訳預り金合計 += 初期預り金
        let カンマ付き預り金合計 = NSNumber(value: 振替仕訳預り金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        預り金.text = フォーマッタ.string(from: カンマ付き預り金合計)!
        
        振替仕訳流動負債合計 = 買掛金合計 + 振替仕訳未払金合計 + 振替仕訳預り金合計
        
        let カンマ付き流動負債の合計 = NSNumber(value: 振替仕訳流動負債合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        流動負債の計.text = フォーマッタ.string(from: カンマ付き流動負債の合計)!
        
        振替仕訳長期借入金合計 += 初期長期借入金
        let カンマ付き長期借入金合計 = NSNumber(value: 振替仕訳長期借入金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        長期借入金.text = フォーマッタ.string(from: カンマ付き長期借入金合計)!
        
        振替仕訳固定負債合計 += 振替仕訳長期借入金合計
        let カンマ付き固定負債合計 = NSNumber(value: 振替仕訳固定負債合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        固定負債の計.text = フォーマッタ.string(from: カンマ付き固定負債合計)!
        
        振替仕訳負債の部合計 += 振替仕訳流動負債合計 + 振替仕訳固定負債合計
        let カンマ付き負債の部合計 = NSNumber(value: 振替仕訳負債の部合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        負債の部の計.text = フォーマッタ.string(from: カンマ付き負債の部合計)!
        
        資本金合計 += 初期資本金
        let カンマ付き資本金合計 = NSNumber(value: 資本金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        資本金.text = フォーマッタ.string(from: カンマ付き資本金合計)!
        
        利益準備金合計 += 初期利益準備金
        let カンマ付き利益準備金合計 = NSNumber(value: 利益準備金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        利益準備金.text = フォーマッタ.string(from: カンマ付き利益準備金合計)!
        
        繰越利益剰余金合計 += 初期繰越利益剰余金 + 売上高合計 - 仕入高合計 - (給料手当合計 + 役員報酬合計 + 退職金給付費用合計 + 保険料合計 + 通信費合計 + ガソリン代合計 + 水道光熱費合計 + 租税公課合計 + 事務用消耗品費合計 + 備品消耗品費合計 + 旅費交通費合計 + 修繕費合計 + 雑費合計 + 広告宣伝費合計 + 接待交際費合計 + 会議費合計 + 車両費合計 + 諸会費合計 + 支払手数料合計) + 受取利息合計 + 雑収入合計
        let カンマ付き繰越利益剰余金合計 = NSNumber(value: 繰越利益剰余金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        繰越利益剰余金.text = フォーマッタ.string(from: カンマ付き繰越利益剰余金合計)!
        
        利益常用金合計 += 繰越利益剰余金合計 + 利益準備金合計//初期利益剰余金計
        let カンマ付き利益常用金合計 = NSNumber(value: 利益常用金合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        利益常用金の計.text = フォーマッタ.string(from: カンマ付き利益常用金合計)!
        
        株主資本合計 += 初期株主資本計 + 売上高合計 - 仕入高合計 - (給料手当合計 + 役員報酬合計 + 退職金給付費用合計 + 保険料合計 + 通信費合計 + ガソリン代合計 + 水道光熱費合計 + 租税公課合計 + 事務用消耗品費合計 + 備品消耗品費合計 + 旅費交通費合計 + 修繕費合計 + 雑費合計 + 広告宣伝費合計 + 接待交際費合計 + 会議費合計 + 車両費合計 + 諸会費合計 + 支払手数料合計) + 受取利息合計 + 雑収入合計
        let カンマ付き株主資本合計 = NSNumber(value: 株主資本合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        株主資本の計.text = フォーマッタ.string(from: カンマ付き株主資本合計)!
        
        純資産の部合計 += 株主資本合計
        let カンマ付き純資産の部合計 = NSNumber(value: 純資産の部合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        純資産の部計.text = フォーマッタ.string(from: カンマ付き純資産の部合計)!
        
        負債純資産の部計合計 = 純資産の部合計 + 振替仕訳負債の部合計
        let カンマ付き負債純資産の部計合計 = NSNumber(value: 負債純資産の部計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        負債純資産の部計.text = フォーマッタ.string(from: カンマ付き負債純資産の部計合計)!
        
        
//損益計算書勘定科目表示
        売上高合計 += 初期売上高
        let カンマ付き売上高合計 = NSNumber(value: 売上高合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        売上高.text = フォーマッタ.string(from: カンマ付き売上高合計)!
        売上高の計.text = フォーマッタ.string(from: カンマ付き売上高合計)!
        
        期首商品棚卸高合計 += 初期期首商品棚卸高
        let カンマ付き期首商品棚卸高合計 = NSNumber(value: 期首商品棚卸高合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        期首商品棚卸高.text = フォーマッタ.string(from: カンマ付き期首商品棚卸高合計)!
//print("期首商品棚卸高.text = \(期首商品棚卸高.text!)")
        
        //期首商品製品棚卸高合計 += 期首商品棚卸高合計
        let カンマ付き期首商品製品棚卸高合計 = NSNumber(value: 期首商品棚卸高合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        期首商品製品棚卸高.text = フォーマッタ.string(from: カンマ付き期首商品製品棚卸高合計)!
        
        仕入高合計 += 初期仕入高
        let カンマ付き仕入高合計 = NSNumber(value: 仕入高合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        仕入高.text = フォーマッタ.string(from: カンマ付き仕入高合計)!
        当期商品仕入高.text = フォーマッタ.string(from: カンマ付き仕入高合計)!
        
        仕入高計合計 += 初期仕入高計 + 期首商品棚卸高合計 + 仕入高合計
        let カンマ付き仕入高計合計 = NSNumber(value: 仕入高計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        仕入高計.text = フォーマッタ.string(from: カンマ付き仕入高計合計)!

        期末商品棚卸高合計 += 初期期末商品棚卸高
        let カンマ付き期末商品棚卸高合計 = NSNumber(value: 期末商品棚卸高合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        期末商品棚卸高.text = フォーマッタ.string(from: カンマ付き期末商品棚卸高合計)!
        
        //期末商品製品棚卸高合計 += 初期期末商品製品棚卸高
        let カンマ付き期末商品製品棚卸高合計 = NSNumber(value: 期末商品棚卸高合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        期末商品製品棚卸高.text = フォーマッタ.string(from: カンマ付き期末商品製品棚卸高合計)!
        
        売上原価計合計 += 初期売上原価計 + 仕入高計合計 + 期末商品棚卸高合計
        let カンマ付き売上原価計合計 = NSNumber(value: 売上原価計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        売上原価計.text = フォーマッタ.string(from: カンマ付き売上原価計合計)!
        
        売上純利益合計 += 初期売上純利益 + 売上高合計 - 売上原価計合計
        let カンマ付き売上純利益合計 = NSNumber(value: 売上純利益合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        売上純利益.text = フォーマッタ.string(from: カンマ付き売上純利益合計)!
        
        人件費計合計 += 初期人件費計 + 給料手当合計 + 役員報酬合計 + 退職金給付費用合計
        let カンマ付き人件費計合計 = NSNumber(value: 人件費計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        人件費計.text = フォーマッタ.string(from: カンマ付き人件費計合計)!
        
        その他経費計合計 += 初期その他経費計 + 保険料合計 + 通信費合計 + ガソリン代合計 + 水道光熱費合計 + 租税公課合計 + 事務用消耗品費合計 + 備品消耗品費合計 + 旅費交通費合計 + 修繕費合計 + 雑費合計 + 広告宣伝費合計 + 接待交際費合計 + 会議費合計 + 車両費合計 + 諸会費合計 + 支払手数料合計
        let カンマ付きその他経費計合計 = NSNumber(value: その他経費計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        その他経費計.text = フォーマッタ.string(from: カンマ付きその他経費計合計)!
        
        販売費一般管理費計合計 += 初期販売費一般管理費計 + 人件費計合計 + その他経費計合計
        let カンマ付き販売費一般管理費計合計 = NSNumber(value: 販売費一般管理費計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        販売費一般管理費計.text = フォーマッタ.string(from: カンマ付き販売費一般管理費計合計)!
        
        営業利益合計 += 初期営業利益 + 売上純利益合計 - 販売費一般管理費計合計
        let カンマ付き営業利益合計 = NSNumber(value: 営業利益合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        営業利益.text = フォーマッタ.string(from: カンマ付き営業利益合計)!
        
        受取利息合計 += 初期受取利息
        let カンマ付き受取利息合計 = NSNumber(value: 受取利息合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        受取利息.text = フォーマッタ.string(from: カンマ付き受取利息合計)!
        
        雑収入合計 += 初期雑収入
        let カンマ付き雑収入合計 = NSNumber(value: 雑収入合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        雑収入.text = フォーマッタ.string(from: カンマ付き雑収入合計)!
        
        営業外収益計合計 += 初期営業外収益計 + 受取利息合計 + 雑収入合計
        let カンマ付き営業外収益計合計 = NSNumber(value: 営業外収益計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        営業外収益計.text = フォーマッタ.string(from: カンマ付き営業外収益計合計)!
        
        営業外費用計合計 += 初期営業外費用計
        let カンマ付き営業外費用計合計 = NSNumber(value: 営業外費用計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        営業外費用計.text = フォーマッタ.string(from: カンマ付き営業外費用計合計)!
        
        経常利益合計 += 初期経常利益 + 営業利益合計 + 営業外費用計合計
        let カンマ付き経常利益合計 = NSNumber(value: 経常利益合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        経常利益.text = フォーマッタ.string(from: カンマ付き経常利益合計)!
        
        特別利益計合計 += 初期特別利益計
        let カンマ付き特別利益計合計 = NSNumber(value: 特別利益計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        特別利益計.text = フォーマッタ.string(from: カンマ付き特別利益計合計)!
        
        特別損失計合計 += 初期特別損失計 + 特別利益計合計
        let カンマ付き特別損失計合計 = NSNumber(value: 特別損失計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        特別損失計.text = フォーマッタ.string(from: カンマ付き特別損失計合計)!
        
        税引箭当期純利益損失合計 += 初期税引箭当期純利益損失 + 経常利益合計 + 特別損失計合計
        let カンマ付き税引箭当期純利益損失合計 = NSNumber(value: 税引箭当期純利益損失合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        税引箭当期純利益損失.text = フォーマッタ.string(from: カンマ付き税引箭当期純利益損失合計)!
        
        当期純利益損失合計 += 初期当期純利益損失 + 税引箭当期純利益損失合計
        let カンマ付き当期純利益損失合計 = NSNumber(value: 当期純利益損失合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        当期純利益損失.text = フォーマッタ.string(from: カンマ付き当期純利益損失合計)!
        
        
//一般管理費 通信費合計
        給料手当合計 += 初期給料手当
        let カンマ付き給料手当合計 = NSNumber(value: 給料手当合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        給料手当.text = フォーマッタ.string(from: カンマ付き給料手当合計)!
        
        役員報酬合計 += 初期役員報酬
        let カンマ付き役員報酬合計 = NSNumber(value: 役員報酬合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        役員報酬.text = フォーマッタ.string(from: カンマ付き役員報酬合計)!
        
        退職金給付費用合計 += 初期退職金給付費用
        let カンマ付き退職金給付費用合計 = NSNumber(value: 退職金給付費用合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        退職金給付費用.text = フォーマッタ.string(from: カンマ付き退職金給付費用合計)!
        
        let 人件費の計の合計 = 給料手当合計 + 役員報酬合計 + 退職金給付費用合計
        let カンマ付き人件費の計の合計 = NSNumber(value: 人件費の計の合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        人件費の計.text = フォーマッタ.string(from: カンマ付き人件費の計の合計)!
        
        通信費合計 += 初期通信費
        let カンマ付き通信費合計 = NSNumber(value: 通信費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        通信費.text = フォーマッタ.string(from: カンマ付き通信費合計)!
        
        水道光熱費合計 += 初期水道光熱費
        let カンマ付き水道光熱費合計 = NSNumber(value: 水道光熱費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        水道光熱費.text = フォーマッタ.string(from: カンマ付き水道光熱費合計)!
        
        旅費交通費合計 += 初期旅費交通費
        let カンマ付き旅費交通費合計 = NSNumber(value: 旅費交通費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        旅費交通費.text = フォーマッタ.string(from: カンマ付き旅費交通費合計)!
        
        広告宣伝費合計 += 初期広告宣伝費
        let カンマ付き広告宣伝費合計 = NSNumber(value: 広告宣伝費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        広告宣伝費.text = フォーマッタ.string(from: カンマ付き広告宣伝費合計)!
        
        接待交際費合計 += 初期接待交際費
        let カンマ付き接待交際費合計 = NSNumber(value: 接待交際費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        接待交際費.text = フォーマッタ.string(from: カンマ付き接待交際費合計)!
        
        会議費合計 += 初期会議費
        let カンマ付き会議費合計 = NSNumber(value: 会議費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        会議費.text = フォーマッタ.string(from: カンマ付き会議費合計)!

        事務用消耗品費合計 += 初期事務用消耗品費
        let カンマ付き事務用消耗品費合計 = NSNumber(value: 事務用消耗品費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        事務用消耗品費.text = フォーマッタ.string(from: カンマ付き事務用消耗品費合計)!

        備品消耗品費合計 += 初期備品消耗品費
        let カンマ付き備品消耗品費合計 = NSNumber(value: 備品消耗品費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        備品消耗品費.text = フォーマッタ.string(from: カンマ付き備品消耗品費合計)!

        修繕費合計 += 初期修繕費
        let カンマ付き修繕費合計 = NSNumber(value: 修繕費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        修繕費.text = フォーマッタ.string(from: カンマ付き修繕費合計)!
        
        ガソリン代合計 += 初期ガソリン代
        let カンマ付きガソリン代合計 = NSNumber(value: ガソリン代合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        ガソリン代.text = フォーマッタ.string(from: カンマ付きガソリン代合計)!
        
        車両費合計 += 初期車両費
        let カンマ付き車両費合計 = NSNumber(value: 車両費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        車両費.text = フォーマッタ.string(from: カンマ付き車両費合計)!
        
        保険料合計 += 初期保険料
        let カンマ付き保険料合計 = NSNumber(value: 保険料合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        保険料.text = フォーマッタ.string(from: カンマ付き保険料合計)!
        
        租税公課合計 += 初期租税公課
        let カンマ付き租税公課合計 = NSNumber(value: 租税公課合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        租税公課.text = フォーマッタ.string(from: カンマ付き租税公課合計)!
        
        諸会費合計 += 初期諸会費
        let カンマ付き諸会費合計 = NSNumber(value: 諸会費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        諸会費.text = フォーマッタ.string(from: カンマ付き諸会費合計)!
//支払手数料
        支払手数料合計 += 初期支払手数料
        let カンマ付き支払手数料合計 = NSNumber(value: 支払手数料合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        支払手数料.text = フォーマッタ.string(from: カンマ付き支払手数料合計)!

        雑費合計 += 初期雑費
        let カンマ付き雑費合計 = NSNumber(value: 雑費合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        雑費.text = フォーマッタ.string(from: カンマ付き雑費合計)!

        let その他経費の計合計 = 保険料合計 + 通信費合計 + ガソリン代合計 + 水道光熱費合計 + 租税公課合計 + 事務用消耗品費合計 + 備品消耗品費合計 + 旅費交通費合計 + 修繕費合計 + 雑費合計 + 広告宣伝費合計 + 接待交際費合計 + 会議費合計 + 車両費合計 + 諸会費合計 + 支払手数料合計
        let カンマ付きその他経費の計合計 = NSNumber(value: その他経費の計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        その他経費の計.text = フォーマッタ.string(from: カンマ付きその他経費の計合計)!

        let 販売費一般管理費の計合計 = その他経費の計合計 + 人件費の計の合計
        let カンマ付き販売費一般管理費の計合計 = NSNumber(value: 販売費一般管理費の計合計)
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
        販売費一般管理費の計.text = フォーマッタ.string(from: カンマ付き販売費一般管理費の計合計)!

//ここまで

        var percentsPerCategory: [(category: String, percent: Double)] = []
        for i in 0..<percents.count {
            percentsPerCategory.append((category: 会計姫categories[i], percent: percents[i]))
        }
        //print("percentsPerCategory = \(percentsPerCategory)")
        //return percentsPerCategory
        
    }
//ここまで

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        fetchSpendings()
        fetch仕入()
        fetch貸借対照表()
        fetch会計姫()
        calculatePercentPerCategory()
        
        
        if let obj: AnyObject = dataObject {
            dataLabel!.text = obj.description
            if dataLabel!.text == "決 算 書" {
                //print("現在は決算書です")
                決算書.alpha = 1
                貸借対照表.alpha = 0
                損益計算書.alpha = 0
                一般管理費.alpha = 0
                署名.alpha = 0
            }
            if dataLabel!.text == "貸 借 対 照 表" {
                //print("現在は貸借対照表です")
                決算書.alpha = 0
                貸借対照表.alpha = 1
                損益計算書.alpha = 0
                一般管理費.alpha = 0
                署名.alpha = 0
            }
            if dataLabel!.text == "損 益 計 算 書" {
                //print("現在は損益計算書です")
                決算書.alpha = 0
                貸借対照表.alpha = 0
                損益計算書.alpha = 1
                一般管理費.alpha = 0
                署名.alpha = 0
            }
            if dataLabel!.text == "一 般 管 理 費" {
                //print("現在は一般管理費です")
                決算書.alpha = 0
                貸借対照表.alpha = 0
                損益計算書.alpha = 0
                一般管理費.alpha = 1
                署名.alpha = 0
            }
            if dataLabel!.text == "署 名" {
                //print("現在は署名です")
                決算書.alpha = 0
                貸借対照表.alpha = 0
                損益計算書.alpha = 0
                一般管理費.alpha = 0
                署名.alpha = 1
            }
        } else {
            dataLabel!.text = "nil"
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//MARK: - func 第15期()
    func 第15期() {
        
//貸借対照表初期設定
        初期現金 = 327882.0
        初期当座預金 = 136988.0
        初期普通預金 = 2604189.0
        初期売掛金 = 1270062.0
        初期商品 = 917662.0
        初期未収収益 = 999006.0
        初期車両運搬具 = 4448194.0
        初期工具器具備品 = 507510.0
        初期繰延資産 = 954045.0
        初期買掛金 = 458877.0
        初期未払金 = 9752644.0
        初期預り金 = 40242.0
        初期長期借入金 = 1300000.0
        初期資本金 = 10000000.0
        初期利益準備金 = 1000000.0
        初期繰越利益剰余金 = -10386225.0
//初期利益剰余金計 = -9386225.0
        初期株主資本計 = 613775.0
        
        //損益計算書初期設定
        初期売上高 = 8110951.0
//let 初期売上高の計 = 8110951.0
        初期期首商品棚卸高 = 836103.0
//初期期首商品製品棚卸高 = 836103.0
        初期仕入高 = 4313172.0
//let 初期当期商品仕入高 = 4313172.0
        初期仕入高計 = 5149275.0
        初期期末商品棚卸高 = 917662.0
//初期期末商品製品棚卸高 = 917662.0
        初期売上原価計 = 4321613.0
        初期売上純利益 = 3879338.0
        初期人件費計 = 3934224.0
        初期その他経費計 = 2334503.0
        初期販売費一般管理費計 = 6268727.0
        初期営業利益 = 2389389.0
        初期受取利息 = 396.0
        初期雑収入 = 25144.0
        初期営業外収益計 = 25540.0
        初期営業外費用計 = 0.0
        初期経常利益 = 2363849.0
        初期特別利益計 = 0.0
        初期特別損失計 = 0.0
        初期税引箭当期純利益損失 = 2363849.0
        初期当期純利益損失 = 2363849.0
        
        //販売費及び一般管理費内訳書初期設定
        初期給料手当 = 1681400.0
        初期役員報酬 = 1718800.0
        初期退職金給付費用 = 534024.0
        初期通信費 = 264420.0
        初期水道光熱費 = 380819.0
        初期旅費交通費 = 22670.0
        初期広告宣伝費 = 40824.0
        初期接待交際費 = 186777.0
        初期会議費 = 21157.0
        初期事務用消耗品費 = 7510.0
        初期備品消耗品費 = 67677.0
        初期修繕費 = 173504.0
        初期ガソリン代 = 201555.0
        初期車両費 = 13390.0
        初期保険料 = 560197.0
        初期租税公課 = 296395.0
        初期諸会費 = 64178.0
        初期支払手数料 = 10029.0
        初期雑費 = 23401.0
        calculatePercentPerCategory()
    }
    

    
    @IBAction func 年度切替(_ sender: UIButton) {
        第15期()
        
    }
    
//画面拡大と移動・追加
    @IBAction func 画像拡大(_ sender: UIPinchGestureRecognizer) {
        if(sender.state == UIGestureRecognizerState.began){
            //ピンチ開始時のアフィン変換をクラス変数に保持する。
            startTransform = 決算書.transform
        }
        //ピンチ開始時のアフィン変換を引き継いでアフィン変換を行う。
        決算書.transform = startTransform.scaledBy(x: sender.scale, y: sender.scale)
    }
    
    @IBAction func 画像移動(_ sender: UIPanGestureRecognizer) {
        //print("パン通過しました")
        //移動量を取得する。
        let move:CGPoint = sender.translation(in: view)
        
        //ドラッグした部品の座標に移動量を加算する。
        sender.view!.center.x += move.x
        sender.view!.center.y += move.y
        
        //参考サイト http://stackoverflow.com/questions/37946990/cgrectmake-cgpointmake-cgsizemake-cgrectzero-cgpointzero-is-unavailable-in-s
        //移動量を0にする。
        sender.setTranslation(CGPoint.zero, in:view)
    }
    //ここまで
}

