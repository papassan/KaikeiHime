//
//  UIBounceButton.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/04/14.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit

class UriageSyUIBounceButton: IBDesignableButton {

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
        super.touchesBegan(touches, with: event)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        UIView.animate(withDuration: 0.1, delay: 0, options: .allowUserInteraction, animations: { 
            self.transform = .identity
        }, completion: nil)
        
        super.touchesEnded(touches, with: event)
    }

}
