//
//  DataViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/23.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//Shiire

import UIKit
import CoreData

// MARK: - Global Variables

class KSDataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Properties
    
    @IBOutlet weak var dataLabel: UILabel!
    @IBOutlet weak var myView: UIView!
    var spendingTableView: UITableView!
    var graphView: UIView!
    var sumCostLabel: UILabel!
    var categoryButtons: [UIButton] = []
    
    // MARK: -
    
    var year: String = ""
    var month: String = ""
    
    // MARK: -
    
    let segueEditSpendingViewController = "SegueEditSpendingViewController"
    let segueAddSpendingViewController = "SegueAddSpendingViewController"
    
    // MARK: - Properties for Fetching
    
    var monthData:[String] = {
        var monthData:[String] = []
        let dateFormatter = DateFormatter()
        monthData = dateFormatter.monthSymbols
        return monthData
    }()
    //ここshiires
    //ここShiire
    var shiires: [Shiire] = []
    var retreatedSpendings: [Shiire] = []
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.dataLabel!.text = "\(month), \(year)"
        createMyView()
        addButtons()
    }
    
    func カンマフォーマッタ() {
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchSpendings()
        categoryButtonsAllColored()
        drawPieChart()
    }
    
    func drawPieChart() {
        let center = CGPoint(x: graphView.frame.height / 2, y: graphView.frame.height / 2)
        //グラフ円のサイズ
        let radius: CGFloat = graphView.frame.height * 0.12//2
        //print("radius = \(radius)")
//ここshiires
        //合計を計算する関数をpercentsPerCategoryに代入している
        let percentsPerCategory = calculatePercentPerCategory(shiires)
        if let graphImageView = drawPieChartImageView(center: center, radius: radius, percentsPerCategory: percentsPerCategory) {
            graphView.addSubview(graphImageView)
        }
    }
    
    func createMyView() {
        // create view for graph
        graphView = UIView()
        let graphViewFrame = CGRect(x: 0.0, y: 0.0, width: myView.frame.width, height: myView.frame.width * 0.2)//0.7
        //(0.0, 0.0, 984.0, 295.2)
        //print("graphViewFrame = \(graphViewFrame)")
        graphView.frame = graphViewFrame
        myView.addSubview(graphView)
        
        // create label for sum cost
        sumCostLabel = UILabel()
        sumCostLabel.frame = CGRect(x: myView.frame.width * 0.5, y: graphView.frame.height - 50.0, width: myView.frame.width * 0.45, height: 50.0)
        sumCostLabel.font = UIFont.systemFont(ofSize: 48)
        sumCostLabel.text = "計 0 円"
        sumCostLabel.backgroundColor = .white
        sumCostLabel.textAlignment = NSTextAlignment.right
        myView.addSubview(sumCostLabel)
        
        // create table view for spendings
        spendingTableView = UITableView()
        let tableViewFrame = CGRect(x: 0.0, y: graphView.frame.maxY, width: myView.frame.width, height: myView.frame.height-graphView.frame.height - 56.8)
        //(0.0, 295.2, 984.0, 406.8)//406.8 - 56.8の意味は引かないとスクロールしなくなる
        //print("tableViewFrame = \(tableViewFrame)")
        spendingTableView.frame = tableViewFrame
        myView.addSubview(spendingTableView)
        spendingTableView.delegate = self
        spendingTableView.dataSource = self
    }
    
    func fetchSpendings() {
        // fetch data from core data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
//ここShiire
//ここShiire
            let fetchRequest: NSFetchRequest<Shiire> = Shiire.fetchRequest()
            if let monthIndex = monthData.index(of: month) {
                fetchRequest.predicate = NSPredicate(format: "year = %@ and month = %d", year, monthIndex + 1)
                fetchRequest.sortDescriptors = [NSSortDescriptor(key: "day", ascending: true), NSSortDescriptor(key: "cost", ascending: false), NSSortDescriptor(key: "name", ascending: false), NSSortDescriptor(key: "total", ascending: false), NSSortDescriptor(key: "kaikake", ascending: false), NSSortDescriptor(key: "shiiredaka", ascending: false), NSSortDescriptor(key: "genkin", ascending: false)]
            }
//ここshiires
            shiires = try context.fetch(fetchRequest)
        } catch {
            print("Spendings Data Fetching Failed.")
        }
        spendingTableView.reloadData()
    }
    
    func arcPercent(center: CGPoint, radius: CGFloat, startAngle: CGFloat, percent: Double) -> UIBezierPath {
        // draw one arc
        let endAngle = 2 * Double.pi * percent + Double(startAngle)
        //188.8
        //print("endAngle = \(endAngle)")
        let path = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: CGFloat(endAngle), clockwise: true)
        //print("path = \(path)")
        path.lineWidth = radius * 2.0
        path.lineCapStyle = .butt
        return path
    }
    
    func addButtons() {
        for i in 0..<仕入締日.count {
            let buttonWidth: CGFloat = graphView.frame.width - graphView.frame.height - 500//40ボタンの幅
            //print("buttonWidth = \(buttonWidth)")
//categories
            let buttonHeight: CGFloat = (graphView.frame.height - sumCostLabel.frame.height) / CGFloat(仕入締日詳細.count) - CGFloat(仕入締日詳細.count + 1) + 10
            //print("buttonHeight = \(buttonHeight)")
            let buttonRect = CGRect(x: graphView.frame.height + 10, y: (buttonHeight + 1.0) * CGFloat(i) + 3.0, width: buttonWidth, height: buttonHeight)
            //print("buttonRect = \(buttonRect)")
            categoryButtons.append(UIBounceButton(frame: buttonRect))
            categoryButtons[i].layer.cornerRadius = 5
            categoryButtons[i].backgroundColor = colors[i]
            
            categoryButtons[i].setTitle(仕入締日[i], for: .normal)
            categoryButtons[i].setTitleColor(.black, for: .normal)
            categoryButtons[i].tag = i
            categoryButtons[i].addTarget(self, action: #selector(self.categoryButtonTapped(_:)), for: .touchUpInside)
            graphView.addSubview(categoryButtons[i])
        }
    }
    
//ここshiires
//ここshiires
    func categoryButtonTapped(_ sender: UIButton) {
        if sender.backgroundColor != .gray {
            categoryButtons[sender.tag].backgroundColor = .gray
            for i in 0..<shiires.count {
                if shiires[i].category! != 仕入締日詳細[sender.tag] {
                    retreatedSpendings.append(shiires[i])
                }
                //print("categoryButtonTapped = \(shiires[i])")
            }
//ここshiires
//ここshiires
            shiires = shiires.filter { $0.category! == 仕入締日詳細[sender.tag] }
        } else {
            categoryButtons[sender.tag].backgroundColor = colors[sender.tag]
            for retreatedSpending in retreatedSpendings {
                if retreatedSpending.category! != 仕入締日詳細[sender.tag] {
//ここshiires
                    shiires.append(retreatedSpending)
                }
            }
            retreatedSpendings = retreatedSpendings.filter { $0.category! == 仕入締日詳細[sender.tag] }
//ここshiires
            shiires.sort(by: {$0.day < $1.day})
        }
        spendingTableView.reloadData()
        drawPieChart()
    }
    
    func categoryButtonsAllColored() {
        for i in 0..<categoryButtons.count {
            categoryButtons[i].backgroundColor = colors[i]
        }
    }
    
//ここShiire
    func calculatePercentPerCategory(_ spendings: [Shiire]) ->  [(category: String, percent: Double)] {
        var percents: [Double] = {
            var percents: [Double] = []
            for _ in 0..<仕入締日詳細.count {
                percents.append(0.0)
            }
            return percents
        }()
        var sumCost = 0.0
        
//ここshiires
        for shiire in shiires {
            if let categoryIndex = 仕入締日詳細.index(of: shiire.category!) {
                percents[categoryIndex] += Double(shiire.cost)
                sumCost += Double(shiire.cost)
            }
        }
        
        for i in 0..<percents.count {
            percents[i] /= sumCost
        }
//総合計の金額にカンマを付けます
        let カンマ付きsumCostLabel = NSNumber(value: sumCost)
        //class KUViewControllerletにグローバル設定しました・let フォーマッタ = NumberFormatter()
        カンマフォーマッタ()
        sumCostLabel.text = フォーマッタ.string(from: カンマ付きsumCostLabel)! + "円"
        
        //sumCostLabel.text = "合計 \(Int(sumCost)) 円"
        
        var percentsPerCategory: [(category: String, percent: Double)] = []
        for i in 0..<percents.count {
            percentsPerCategory.append((category: 仕入締日詳細[i], percent: percents[i]))
        }
        
        return percentsPerCategory
    }
    
    func drawPieChartImageView(center: CGPoint, radius: CGFloat, percentsPerCategory: [(category: String, percent: Double)]) -> UIImageView? {
        // begin drawing
        UIGraphicsBeginImageContextWithOptions(myView.bounds.size, false, 1.0)
        
        // initialization
        var startAngle = -Double.pi
        let sortedPercentsPerCategory = percentsPerCategory.sorted(by: {$0.percent > $1.percent})
        
        // return nil if the number of colors is short
        if sortedPercentsPerCategory.count > colors.count {
            return nil
        }
        
        // draw frame of pie chart
        let contextMoney = UIGraphicsGetCurrentContext()
        let frameWidthRatio: CGFloat = 2.05
        let whiteCircleRect = CGRect(x: center.x-radius*frameWidthRatio, y: center.y-radius*frameWidthRatio, width: 2*frameWidthRatio*radius, height: 2*frameWidthRatio*radius)
        let whiteCirclePath = UIBezierPath(ovalIn: whiteCircleRect)
        contextMoney?.setFillColor(UIColor.gray.cgColor)
        whiteCirclePath.fill()
        
        // draw PieChart per category
        for i in 0..<sortedPercentsPerCategory.count {
            if let colorIndex = 仕入締日詳細.index(of: sortedPercentsPerCategory[i].category) {
                colors[colorIndex].setStroke()
            }
            let arcPath = arcPercent(center: center, radius: radius, startAngle: CGFloat(startAngle), percent: sortedPercentsPerCategory[i].percent)
            startAngle += 2 * Double.pi * sortedPercentsPerCategory[i].percent
            arcPath.stroke()
        }
        
        // get image from context and end drawing
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return UIImageView(image: image)
    }
    
    // MARK: - Spending Table View Data Source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cellRect = CGRect(x: 0, y: 0, width: myView.frame.width, height: 30.0)
        let cell = UIView(frame: cellRect)
        
        let sortButtons = UISegmentedControl(items: ["日付順", "金額順", "カテゴリ順"])
        sortButtons.frame.size = CGSize(width: cell.frame.width-20, height: cell.frame.height)
        sortButtons.center = cell.center
        sortButtons.backgroundColor = self.view.backgroundColor
        sortButtons.tintColor = .orange
        sortButtons.selectedSegmentIndex = 0
        sortButtons.addTarget(self, action: #selector(sortButtonTapped(_:)), for: .valueChanged)
        
        cell.addSubview(sortButtons)
        
        return cell
    }
//ここshiires
    func sortButtonTapped(_ sortButtons: UISegmentedControl) {
        switch sortButtons.selectedSegmentIndex {
        case 0:
            shiires.sort(by: { (shiire1, shiire2) -> Bool in
                return shiire1.day < shiire2.day
            })
        case 1:
            shiires.sort(by: { (shiire1, shiire2) -> Bool in
                return shiire1.cost > shiire2.cost
            })
        case 2:
            shiires.sort(by: { (shiire1, shiire2) -> Bool in
                return shiire1.category! > shiire2.category!
            })
        default:
            print("default")
        }
        if let indexPathes = spendingTableView.indexPathsForVisibleRows {
            spendingTableView.reloadRows(at: indexPathes, with: .automatic)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//ここshiires
        return shiires.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//ここshiire
//ここshiires
        let shiire = shiires[indexPath.row]
        
//ここshiire
        let cell = configureSpendingCell(shiire: shiire)
        cell.layoutMargins = .zero
        
        return cell
    }
    
//ここshiire
    func configureSpendingCell(shiire: Shiire) -> UITableViewCell {
        let cell = UITableViewCell()
        
        // create day label
        let dayLabel = UILabel()
        dayLabel.sizeToFit()
//ここshiire
        dayLabel.text = "\(shiire.day)日"//ここ
        dayLabel.frame = CGRect(x: myView.frame.width * 0.05, y: 0.0, width: myView.frame.width / 5.0, height: cell.frame.height)
        cell.addSubview(dayLabel)
        
        let 仕入先顧客Label = UILabel()
        仕入先顧客Label.sizeToFit()

        仕入先顧客Label.text = "\(shiire.name!)"//ここ
        仕入先顧客Label.frame = CGRect(x: myView.frame.width * 0.17, y: 0.0, width: myView.frame.width / 2.0, height: cell.frame.height)
        cell.addSubview(仕入先顧客Label)
        
        // create scost label
        let costLabel = UILabel()
        costLabel.sizeToFit()
        costLabel.font = UIFont.systemFont(ofSize: 24)
//リスト金額にカンマを付けています
        let カンマ付き伝票合計Label = NSNumber(value: shiire.cost)
        カンマフォーマッタ()
        costLabel.text = フォーマッタ.string(from: カンマ付き伝票合計Label)! + "円"
        
        //costLabel.text = "\(shiire.cost)円"
        costLabel.textAlignment = .right
        costLabel.frame = CGRect(x: myView.frame.width * 0.6, y: 0.0, width: myView.frame.width * 0.35, height: cell.frame.height)
        cell.addSubview(costLabel)
        
        return cell
    }
    
    // MARK: - Spending Table View Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//ここshiires
        performSegue(withIdentifier: segueEditSpendingViewController, sender: shiires[indexPath.row])
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueEditSpendingViewController {
//ここKSAddViewController
            let destinationViewController = segue.destination as! KSAddViewController//ここ
//ここshiire
//ここShiire
            destinationViewController.shiire = sender as! Shiire?
        } else if segue.identifier == segueAddSpendingViewController {
//ここKSAddViewController
            let destinationViewController = segue.destination as! KSAddViewController//ここ
            destinationViewController.myDate[0] = Int(year)!
            if let month = monthData.index(of: month) {
                destinationViewController.myDate[1] = month + 1
            }
        }
    }
}
