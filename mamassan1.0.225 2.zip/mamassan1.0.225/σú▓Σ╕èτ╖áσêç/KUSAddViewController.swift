//
//  AddSpendingViewController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/06/22.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

//参考サイトhttp://d.hatena.ne.jp/kazukingband/20120522/1337638966
//参考サイト http://hajihaji-lemon.com/smartphone/swift/uipickerview/

import UIKit

class KUSAddViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
// MARK: - 参考サイト2-1 http://qiita.com/marty-suzuki/items/f0547e40dc09e790328f
    lazy var __once: Void = {
        self.printSomething()
    }()
// MARK: - ここまで・参考サイト2-1
//画面拡大と移動
    @IBOutlet weak var View拡大: UIView!
    var pinchGesture = UIPinchGestureRecognizer()
    var startTransform:CGAffineTransform!
//ここまで
    
    
    // MARK: - Properties
    
    @IBOutlet weak var 電卓: UIStackView!
    @IBOutlet weak var 保存: UriageSyUIBounceButton!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var categorySegmentedControl1: UISegmentedControl!
    @IBOutlet weak var categorySegmentedControl2: UISegmentedControl!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var costLabel: UILabel!

    @IBOutlet weak var multiplyButton: UIButton!
    
    @IBOutlet weak var 年ラベル: UILabel!
    @IBOutlet weak var 月ラベル: UILabel!
    @IBOutlet weak var 日ラベル: UILabel!
    
    @IBOutlet weak var 税抜価格ラベル: UILabel!
    @IBOutlet weak var 振込料ラベル: UILabel!
    @IBOutlet weak var 入金書ラベル: UILabel!
    @IBOutlet weak var 売掛伝票顧客ラベル: UILabel!
    @IBOutlet weak var 売掛伝票顧客ピッカー部品: UIPickerView!
    @IBOutlet weak var 売掛伝票番号ラベル: UILabel!
    @IBOutlet weak var 売掛伝票番号ピッカー部品: UIPickerView!
    @IBOutlet weak var 売掛伝票品名ピッカー部品: UIPickerView!
    
    @IBOutlet weak var 顧客ボタン表示: UIButton!
    @IBOutlet weak var 番号ボタン表示: UIButton!
    @IBOutlet weak var 日付ピッカーボタン表示: UIButton!

    @IBOutlet weak var 品名ボタン表示1: UIButton!
    @IBOutlet weak var 品名ボタン表示2: UIButton!
    @IBOutlet weak var 品名ボタン表示3: UIButton!
    @IBOutlet weak var 品名ボタン表示4: UIButton!
    @IBOutlet weak var 品名ボタン表示5: UIButton!
    @IBOutlet weak var 品名ボタン表示6: UIButton!
    @IBOutlet weak var 品名ボタン表示7: UIButton!

    @IBOutlet weak var 売掛伝票品名ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票品名ラベル7: UILabel!
    
    // MARK: ラベル
    
    @IBOutlet weak var 売掛伝票数量ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票数量ラベル7: UILabel!
    
    @IBOutlet weak var 売掛伝票単価ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票単価ラベル7: UILabel!
    
    @IBOutlet weak var 売掛伝票単位ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票単位ラベル7: UILabel!
    
    @IBOutlet weak var 売掛伝票小計ラベル1: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル2: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル3: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル4: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル5: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル6: UILabel!
    @IBOutlet weak var 売掛伝票小計ラベル7: UILabel!

    
    @IBOutlet weak var 売掛伝票合計ラベル: UILabel!
    
    @IBOutlet weak var 適用テキスト1: UITextField!
    @IBOutlet weak var 適用テキスト2: UITextField!
    @IBOutlet weak var 適用テキスト3: UITextField!
    @IBOutlet weak var 適用テキスト4: UITextField!
    @IBOutlet weak var 適用テキスト5: UITextField!
    @IBOutlet weak var 適用テキスト6: UITextField!
    @IBOutlet weak var 適用テキスト7: UITextField!
    
    @IBOutlet weak var 伝票削除許可ボタン: UIButton!
    
    @IBOutlet weak var 浩子: UIButton!
    
    var ビッカー変更 = true
    var 締切 = ""
    var 保存ボタン = 0

    
    var 売掛伝票顧客入力 = true
    var 売掛伝票顧客入力済 = false
    var 売掛伝票日付入力 = true
    var 売掛伝票番号入力 = true
    var 売掛伝票番号入力済 = false
    
    var 売掛伝票品名入力1 = false
    var 売掛伝票品名入力2 = false
    var 売掛伝票品名入力3 = false
    var 売掛伝票品名入力4 = false
    var 売掛伝票品名入力5 = false
    var 売掛伝票品名入力6 = false
    var 売掛伝票品名入力7 = false
    
    var 売掛伝票品名入力済1 = false
    var 売掛伝票品名入力済2 = false
    var 売掛伝票品名入力済3 = false
    var 売掛伝票品名入力済4 = false
    var 売掛伝票品名入力済5 = false
    var 売掛伝票品名入力済6 = false
    var 売掛伝票品名入力済7 = false
    
    var 品名rowInt = 11
    var 数量rowInt = 31
    var 単価rowInt = 0
    
    //Optional型での宣言
    var 品名rowString: String? = "11"
    //非Optional型での宣言
    var 数量rowString = "31"
    var 単価rowString = "0"
    
    var 更新伝票番号 = 0
    var 更新伝票数 = 0
    
    var 伝票合計Int = 0
    
    var 売掛伝票小計ラベル1合計 = 0
    var 売掛伝票小計ラベル2合計 = 0
    
    
    //アルファ
    @IBOutlet weak var 伝票アルファ: UIImageView!
    // 日付フォーマット
    //年
    var yeardateFormatter: DateFormatter{
        let yearformatter = DateFormatter()
        yearformatter.dateFormat = "y"
        return yearformatter
    }
    //月
    var monthdateFormatter: DateFormatter{
        let monthformatter = DateFormatter()
        monthformatter.dateFormat = "M"//MMならば4は04と表示します
        return monthformatter
    }
    //日
    var daydateFormatter: DateFormatter{
        let dayformatter = DateFormatter()
        dayformatter.dateFormat = "d"//ddなら4は04と表示します
        return dayformatter
    }

    // MARK: - Flags for Inputing Numbers
    
    var multiplyFlag = false
    var placehold = false
    var edNumber = 0
    
//追加
    // MARK: - Properties for Saving data into Core Data
    var myCategory = 売上締日.first
    var myDate: [Int] = {
        var myDate: [Int] = []
        // get current date
        let now = Date()
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: now)
//print("dateComps = \(dateComps)")
        // assign them to myDate[]
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate.append(year)
//print("year = \(year)")
            myDate.append(month)
            myDate.append(day)
        }
        return myDate
    }()
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//ここ
    var uriage: Uriage?
    var taisyaku: Taisyaku?
    
    
    // MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        税抜価格ラベル.alpha = 0
        振込料ラベル.alpha = 0
        入金書ラベル.alpha = 0
        
        //YESなら操作可、NOなら操作不可
        //合計.isEnabled = true
        //合計.isEnabled = false
        
//売掛伝票ピッカー
        売掛伝票顧客ピッカー部品.delegate = self
        売掛伝票顧客ピッカー部品.dataSource = self
        売掛伝票顧客ピッカー部品.alpha = 0
        
        売掛伝票番号ピッカー部品.delegate = self
        売掛伝票番号ピッカー部品.dataSource = self
        売掛伝票番号ピッカー部品.alpha = 0

        売掛伝票品名ピッカー部品.alpha = 0
        
        datePicker.alpha = 0
        
        電卓.alpha = 0
        保存.alpha = 0
        
        伝票削除許可ボタン.alpha = 0
        
        //更新伝票番号
        更新伝票番号 = Int(ラスト伝票番号) + 1
        売掛伝票番号ラベル.text = String(更新伝票番号)
        
        更新伝票数 = Int(伝票数) + 1
        売掛伝票番号ラベル.text = String(更新伝票数)

        
//画面拡大と移動
        ジェスチャーの用意()
//ここまで
        
        // set date got from segue
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        
        if let date = dateFormatter.date(from: "\(myDate[0])/\(myDate[1])/\(myDate[2])") {
            datePicker.date = date
        }
 
        
        // 初回の日付を表示する
        updateDateLabel()
//ここ
        if let uriage = uriage {
            setEditedSpending(uriage)
        }
        
        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(cancelButtonTapped(_:)))
        downSwipe.direction = .down
        self.view.addGestureRecognizer(downSwipe)

// MARK: - 参考サイト2-2
        _ = __once // Void型のPropertyの初期化が一度だけ実行されるので、`self.printSomething()`が呼ばれる
        _ = __once // 既にPropertyの初期化が完了しているので、`self.printSomething()`が呼ばれない
// MARK: - ここまで・参考サイト2-2

    }
// MARK: - ここまでviewDidLoad()
    
    func カンマフォーマッタ() {
        フォーマッタ.numberStyle = .decimal
        フォーマッタ.groupingSeparator = ","
        フォーマッタ.groupingSize = 3
    }
    
// MARK: - 参考サイト2-3
    func printSomething() {
        //print("this method might be executed once.")
    }
// MARK: - ここまで・参考サイト2-3
    
// MARK: - 参考サイト1-2
    var exec: (() -> Void)? = {
        //print("hoge")
    }
// MARK: - ここまで・参考サイト1-2
    
    //画面が表示された直後
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
// MARK: - 参考サイト1-3
        execOnce(execute: &exec)
// MARK: - ここまで・参考サイト1-3
    }
    
    
//売掛伝票ピッカー
     //pickerに表示する列数を返すデータソースメソッド.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //print("通過0")
        if (pickerView.tag == 1) {
            return 売掛伝票顧客.count//return 1
        }
        if (pickerView.tag == 2) {
            return 1
        }
        if (pickerView.tag == 3) {
            return 売掛伝票品名.count
        }
        return 売掛伝票品名.count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する行数を返すデータソースメソッド
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //print("通過1")
        
        if (pickerView.tag == 1) {
            return 売掛伝票顧客[component].count//売掛伝票顧客[component].count
        }
        if (pickerView.tag == 2) {
            return 売掛伝票番号.count
        }
        if (pickerView.tag == 3) {
            return 売掛伝票品名[component].count
        }
        return 売掛伝票品名[component].count//returnは最後に追加したピッカーの変数を返します
    }
    
    //pickerに表示する値を返すデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //print("通過2")
        
        if (pickerView.tag == 1) {
            return 売掛伝票顧客[component][row]//("\(売掛伝票顧客[row])")
        }
        if (pickerView.tag == 2) {
            return ("\(売掛伝票番号[row])")
        }
        if (pickerView.tag == 3) {
            return 売掛伝票品名[component][row]
        }
        return 売掛伝票品名[component][row]//returnは最後に追加したピッカーの変数を返します
    }
    
// MARK: - pickerが選択された際に呼ばれるデリゲートメソッド
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print("通過3")
        
        if (pickerView.tag == 1) {
            売掛伝票顧客ラベル.text = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
// MARK: - ピッカー連動で項目を追加する
            
            締切 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 1)!
            売掛伝票品名入力1 = true
            
            伝票顧客入力終了()
        }
        // MARK: - print("番号ピッカー選択後")
        if (pickerView.tag == 2) {
            売掛伝票番号ラベル.text = ("\(売掛伝票番号[row])")
            伝票番号入力終了()
        }
        if (pickerView.tag == 3) {
            var 品名 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
            var 数量 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
            var 単価 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)
            
            //単位は品名と同期しています
            //同期方法の解説・forComponentは配列の順番で設定します、この場合の配列順は品名、数量単価の次なので3になります、inComponentは同期したいinComponentと同様にします
            let 単位 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 0), forComponent: 3)
            //品名rowは品名と同期しています
            let 品名row = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 4)
            //数量rowは数量と同期しています
            let 数量row = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 5)
            //単価rowは単価と同期しています
            let 単価row = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 6)
            
            //print("品名 = \(品名!)")
            if 品名 == "１号砕石" {
                品名rowInt = 0
                数量rowInt = 10
                単価rowInt = 5
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "40-0(m³)" {
                品名rowInt = 11
                数量rowInt = 10
                単価rowInt = 4
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "40-0(合)" {
                品名rowInt = 12
                数量rowInt = 11
                単価rowInt = 3
                顧客品名ピッカー雛形設定()
            }
            if 品名 == "40-0(ヶ)" {
                品名rowInt = 13
                数量rowInt = 26
                単価rowInt = 0
                顧客品名ピッカー雛形設定()
            }
            //print("品名rowInt = \(品名rowInt)")
            //print("数量rowInt = \(数量rowInt)")
            //print("単価rowInt = \(単価rowInt)")

            品名 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 0), forComponent: 0)
            数量 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent : 1), forComponent: 1)
            単価 = self.pickerView(pickerView, titleForRow: pickerView.selectedRow(inComponent: 2), forComponent: 2)

            
            if 売掛伝票品名入力1 {
                売掛伝票品名ラベル1.text = 品名
                売掛伝票数量ラベル1.text = 数量
                売掛伝票単位ラベル1.text = 単位
                売掛伝票単価ラベル1.text = 単価
                
                //String同士で置き換えをしていますがOptional型での宣言(var 品名rowString: String? = "11")で初期化していれば!マークが不要ですが非Optional型での宣言(var 数量rowString = "31")で初期化すると!マークは必要です
                品名rowString = 品名row
                数量rowString = 数量row!
                単価rowString = 単価row!
            }
            
            if 売掛伝票品名入力2 {
                売掛伝票品名ラベル2.text = 品名
                売掛伝票数量ラベル2.text = 数量
                売掛伝票単位ラベル2.text = 単位
                売掛伝票単価ラベル2.text = 単価
            }
            
            if 売掛伝票品名入力3 {
                売掛伝票品名ラベル3.text = 品名
                売掛伝票数量ラベル3.text = 数量
                売掛伝票単位ラベル3.text = 単位
                売掛伝票単価ラベル3.text = 単価
            }
            
            if 売掛伝票品名入力4 {
                売掛伝票品名ラベル4.text = 品名
                売掛伝票数量ラベル4.text = 数量
                売掛伝票単価ラベル4.text = 単価
            }
            
            if 売掛伝票品名入力5 {
                売掛伝票品名ラベル5.text = 品名
                売掛伝票数量ラベル5.text = 数量
                売掛伝票単価ラベル5.text = 単価
            }
            
            if 売掛伝票品名入力6 {
                売掛伝票品名ラベル6.text = 品名
                売掛伝票数量ラベル6.text = 数量
                売掛伝票単価ラベル6.text = 単価
            }
            
            if 売掛伝票品名入力7 {
                売掛伝票品名ラベル7.text = 品名
                売掛伝票数量ラベル7.text = 数量
                売掛伝票単価ラベル7.text = 単価
            }
        }
    }
    
    //参考サイトhttp://stackoverflow.com/questions/33655015/changing-font-and-its-size-of-a-picker-in-swift
    // MARK: - ピッカーのフォントサイズ設定
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        
        var 売上顧客フォント: UILabel
            if let view = view as? UILabel {
                売上顧客フォント = view
            } else {
                売上顧客フォント = UILabel()
        }
        
        売上顧客フォント.textColor = .black
        売上顧客フォント.textAlignment = .center
        売上顧客フォント.font = UIFont.systemFont(ofSize: 12)
        
        // where data is an Array of String
        if pickerView.tag == 1 {
            売上顧客フォント.text = 売掛伝票顧客[component][row]//売掛伝票顧客[row] as? String
            return 売上顧客フォント
        }
        
        var 売上伝票番号フォント: UILabel
        if let view = view as? UILabel {
            売上伝票番号フォント = view
        } else {
            売上伝票番号フォント = UILabel()
        }
        
        売上伝票番号フォント.textColor = .black
        売上伝票番号フォント.textAlignment = .center
        売上伝票番号フォント.font = UIFont.systemFont(ofSize: 18)
        
        if pickerView.tag == 2 {
            売上伝票番号フォント.text = ("\(売掛伝票番号[row])")
            return 売上伝票番号フォント
        }
//ここから
        var 売上伝票品名フォント: UILabel
        if let view = view as? UILabel {
            売上伝票品名フォント = view
        } else {
            売上伝票品名フォント = UILabel()
        }
        
        売上伝票品名フォント.textColor = .black
        売上伝票品名フォント.textAlignment = .center
        売上伝票品名フォント.font = UIFont.systemFont(ofSize: 12)
        
        if pickerView.tag == 3 {
            売上伝票品名フォント.text = 売掛伝票品名[component][row]
            return 売上伝票品名フォント
        }//ここまで
//新規ピッカー追加はここに追加します
        
        return 売上伝票品名フォント//return変数は最後に追加した変数を書きます
}
    
    // MARK: - 品名のピッカーサイズ
    func pickerView(_ pickerView: UIPickerView, widthForComponent component:Int) -> CGFloat {
        
        if (pickerView.tag == 1) {
            return 169
        }
        if (pickerView.tag == 2) {
            return 26
        }
        if (pickerView.tag == 3) {
            switch component {
            case 0:
                return 95//品名の幅
            case 1:
                return 60//数量の幅
            case 2:
                return 54//単価の幅
            case 3:
                return 0//その他の幅
            default: break
            }
        }
        return 0//この場合は最後なので単価の幅です・34以下は万単位で1の桁が表示しません
    }
    
    // MARK: - ホイールのセルの高さの調節
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
    return 20
    }
    //ホイールのセルの幅の調節・しかし反応なしです ?
    func pickerView(_ pickerView: UIPickerView, rowWidthForComponent component: Int) -> CGFloat {
    return 80
    }

    
// MARK: - func・伝票顧客入力終了
    func 伝票顧客入力終了() {
        売掛伝票顧客ピッカー部品.alpha = 0
        売掛伝票顧客ラベル.alpha = 1
        売掛伝票番号入力 = true
        年ラベル.alpha = 1
        月ラベル.alpha = 1
        日ラベル.alpha = 1
        伝票アルファ.alpha = 1
        let 売上締日詳細Index = Int(締切)
        categorySegmentedControl1.selectedSegmentIndex = 売上締日詳細Index!
        myCategory = 売上締日[categorySegmentedControl1.selectedSegmentIndex]
        売掛伝票顧客入力済 = true
        顧客品名雛形()
        入力済()
    }
    
    // MARK: - func・伝票番号入力終了//
    func 伝票番号入力終了() {
        売掛伝票番号ピッカー部品.alpha = 0
        売掛伝票番号ラベル.alpha = 1
        売掛伝票顧客入力 = true
        伝票アルファ.alpha = 1
        売掛伝票番号入力済 = true
        入力済()
    }
    
    // MARK: - func・伝票品名入力終了
    func 伝票品名入力終了() {
        if (売掛伝票品名ラベル1.text != "") {
            売掛伝票品名ピッカー部品.alpha = 1
            売掛伝票品名ピッカー部品.alpha = 0
            //売掛伝票品名ラベル1.tag = 0
            
            売掛伝票品名入力済1 = true
            //売掛伝票品名入力2 = true
            
            売掛伝票品名ラベル1.alpha = 1
            売掛伝票数量ラベル1.alpha = 1
            売掛伝票単価ラベル1.alpha = 1
            伝票アルファ.alpha = 1
            売掛伝票品名入力済1 = true
            入力済()
            if 売掛伝票品名入力済2 {
                売掛伝票品名入力3 = true
            }
            if 売掛伝票品名入力済3 {
                売掛伝票品名入力4 = true
            }
            if 売掛伝票品名入力済4 {
                売掛伝票品名入力5 = true
            }
            if 売掛伝票品名入力済5 {
                売掛伝票品名入力6 = true
            }
            if 売掛伝票品名入力済6 {
                売掛伝票品名入力7 = true
            }
        }
    }
    
    func 入力済() {
        if 売掛伝票顧客入力済 && 売掛伝票番号入力済 && 売掛伝票品名入力済1 {
            保存.alpha = 1
        }
    }

    
//ここまで
    
    //画面拡大と移動
    func ジェスチャーの用意() {
        View拡大.isUserInteractionEnabled = true
        View拡大.isMultipleTouchEnabled = true
        
        pinchGesture = UIPinchGestureRecognizer(target: self, action:#selector(画像拡大))
        View拡大.addGestureRecognizer(self.pinchGesture)
        
    }
    //ここまで

    
    // MARK: - 日付ラベル更新メソッド
    func updateDateLabel(){
        let now = Date()
        // システムのカレンダーを取得
        let 和暦 = Calendar(identifier: Calendar.Identifier.japanese)
        // 現在時刻のDateComponentsを取り出す
        var 和暦取得 = 和暦.dateComponents([.year, .month, .day, .hour, .minute, .second], from: now as Date)
        //西暦で表示する
        //年ラベル.text = yeardateFormatter.string(from: now as Date)
        //月ラベル.text = monthdateFormatter.string(from: now as Date)
        //日ラベル.text = daydateFormatter.string(from: now as Date)
        //和暦で表示する

            年ラベル.text = ("\(和暦取得.year!)")
            月ラベル.text = ("\(和暦取得.month!)")
            日ラベル.text = ("\(和暦取得.day!)")
        }

    // MARK: セッティング
//追加
    func setEditedSpending(_ uriage: Uriage) {
        myDate[0] = Int(uriage.year)
        myDate[1] = Int(uriage.month)
        myDate[2] = Int(uriage.day)
        myCategory = uriage.category!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "y/M/d"
        if let uriageDate = dateFormatter.date(from: "\(uriage.year)/\(uriage.month)/\(uriage.day)") {
            datePicker.date = uriageDate
        }
        if let uriageCategoryIndex = 売上締日詳細.index(of: uriage.category!) {
            if uriageCategoryIndex < 5 {
                categorySegmentedControl1.selectedSegmentIndex = uriageCategoryIndex
                
            } else {
                categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
                categorySegmentedControl2.selectedSegmentIndex = uriageCategoryIndex - 5
            }
//伝票の締め日を検知している
            //print("uriageCategoryIndex = \(uriageCategoryIndex)")
        }

//追加
            costLabel.text = String(Int(uriage.unitPrice1))
        
        伝票削除許可ボタン.alpha = 1
        
//name・顧客
        売掛伝票顧客ラベル.alpha = 1
        売掛伝票顧客ラベル.text = uriage.name
        if 売掛伝票顧客ラベル.text == "現金顧客" {
            売掛伝票顧客ラベル.alpha = 1
            //伝票現金顧客テキスト入力.alpha = 1
            //伝票現金顧客テキスト入力.font = UIFont.systemFont(ofSize: 18)
            売掛伝票顧客ラベル.text = uriage.nameGenkin
        }
        
//number・番号
        売掛伝票番号ラベル.alpha = 1
        売掛伝票番号ラベル.text = String(uriage.number)
        
//retailer・品名
        適用テキスト1.text = uriage.retailer1
            if uriage.category == "入金" {
                税抜価格ラベル.alpha = 1
                振込料ラベル.alpha = 1
                入金書ラベル.alpha = 1
                適用テキスト1.alpha = 0
                適用テキスト2.alpha = 0
                適用テキスト3.alpha = 0
                適用テキスト4.alpha = 0
                適用テキスト5.alpha = 0
                適用テキスト6.alpha = 0
                適用テキスト7.alpha = 0
                適用テキスト1.text = ""
                売掛伝票品名ラベル6.text = uriage.retailer1
                }
        適用テキスト2.text = uriage.retailer2
        
//MARK: - details・品名
        売掛伝票品名ラベル1.text = uriage.details1
        売掛伝票品名ラベル2.text = uriage.details2
        
//quantity・数量
/*        if uriage.category == "入金" {
            売掛伝票数量ラベル1.font = UIFont(name: "HiraMinProN-W3", size: 13)
        }*/
        売掛伝票数量ラベル1.text = ("\(String(uriage.quantity1))")
        
        if uriage.quantity2 != 0.0 {
            売掛伝票数量ラベル2.text = ("\(String(uriage.quantity2))")
        }

//unit・単位
        売掛伝票単位ラベル1.text = uriage.unit1
        売掛伝票単位ラベル2.text = uriage.unit2
        if 売掛伝票単位ラベル1.text == "袋" {
            売掛伝票数量ラベル1.text = ("\(String(Int(uriage.quantity1)))")
        }
        if uriage.category == "入金" {
            let カンマ付き数量ラベル1 = NSNumber(value: uriage.zeikomikakaku)
            カンマフォーマッタ()
            売掛伝票数量ラベル1.text = フォーマッタ.string(from: カンマ付き数量ラベル1)!
        }
        
            if 売掛伝票単位ラベル2.text == "袋" {
                売掛伝票数量ラベル2.text = ("\(String(Int(uriage.quantity2)))")
            }
        
//MARK: - String単価をIntに変換してカンマを付けます
        var カンマ付き単価ラベル1 = NSNumber(value: uriage.unitPrice1)
        //class KUSViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
        if uriage.category == "入金" {
            let 振込料 = uriage.zeikomikakaku - uriage.nyuukin
            カンマ付き単価ラベル1 = NSNumber(value: 振込料)
        }
        
        カンマフォーマッタ()
        売掛伝票単価ラベル1.text = フォーマッタ.string(from: カンマ付き単価ラベル1)!
        
        if uriage.unitPrice2 != 0.0 {
            let カンマ付き単価ラベル2 = NSNumber(value: uriage.unitPrice2)
//class KUSViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
            カンマフォーマッタ()
            売掛伝票単価ラベル2.text = フォーマッタ.string(from: カンマ付き単価ラベル2)!
        }
//小計を変数に入れる
        売掛伝票小計ラベル1合計 = Int(uriage.total1)
        売掛伝票小計ラベル2合計 = Int(uriage.total2)
        
//String小計をIntに変換してカンマを付けている
        
        var カンマ付き小計ラベル1合計 = NSNumber(value: uriage.total1)
        //class KUSViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
        if uriage.category == "入金" {
            カンマ付き小計ラベル1合計 = NSNumber(value: uriage.nyuukin)
        }
        カンマフォーマッタ()
        売掛伝票小計ラベル1.text = フォーマッタ.string(from: カンマ付き小計ラベル1合計)!
        
        if uriage.total2 != 0 {
            let カンマ付き小計ラベル2合計 = NSNumber(value: uriage.total2)
            カンマフォーマッタ()
            売掛伝票小計ラベル2.text = フォーマッタ.string(from: カンマ付き小計ラベル2合計)!
        }
        var 伝票合計 = uriage.total1 + uriage.total2
        if uriage.category == "入金" {
            伝票合計 = uriage.nyuukin
        }
        let カンマ付き金額ラベル合計 = NSNumber(value: 伝票合計)
        カンマフォーマッタ()
        売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き金額ラベル合計)!

//品名復元
        品名rowInt = Int(uriage.restoredItemName!)!
//数量復元
        数量rowInt = Int(uriage.restoredQuantity!)!
//単価復元
        単価rowInt = Int(uriage.restoredUnitPrice!)!
        
        年ラベル.text = String(uriage.year)
        月ラベル.text = String(uriage.month)
        日ラベル.text = String(uriage.day)
        
        deleteButton.isEnabled = true
        
        売掛伝票品名入力1 = true//編集なので品名1を入力済にしている
        保存.alpha = 1//編集なので保存ボタンを表示します
        
        //print("伝票番号 = \(Int(uriage.number))")
        //print("伝票数 = \(伝票数)")
        //print("ラスト伝票番号 = \(Int(ラスト伝票番号))")
        //print("更新伝票番号 = \(Int(更新伝票番号))\n")

    }
// MARK: - 伝票完成()
    func 伝票完成() {
        //print("\(String(describing: 売掛伝票顧客ラベル.text))")
        if 売掛伝票顧客ラベル.text == nil { //これを追加しますunit
            
            保存.alpha = 0 //編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
        
        if 売掛伝票品名ラベル1.text == "" { //これを追加しますunit
            保存.alpha = 0 //編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
        
        if 売掛伝票数量ラベル1.text == String(describing: "") {//これを追加しますunit
            保存.alpha = 0//編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
        
        if 売掛伝票単価ラベル1.text == "" {//これを追加しますunit
            保存.alpha = 0//編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }

        if 売掛伝票単位ラベル1.text == nil {//これを追加しますunit
            保存.alpha = 0//編集後なので保存ボタンを表示します
        } else {
            保存.alpha = 1
        }
    }
    
    // MARK: - 関数・顧客品名ピッカー雛形設定()
    func 顧客品名ピッカー雛形設定() {
        売掛伝票品名ピッカー部品.delegate = self
        売掛伝票品名ピッカー部品.dataSource = self
        // 行、列を指定して選択状態にする。(5行、1列、アニメーションする)
        売掛伝票品名ピッカー部品.selectRow(品名rowInt, inComponent: 0, animated: true)
        売掛伝票品名ピッカー部品.selectRow(数量rowInt, inComponent: 1, animated: false)
        売掛伝票品名ピッカー部品.selectRow(単価rowInt, inComponent: 2, animated: false)
        // 選択中の行をハイライト
        売掛伝票品名ピッカー部品.showsSelectionIndicator = true
    }

    // MARK: - 関数・顧客品名雛形()
    func 顧客品名雛形() {
        //print("通過・顧客品名雛形()")
        if 売掛伝票顧客ラベル.text == "ポラスグランテック株式会社" {
            品名rowInt = 0//１号砕石
            数量rowInt = 10//1.0
            単価rowInt = 2//7800
            顧客品名ピッカー雛形設定()
        }
        if 売掛伝票顧客ラベル.text == "瀬野左官工業所" {
            品名rowInt = 1//川砂
            数量rowInt = 8//0.8
            単価rowInt = 0//550
            顧客品名ピッカー雛形設定()
        }
        if 売掛伝票顧客ラベル.text == "左官職山田" {
            品名rowInt = 2//中目砂
            数量rowInt = 26//5
            単価rowInt = 0//550
            顧客品名ピッカー雛形設定()
        }
    }
    
    // MARK: - 電卓ボタン
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func dateChanged(_ sender: UIDatePicker) {
        // Assign selected date to myDate[]
        let dateComps = Calendar.current.dateComponents([.year, .month, .day], from: sender.date)
        if let year = dateComps.year, let month = dateComps.month, let day = dateComps.day {
            myDate[0] = year
            myDate[1] = month
            myDate[2] = day
            年ラベル.text = String(year)
            月ラベル.text = String(month)
            日ラベル.text = String(day)
            年ラベル.alpha = 1
            月ラベル.alpha = 1
            日ラベル.alpha = 1
            datePicker.alpha = 0
            伝票アルファ.alpha = 1
            売掛伝票顧客ラベル.alpha = 1
        }
    }
    
    @IBAction func categoryChosen1(_ sender: UISegmentedControl) {
        myCategory = 売上締日[sender.selectedSegmentIndex]
        categorySegmentedControl2.selectedSegmentIndex = UISegmentedControlNoSegment
    }
    
    @IBAction func categoryChosen2(_ sender: UISegmentedControl) {
        myCategory = 売上締日[sender.selectedSegmentIndex + 5]
        categorySegmentedControl1.selectedSegmentIndex = UISegmentedControlNoSegment
    }
    
    
// MARK: - エンターキー
    @IBAction func 保存(_ sender: UriageSyUIBounceButton) {
        if uriage?.category == "入金" {
            return
        }
        
        if 売掛伝票顧客ラベル.text == "" { //これを追加します
            return
        }
        
        if 売掛伝票番号ラベル.text == "" { //これを追加します
            return
        }
        
// 品名1の行・dismiss if no cost is input
        if 売掛伝票品名ラベル1.text == "" || 売掛伝票単価ラベル1.text == "" || 売掛伝票数量ラベル1.text == "" || 売掛伝票単位ラベル1.text == nil { //これを追加します
            return
        }
        
        // create new Spending object if nothing is got from segue
        if uriage == nil {
            uriage = Uriage(context: context)
            //print("100\(context)")
        }
        //追加4
        // configure Spending object
        if let uriage = uriage {
            uriage.year = Int16(myDate[0])
            uriage.month = Int16(myDate[1])
            uriage.day = Int16(myDate[2])
            uriage.category = myCategory
            taisyaku?.category = myCategory
            //print("uriage.category = \(uriage.category!)")
            //print("taisyaku?.category = \(taisyaku?.category!)")
            
            
//伝票の締め日・変数myCategoryはOptional型なので!マークを付けると非Optional型になります
            //print("myCategory = \(myCategory!)")
            

//売掛伝票単価ラベル1.textからカンマを取り除いています
            let カンマ無し単価ラベル1 = 売掛伝票単価ラベル1.text?.replacingOccurrences(of: ",", with: "")
//unitPrice1・単価1
            if let unitPrice1 = Int32(カンマ無し単価ラベル1!) {
                uriage.unitPrice1 = Float(unitPrice1)
                //print("101・単価1は\(売掛伝票単価ラベル1.text!)")

//name・顧客
                let name = String(売掛伝票顧客ラベル.text!)//ここで追加します
                uriage.name = name
//number・伝票番号
                let number = String(売掛伝票番号ラベル.text!)//ここで追加します
                uriage.number = Int16(number!)!
//retailer1・適用1
                //リストには適用1のみが表示されます
                if 適用テキスト1.text == "" {
                    適用テキスト1.text = "適用1"
                }
                let retailer1 = 適用テキスト1.text!//ここで追加します
                uriage.retailer1 = retailer1
                //print("102・適用1は\(適用テキスト1.text!)")
//details1・品名1
                let details1 = String(売掛伝票品名ラベル1.text!)//ここで追加します
                uriage.details1 = details1
                //print("103・品名1は\(売掛伝票品名ラベル1.text!)")
//quantity1・数量1
                let quantity1 = String(売掛伝票数量ラベル1.text!)//ここで追加します
                uriage.quantity1 = Float(quantity1!)!
                //print("104・数量1は\(売掛伝票数量ラベル1.text!)")
//total1・小計1の計算式
                uriage.total1 = Int32(Float(unitPrice1) * Float(quantity1!)!)//金額と数量をかけている
                //print("105・小計1は\(uriage.total1)")
//unit1・単位1
                let unit1 = String(売掛伝票単位ラベル1.text!)
                uriage.unit1 = unit1//ここで追加します
                //print("106・単位1は\(売掛伝票単位ラベル1.text!)")

                
                //品名復元を保存
                let restoredItemName = 品名rowString//ここで追加します
                uriage.restoredItemName = restoredItemName
                //数量を復元を保存
                let restoredQuantity = 数量rowString//ここで追加します
                uriage.restoredQuantity = restoredQuantity
                //単価を復元を保存
                let restoredUnitPrice = 単価rowString//ここで追加します
                uriage.restoredUnitPrice = restoredUnitPrice
            }
            
//MARK: - 重要 品名2の行
//最初の入力で2行目から7行目は入力結果がなくてもCoreData保存しないと次の入力で2行目以降に入力が反映されません
            if 売掛伝票品名ラベル2.text == "" || 売掛伝票単価ラベル2.text == "" || 売掛伝票数量ラベル2.text == "" || 売掛伝票単位ラベル2.text == nil { //これを追加します
                
                //print("\n200・入力はありません\n")
//ダミー単価2
                売掛伝票単価ラベル2.text = "123"
                売掛伝票単価ラベル2.alpha = 0
//ダミー品名2
                売掛伝票品名ラベル2.text = "ダミー品名2"
                売掛伝票品名ラベル2.alpha = 0
//ダミー数量2
                売掛伝票数量ラベル2.text = "0.0"
                売掛伝票数量ラベル2.alpha = 0
                適用テキスト2.alpha = 0
                
                uriage.total = (uriage.total1) + (uriage.total2)
                uriage.uriagedaka = (uriage.total)
                
                if let uriageCategoryIndex = 売上締日詳細.index(of: (uriage.category!)) {
//勘定科目の書き込み・売上現金
                    if uriageCategoryIndex == 0 {
                        uriage.genkin = (uriage.total)
                        taisyaku?.genkin = (uriage.total)
                    }
//勘定科目の書き込み・売掛金
                    if uriageCategoryIndex != 0 {
                        uriage.urikake = (uriage.total)
                        taisyaku?.urikakeTotal = (uriage.total)
                    }
//締切日のインデックス表示
                    //print("売上のuriageCategoryIndex = \(uriageCategoryIndex)")
                }
                
                (UIApplication.shared.delegate as! AppDelegate).saveContext()
                
                dismiss(animated: true, completion: nil)
            }

            
//単価2よりカンマを除去している
            let カンマ無し単価ラベル2 = 売掛伝票単価ラベル2.text?.replacingOccurrences(of: ",", with: "")
//unitPrice2・単価2
                if let unitPrice2 = Int32(カンマ無し単価ラベル2!) {
                    //print("201・単価2は\(売掛伝票単価ラベル2.text!)")
                    uriage.unitPrice2 = Float(unitPrice2)
//retailer2・適用2
                    if 適用テキスト2.text == "" {
                        適用テキスト2.text = "適用2"
                    }
                    let retailer2 = 適用テキスト2.text!//ここで追加します
                    uriage.retailer2 = retailer2
                    //print("202・適用2は\(適用テキスト2.text!)")
                    
//1行入力後の売掛伝票品名ラベル2.textはnilになります
                    //print("通過前・売掛伝票品名ラベル2は\(String(describing: 売掛伝票品名ラベル2.text))")
                    
                    if 売掛伝票品名ラベル2.text == "" {
                        売掛伝票品名ラベル2.text = " "
                    }
//details2・品名2
                    let details2 = String(売掛伝票品名ラベル2.text!)//ここで追加します
                    uriage.details2 = details2
                    //print("203・品名2は\(売掛伝票品名ラベル2.text!)")
//quantity2・数量2
                    let quantity2 = String(売掛伝票数量ラベル2.text!)//ここで追加します
                    uriage.quantity2 = Float(quantity2!)!
                    //print("204・数量2は\(売掛伝票数量ラベル2.text!)")
//total2・小計2の計算式
                    uriage.total2 = Int32(Float(unitPrice2) * Float(quantity2!)!)//金額と数量をかけている
                    //print("205・小計2は\(uriage.total2)")

                    if 売掛伝票単位ラベル2.text == "" {
                        売掛伝票単位ラベル2.text = " "
                    }
//unit2・単位2
                    let unit2 = String(売掛伝票単位ラベル2.text!)
                    uriage.unit2 = unit2//ここで追加します
                    //print("206・単位2は\(売掛伝票単位ラベル2.text!)")
            }
        }
        
//MARK: - 伝票小計の合計を計算して書き込んでいる
        uriage?.total = (uriage?.total1)! + (uriage?.total2)!
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        dismiss(animated: true, completion: nil)

    }
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        if let uriage = uriage {
            context.delete(uriage)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func insertNumber(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if costLabel.text == "0" {
            costLabel.text = String(sender.tag)
        } else if placehold {
            costLabel.text = String(sender.tag)
            placehold = false
        } else {
            costLabel.text = costLabel.text! + String(sender.tag)
        }
    }
    
    @IBAction func insert0(_ sender: UIButton) {
        if (costLabel.text?.characters.count)! >= 9 {
            return
        }
        if placehold {
            costLabel.text = "0"
            placehold = false
        } else if costLabel.text != "0" {
            if sender.tag == 11 {
                costLabel.text = costLabel.text! + "00"
            } else {
                costLabel.text = costLabel.text! + "0"
            }
        }
    }
    
    //追加5
    @IBAction func clearButtonTapped(_ sender: Any) {
        costLabel.text = "0"
        multiplyFlag = false
        placehold = false
        multiplyButton.isEnabled = true
        
        //追加しました
        /*顧客名.text = ""
        購入先.text = ""
        詳細.text = ""*/
    }
    
    @IBAction func multiplyButtonTapped(_ sender: Any) {
        multiplyFlag = true
        placehold = true
        multiplyButton.isEnabled = false
        edNumber = Int(costLabel.text!)!
    }
    
    @IBAction func equalButtonTapped(_ sender: Any) {
        if multiplyFlag {
            costLabel.text = String(edNumber * Int(costLabel.text!)!)
            multiplyFlag = false
            multiplyButton.isEnabled = true
        }
    }
    
    
    // MARK: - 売掛顧客ピッカー
    @IBAction func 売掛伝票顧客ピッカー(_ sender: UIButton) {
        if uriage?.category == "入金" {
            return
        }
        
        if 売掛伝票顧客入力 {
            if 売掛伝票顧客ピッカー部品.alpha == 0 {
                売掛伝票顧客ピッカー部品.alpha = 1
                売掛伝票顧客ラベル.alpha = 0
                売掛伝票番号入力 = false
                年ラベル.alpha = 0.1
                月ラベル.alpha = 0.1
                日ラベル.alpha = 0.1
                伝票アルファ.alpha = 0.3
                
                
            } else {
                売掛伝票顧客ピッカー部品.alpha = 0
                売掛伝票顧客ラベル.alpha = 1
                売掛伝票番号入力 = true
		売掛伝票顧客入力済 = true
                年ラベル.alpha = 1
                月ラベル.alpha = 1
                日ラベル.alpha = 1
                伝票アルファ.alpha = 1
            }
        }
    }
    
    // MARK: - 伝票日付ピッカー
    @IBAction func 売上伝票日付ピッカー(_ sender: UIButton) {
        if uriage?.category == "入金" {
            return
        }
        if 売掛伝票日付入力 {
            売掛伝票日付入力 = false
            伝票アルファ.alpha = 0.3
            売掛伝票顧客ラベル.alpha = 0
            年ラベル.alpha = 0
            月ラベル.alpha = 0
            日ラベル.alpha = 0
            datePicker.alpha = 1
            
            } else {
                売掛伝票日付入力 = true
                datePicker.alpha = 0
        }
    }
    
    // MARK: - 伝票番号ピッカー
    @IBAction func 売掛伝票番号ピッカー(_ sender: UIButton) {
        if uriage?.category == "入金" {
            return
        }
        if 売掛伝票番号入力 {
            if 売掛伝票番号ピッカー部品.alpha == 0 {
                売掛伝票番号ピッカー部品.alpha = 1
                売掛伝票番号ラベル.alpha = 0
                売掛伝票顧客入力 = false
                伝票アルファ.alpha = 0.3
            } else {
                伝票番号入力終了()
            }
        }
    }
    
    //参考サイトhttps://blog.77jp.net/uipickerview-swift-japanese-document-xcode
    // MARK: - 売掛伝票品名ピッカー1
    @IBAction func 売掛伝票品名ピッカー1(_ sender: UIButton) {
        if uriage?.category == "入金" {
            return
        }
        
        顧客品名ピッカー雛形設定()

        if 売掛伝票品名入力1 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 104, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                //売掛伝票品名ラベル1.tag = 1
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル1.alpha = 0
                売掛伝票数量ラベル1.alpha = 0
                売掛伝票単価ラベル1.alpha = 0
                伝票アルファ.alpha = 0.3
            } else { if (売掛伝票品名ラベル1.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 1
                    売掛伝票品名ピッカー部品.alpha = 0

                
                売掛伝票品名入力済1 = true
                売掛伝票品名入力2 = true
                
                    売掛伝票品名ラベル1.alpha = 1
                    売掛伝票数量ラベル1.alpha = 1
                    売掛伝票単価ラベル1.alpha = 1
                    伝票アルファ.alpha = 1
                売掛伝票品名入力済1 = true
//MARK: - 伝票完成()
                伝票完成()

//売掛伝票単価ラベル1.textからカンマを取り除いています
                売掛伝票単価ラベル1.text = 売掛伝票単価ラベル1.text?.replacingOccurrences(of: ",", with: "")
                
//伝票小計1の合計を計算しています
                売掛伝票小計ラベル1合計 = Int(Float(売掛伝票数量ラベル1.text!)! * Float(売掛伝票単価ラベル1.text!)!)
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計

                //参考サイトhttp://pebble8888.hatenablog.com/entry/2015/07/23/114459

                let カンマ付き小計ラベル1 = NSNumber(value: 売掛伝票小計ラベル1合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル1.text = フォーマッタ.string(from: カンマ付き小計ラベル1)!
                
                let カンマ付き合計ラベル = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き合計ラベル)!

                let カンマ変換 = Int(売掛伝票単価ラベル1.text!)
                //class KUSViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
                カンマフォーマッタ()
                売掛伝票単価ラベル1.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
                
                
// MARK: - 新規伝票入力合計計算・ここまで
                入力済()

            if 売掛伝票品名入力済2 {
                売掛伝票品名入力3 = true
            }
            if 売掛伝票品名入力済3 {
                売掛伝票品名入力4 = true
            }
            if 売掛伝票品名入力済4 {
                売掛伝票品名入力5 = true
            }
            if 売掛伝票品名入力済5 {
                売掛伝票品名入力6 = true
            }
            if 売掛伝票品名入力済6 {
                売掛伝票品名入力7 = true
            }
                }
            }
        }
    }
    
    @IBAction func 売掛伝票品名ピッカー2(_ sender: UIButton) {
        if 売掛伝票品名入力2 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 127, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル2.alpha = 0
                売掛伝票数量ラベル2.alpha = 0
                売掛伝票単価ラベル2.alpha = 0
                伝票アルファ.alpha = 0.3
            } else { if (売掛伝票品名ラベル2.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                売掛伝票品名入力済2 = true
                    売掛伝票品名入力3 = true
                
                売掛伝票品名入力1 = true
                売掛伝票品名入力2 = true
                売掛伝票品名入力3 = true

                    売掛伝票品名ラベル2.alpha = 1
                    売掛伝票数量ラベル2.alpha = 1
                    売掛伝票単価ラベル2.alpha = 1
                売掛伝票小計ラベル2.alpha = 1
                    伝票アルファ.alpha = 1

// MARK: - 単価ラベル2からカンマを取り去ります
                売掛伝票単価ラベル2.text = 売掛伝票単価ラベル2.text?.replacingOccurrences(of: ",", with: "")
// MARK: - 数量ラベル2 × 単価ラベル2 = 売掛伝票小計ラベル2小計を計算しています
                売掛伝票小計ラベル2合計 = Int(Float(売掛伝票数量ラベル2.text!)! * Float(売掛伝票単価ラベル2.text!)!)
                let カンマ付き小計ラベル2小計 = NSNumber(value: 売掛伝票小計ラベル2合計)
                カンマフォーマッタ()
                売掛伝票小計ラベル2.text = フォーマッタ.string(from: カンマ付き小計ラベル2小計)!
                
// MARK: - //伝票小計2の合計を計算しています
                伝票合計Int = 売掛伝票小計ラベル1合計 + 売掛伝票小計ラベル2合計
// MARK: - 売掛伝票合計ラベルの値にカンマを付ける
                let カンマ付き伝票合計 = NSNumber(value: 伝票合計Int)
                カンマフォーマッタ()
                売掛伝票合計ラベル.text = フォーマッタ.string(from: カンマ付き伝票合計)!

//不要かも ? すでに単価にカンマが付いているから ?
                let カンマ変換 = Int(売掛伝票単価ラベル2.text!)
                //class KUSViewControllerletにグローバル設定しました・フォーマッタ = NumberFormatter()
                カンマフォーマッタ()
                売掛伝票単価ラベル2.text = フォーマッタ.string(from: カンマ変換! as NSNumber)!
                
                
                if 売掛伝票品名入力済3 {
                    売掛伝票品名入力4 = true
                }
                if 売掛伝票品名入力済4 {
                    売掛伝票品名入力5 = true
                }
                if 売掛伝票品名入力済5 {
                    売掛伝票品名入力6 = true
                }
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    
    @IBAction func 売掛伝票品名ピッカー3(_ sender: UIButton) {
        if 売掛伝票品名入力3 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 149, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false
                
                売掛伝票品名ラベル3.alpha = 0
                売掛伝票数量ラベル3.alpha = 0
                売掛伝票単価ラベル3.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル3.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                売掛伝票品名入力済3 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力4 = true

                    売掛伝票品名ラベル3.alpha = 1
                    売掛伝票数量ラベル3.alpha = 1
                    売掛伝票単価ラベル3.alpha = 1
                    伝票アルファ.alpha = 1
                if 売掛伝票品名入力済4 {
                    売掛伝票品名入力5 = true
                }
                if 売掛伝票品名入力済5 {
                    売掛伝票品名入力6 = true
                }
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー4(_ sender: UIButton) {
        if 売掛伝票品名入力4 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 171.5, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル4.alpha = 0
                売掛伝票数量ラベル4.alpha = 0
                売掛伝票単価ラベル4.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル4.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                売掛伝票品名入力済4 = true
                    売掛伝票品名入力3 = true
                    売掛伝票品名入力5 = true
                
                    売掛伝票品名ラベル4.alpha = 1
                    売掛伝票数量ラベル4.alpha = 1
                    売掛伝票単価ラベル4.alpha = 1
                    伝票アルファ.alpha = 1
                if 売掛伝票品名入力済5 {
                    売掛伝票品名入力6 = true
                }
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー5(_ sender: UIButton) {
        if 売掛伝票品名入力5 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 194, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル5.alpha = 0
                売掛伝票数量ラベル5.alpha = 0
                売掛伝票単価ラベル5.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル5.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力3 = true
                売掛伝票品名入力済5 = true
                    売掛伝票品名入力4 = true
                    売掛伝票品名入力6 = true
                
                    売掛伝票品名ラベル5.alpha = 1
                    売掛伝票数量ラベル5.alpha = 1
                    売掛伝票単価ラベル5.alpha = 1
                    伝票アルファ.alpha = 1
                if 売掛伝票品名入力済6 {
                    売掛伝票品名入力7 = true
                }
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー6(_ sender: UIButton) {
        if 売掛伝票品名入力6 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 216.5, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力7 = false

                売掛伝票品名ラベル6.alpha = 0
                売掛伝票数量ラベル6.alpha = 0
                売掛伝票単価ラベル6.alpha = 0
                伝票アルファ.alpha = 0.3
        } else { if (売掛伝票品名ラベル6.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力3 = true
                    売掛伝票品名入力4 = true
                    売掛伝票品名入力5 = true
                売掛伝票品名入力済6 = true
                    売掛伝票品名入力7 = true

                    売掛伝票品名ラベル6.alpha = 1
                    売掛伝票数量ラベル6.alpha = 1
                    売掛伝票単価ラベル6.alpha = 1
                    伝票アルファ.alpha = 1
                }
            }
        }
    }
    @IBAction func 売掛伝票品名ピッカー7(_ sender: UIButton) {
        if 売掛伝票品名入力7 {
            if 売掛伝票品名ピッカー部品.alpha == 0 {
                売掛伝票品名ピッカー部品.frame = CGRect(x: 70, y: 239.5, width: 250, height: 120)
                売掛伝票品名ピッカー部品.alpha = 1
                売掛伝票品名入力1 = false
                売掛伝票品名入力2 = false
                売掛伝票品名入力3 = false
                売掛伝票品名入力4 = false
                売掛伝票品名入力5 = false
                売掛伝票品名入力6 = false
                売掛伝票品名入力済7 = true
                
                売掛伝票品名ラベル7.alpha = 0
                売掛伝票数量ラベル7.alpha = 0
                売掛伝票単価ラベル7.alpha = 0
        } else { if (売掛伝票品名ラベル7.text != "") {
                    売掛伝票品名ピッカー部品.alpha = 0
                
                    売掛伝票品名入力1 = true
                    売掛伝票品名入力2 = true
                    売掛伝票品名入力3 = true
                    売掛伝票品名入力4 = true
                    売掛伝票品名入力5 = true
                    売掛伝票品名入力6 = true
                
                    売掛伝票品名ラベル7.alpha = 1
                    売掛伝票数量ラベル7.alpha = 1
                    売掛伝票単価ラベル7.alpha = 1
                    伝票アルファ.alpha = 1
                }
            }
        }
    }
    
    
//画面拡大と移動
    @IBAction func 画像拡大(_ sender: UIPinchGestureRecognizer) {
        if(sender.state == UIGestureRecognizerState.began){
            //ピンチ開始時のアフィン変換をクラス変数に保持する。
            startTransform = View拡大.transform
        }
        //ピンチ開始時のアフィン変換を引き継いでアフィン変換を行う。
        View拡大.transform = startTransform.scaledBy(x: sender.scale, y: sender.scale)
    }

    @IBAction func 画像移動(_ sender: UIPanGestureRecognizer) {
        //print("パン通過しました")
        //移動量を取得する。
        let move:CGPoint = sender.translation(in: view)
        
        //ドラッグした部品の座標に移動量を加算する。
        sender.view!.center.x += move.x
        sender.view!.center.y += move.y
        
        //参考サイト http://stackoverflow.com/questions/37946990/cgrectmake-cgpointmake-cgsizemake-cgrectzero-cgpointzero-is-unavailable-in-s
        //移動量を0にする。
        sender.setTranslation(CGPoint.zero, in:view)
    }
//ここまで
}
