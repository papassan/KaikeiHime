//
//  ModelController.swift
//  KaikeiHime
//
//  Created by Toshikazu Fukuda on 2017/05/27.
//  Copyright © 2017年 株式会社パパスサン. All rights reserved.
//

import UIKit

class pKHPageController: NSObject, UIPageViewControllerDataSource {

    var yearData: [String] = []
    var monthData: [String] = []
    var currentMonthIndex: Int = 12

    override init() {
        super.init()
        
        // Create the data model.
        let dateFormatter = DateFormatter()
        self.monthData = dateFormatter.monthSymbols
        
        let dateComps = Calendar.current.dateComponents([.year, .month], from: Date())
        for year in 2010...dateComps.year! {
            yearData.append(String(year))
        }
        currentMonthIndex = dateComps.month!
    }

//ここKHDataViewController
    func viewControllerAtIndex(_ index: Int, _ yearIndex: Int, storyboard: UIStoryboard) -> pKHDataViewController? {
        // Return the data view controller for the given index.
        if (monthData.count == 0) || (index >= monthData.count) {
            return nil
        }

        // Create a new view controller and pass suitable data.
//ここKHDataViewController
        let dataViewController = storyboard.instantiateViewController(withIdentifier: "pKHDataViewController") as! pKHDataViewController//ここ
        dataViewController.month = self.monthData[index]
        dataViewController.year = self.yearData[yearIndex]

        return dataViewController
    }

//ここKHDataViewController
    func monthIndexOfViewController(_ viewController: pKHDataViewController) -> Int {
        // Return the index of the given data view controller.
        // For simplicity, this implementation uses a static array of model objects and the view controller stores the model object; you can therefore use the model object to identify the index.
        return monthData.index(of: viewController.month) ?? NSNotFound
    }
    
//ここKHDataViewController
    func yearIndexOfViewController(_ viewController: pKHDataViewController) -> Int {
        return yearData.index(of: viewController.year) ?? NSNotFound
    }

    // MARK: - Page View Controller Data Source

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
//ここKHDataViewController
        var index = self.monthIndexOfViewController(viewController as! pKHDataViewController)
//ここKHDataViewController
        var yearIndex = self.yearIndexOfViewController(viewController as! pKHDataViewController)
        if index == NSNotFound || yearIndex == NSNotFound {
            return nil
        }
        
        if index == 0 {
            if yearIndex != 0 {
                index = self.monthData.count - 1
                yearIndex -= 1
                return self.viewControllerAtIndex(index, yearIndex, storyboard: viewController.storyboard!)
            } else {
                return nil
            }
        }
        
        index -= 1
        return self.viewControllerAtIndex(index, yearIndex, storyboard: viewController.storyboard!)
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
//ここKHDataViewController
        var index = self.monthIndexOfViewController(viewController as! pKHDataViewController)
//ここKHDataViewController
        var yearIndex = self.yearIndexOfViewController(viewController as! pKHDataViewController)
        if index == NSNotFound {
            return nil
        }
        
        index += 1
        
        if yearIndex == yearData.count - 1 && index == currentMonthIndex {
            return nil
        }
        
        if index == self.monthData.count {
            index = 0
            yearIndex += 1
            return self.viewControllerAtIndex(index, yearIndex, storyboard: viewController.storyboard!)
        }
        return self.viewControllerAtIndex(index, yearIndex, storyboard: viewController.storyboard!)
    }

}

